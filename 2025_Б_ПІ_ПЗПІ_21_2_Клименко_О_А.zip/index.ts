import { registerRootComponent } from 'expo';
import '@/lib/i18n';
import 'react-native-url-polyfill/auto';
import 'intl-pluralrules';
import 'react-native-get-random-values';

import App from './src/App';
import { configureGoogleSignIn } from './src/lib/googleAuth';

const prepareApp = async () => {
  if (!__DEV__ || true) {
    return;
  }

  await import('./src/lib/mocks/polyfills');
  const { server } = await import('./src/lib/mocks/server');

  server.listen();
};

configureGoogleSignIn();

// registerRootComponent calls AppRegistry.registerComponent('main', () => App);
// It also ensures that whether you load the app in Expo Go or in a native build,
// the environment is set up appropriately
prepareApp().then(() => registerRootComponent(App));
