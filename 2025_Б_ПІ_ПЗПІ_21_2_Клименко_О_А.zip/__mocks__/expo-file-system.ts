export const documentDirectory = 'file://mock-documents/';
export const cacheDirectory = 'file://mock-cache/';

export const makeDirectoryAsync = jest.fn().mockResolvedValue(undefined);
export const createDownloadResumable = jest.fn();
export const DownloadResumable = jest.fn();
