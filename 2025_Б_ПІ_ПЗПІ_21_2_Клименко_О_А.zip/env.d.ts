declare namespace NodeJS {
  interface ProcessEnv {
    NODE_ENV: 'development' | 'production' | 'test';
    EXPO_PUBLIC_API_BASE_URL: string;
    EXPO_PUBLIC_AUTH_BASE_URL: string;
    EXPO_PUBLIC_GOOGLE_CLIENT_ID: string;
    EXPO_PUBLIC_FILE_SYSTEM_DOWNLOAD_URL_MOCK?: string;
    EXPO_PUBLIC_FILE_SYSTEM_UPLOAD_URL_MOCK?: string;
  }
}
