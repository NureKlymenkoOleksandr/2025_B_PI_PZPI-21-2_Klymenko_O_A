const ensureEnv = () => {
  const requiredVars = ['API_BASE_URL', 'GOOGLE_CLIENT_ID', 'AUTH_BASE_URL'];
  const missingVars: string[] = [];

  if (requiredVars.some((envVar) => !process.env[`EXPO_PUBLIC_${envVar}`])) {
    throw new Error('Invalid env provided.');
  }

  requiredVars.forEach((envVar) => {
    if (!process.env[`EXPO_PUBLIC_${envVar}`]) {
      missingVars.push(envVar);
    }
  });

  if (missingVars.length) {
    throw new Error(
      `Invalid env provided.\n\nMissing variables:\n${missingVars.join('\n')}`,
    );
  }
};

if (process.env.NODE_ENV !== 'test') ensureEnv();

export const API_BASE_URL = process.env.EXPO_PUBLIC_API_BASE_URL;
export const AUTH_BASE_URL = process.env.EXPO_PUBLIC_AUTH_BASE_URL;
export const GOOGLE_CLIENT_ID = process.env.EXPO_PUBLIC_GOOGLE_CLIENT_ID;
export const FILE_SYSTEM_DOWNLOAD_URL_MOCK =
  process.env.EXPO_PUBLIC_FILE_SYSTEM_DOWNLOAD_URL_MOCK;
export const FILE_SYSTEM_UPLOAD_URL_MOCK =
  process.env.EXPO_PUBLIC_FILE_SYSTEM_UPLOAD_URL_MOCK;
