import { Image } from 'expo-image';
import { StyleSheet, View, Pressable } from 'react-native';

import { ScreenContainer } from '@/common/components/layout/ScreenContainer';
import { Typography } from '@/common/components/Typography';
import { Theme, useTheme } from '@/common/theme';
import { GoogleButton } from '@/features/auth/components/GoogleButton';
import { setupTestAuth } from '@/testing/auth-test-utils';

export const AuthScreen = () => {
  const { theme } = useTheme();
  const isDarkTheme = theme === Theme.DARK;
  console.log(process.env.NODE_ENV);
  return (
    <ScreenContainer justify="center">
      <View style={styles.wrapper}>
        <View>
          <Image
            source={
              isDarkTheme
                ? require('assets/app-logo-dark.png')
                : require('assets/app-logo-light.png')
            }
            contentFit="contain"
            style={styles.logo}
          />
          <Typography style={styles.message} weight="bold">
            One step to peace of mind in the cloud
          </Typography>
        </View>
        <View>
          <GoogleButton />
          {process.env.NODE_ENV === 'aaa' && (
            <View style={styles.testButtonContainer}>
              <Pressable
                onPress={setupTestAuth}
                style={({ pressed }) => [
                  styles.testButton,
                  pressed && styles.pressed,
                ]}
                testID="test-login-button"
              >
                <Typography color="#FFFFFF">Test Login</Typography>
              </Pressable>
            </View>
          )}
        </View>
      </View>
    </ScreenContainer>
  );
};

const styles = StyleSheet.create({
  wrapper: {
    marginBlockEnd: 'auto',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingBlock: 80,
    paddingInline: 24,
    flex: 1,
  },
  message: {
    fontSize: 24,
    marginBottom: 24,
    letterSpacing: 1.1,
  },
  logo: {
    height: 200,
    alignSelf: 'stretch',
  },
  testButtonContainer: {
    marginTop: 16,
  },
  testButton: {
    backgroundColor: '#4CAF50',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  pressed: {
    opacity: 0.8,
  },
});
