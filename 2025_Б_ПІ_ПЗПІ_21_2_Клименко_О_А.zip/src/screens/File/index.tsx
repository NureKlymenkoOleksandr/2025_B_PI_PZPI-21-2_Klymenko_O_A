import Ionicons from '@expo/vector-icons/Ionicons';
import { StaticScreenProps } from '@react-navigation/native';
import { Pressable } from 'react-native';

import { GoBackButton } from '@/common/components/layout/GoBackButton';
import { HeaderContainer } from '@/common/components/layout/HeaderContainer';
import { ScreenContainer } from '@/common/components/layout/ScreenContainer';
import { Loader } from '@/common/components/Loader';
import { Typography } from '@/common/components/Typography';
import { useTheme } from '@/common/theme';
import { getMimeTypeFromExtension } from '@/common/utils/mimeType';
import { useFileQuery } from '@/features/file/api/getFile';
import { useFileDownloadService } from '@/features/file/context';
import { FileWithConnection } from '@/features/file/types';
import { useFileSystemActionStore } from '@/features/file-system/stores/fileSystemActionStore';
import { FileSystemAction } from '@/features/file-system/types';
import { AudioPreview } from '@/features/preview/components/AudioPreview';
import { ImagePreview } from '@/features/preview/components/ImagePreview';
import { NotSupportedPreview } from '@/features/preview/components/NotSupportedPreview';
import { VideoPreview } from '@/features/preview/components/VideoPreview';

type FileScreenProps = StaticScreenProps<{
  id: string;
}>;

export const FileScreen = ({ route }: FileScreenProps) => {
  const { colors } = useTheme();
  const { data, isLoading } = useFileQuery(route.params.id);
  const fileDownloadService = useFileDownloadService();
  const { setCurrentAction, setCurrentItem } = useFileSystemActionStore(
    (store) => ({
      setCurrentAction: store.setCurrentAction,
      setCurrentItem: store.setCurrentItem,
    }),
  );

  const renderPreview = (file: FileWithConnection) => {
    const type = getMimeTypeFromExtension(file.extension).mediaType;
    const fileUrl = fileDownloadService.getDownloadURL(file);

    switch (type) {
      case 'audio':
        return <AudioPreview url={fileUrl} />;
      case 'image':
        return <ImagePreview url={fileUrl} cacheKey={file.id} />;
      case 'video':
        return <VideoPreview url={fileUrl} />;
      default:
        return <NotSupportedPreview fileExtension={file.extension} />;
    }
  };

  const handleDownloadClick = (file: FileWithConnection) => () => {
    setCurrentAction(FileSystemAction.DOWNLOAD);
    setCurrentItem(file);
  };

  if (isLoading || !data) return <Loader />;

  return (
    <ScreenContainer noTopPadding>
      <HeaderContainer
        headerLeft={<GoBackButton />}
        headerRight={
          <Pressable
            onPress={handleDownloadClick(data)}
            style={{ marginInline: 16 }}
          >
            <Ionicons name="download" size={20} color={colors.text} />
          </Pressable>
        }
      >
        <Typography numberOfLines={1} ellipsizeMode="middle" size={20}>
          {data.name}
        </Typography>
      </HeaderContainer>
      {renderPreview(data)}
    </ScreenContainer>
  );
};
