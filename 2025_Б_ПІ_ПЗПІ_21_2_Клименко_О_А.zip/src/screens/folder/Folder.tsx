import { StaticScreenProps } from '@react-navigation/native';

import { ScreenContainer } from '@/common/components/layout/ScreenContainer';
import { Folder } from '@/features/file-system/types';
import { FolderContent } from '@/features/folder/components/FolderContent';
import { useFoldersNavigation } from '@/navigation/hooks/useFoldersNavigation';

export type FolderScreenProps = StaticScreenProps<{
  folderId: string;
  folderName: string;
}>;

export const FolderScreen = ({ route }: FolderScreenProps) => {
  const navigation = useFoldersNavigation();

  const handleFolderPress = (folder: Folder) => {
    navigation.push('Folder', {
      folderId: folder.id,
      folderName: folder.name,
    });
  };

  return (
    <ScreenContainer noTopPadding>
      <FolderContent
        folderId={route.params.folderId}
        onFolderPress={handleFolderPress}
      />
    </ScreenContainer>
  );
};
