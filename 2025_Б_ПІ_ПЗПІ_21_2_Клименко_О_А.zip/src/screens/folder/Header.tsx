import { Route } from '@react-navigation/native';

import { GoBackButton } from '@/common/components/layout/GoBackButton';
import { HeaderContainer } from '@/common/components/layout/HeaderContainer';
import { Typography } from '@/common/components/Typography';

import { FolderScreenProps } from './Folder';

type FolderHeaderProps = {
  route: Route<string>;
};

export const FolderHeader = ({ route }: FolderHeaderProps) => {
  const folderName = (route as FolderScreenProps['route']).params?.folderName;

  return (
    <HeaderContainer headerLeft={<GoBackButton />}>
      <Typography size={20}>{folderName}</Typography>
    </HeaderContainer>
  );
};
