import { ScreenContainer } from '@/common/components/layout/ScreenContainer';
import { Folder } from '@/features/file-system/types';
import { FolderContent } from '@/features/folder/components/FolderContent';
import { useFoldersNavigation } from '@/navigation/hooks/useFoldersNavigation';

import { FolderScreenProps } from './Folder';

type FolderMoveScreenProps = FolderScreenProps;

export const FolderMoveScreen = ({ route }: FolderMoveScreenProps) => {
  const navigation = useFoldersNavigation();

  const handleFolderPress = (folder: Folder) => {
    navigation.push('FolderMove', {
      folderId: folder.id,
      folderName: folder.name,
    });
  };

  return (
    <ScreenContainer noTopPadding>
      <FolderContent
        folderId={route.params.folderId}
        onFolderPress={handleFolderPress}
        folderOnly
        itemMenuHidden
      />
    </ScreenContainer>
  );
};
