import FontAwesome6 from '@expo/vector-icons/FontAwesome6';
import { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { StyleSheet, View, FlatList } from 'react-native';
import { Pressable } from 'react-native-gesture-handler';
import Animated, {
  useAnimatedStyle,
  withTiming,
  useSharedValue,
} from 'react-native-reanimated';

import { HeaderContainer } from '@/common/components/layout/HeaderContainer';
import { ScreenContainer } from '@/common/components/layout/ScreenContainer';
import { Typography } from '@/common/components/Typography';
import { FileIcon } from '@/common/icons/FileIcon';
import { UploadIcon } from '@/common/icons/UploadIcon';
import { useTheme } from '@/common/theme';
import { useDeleteFileMutation } from '@/features/file/api/deleteFile';
import { useFileUploadStore } from '@/features/file/context';
import { FileUpload, FileUploadStatus } from '@/features/file/types';

type UploadItemProps = {
  uploadId: string;
  upload: FileUpload;
};

const EmptyState = () => {
  const { t } = useTranslation();
  const { colors } = useTheme();

  return (
    <View
      style={[styles.emptyContainer, { backgroundColor: colors.surfaceSubtle }]}
    >
      <UploadIcon width={64} height={64} fill={colors.primary} />
      <Typography size={18} style={styles.emptyTitle}>
        {t('uploads.empty.title')}
      </Typography>
      <Typography color={colors.text} style={styles.emptyText}>
        {t('uploads.empty.description')}
      </Typography>
    </View>
  );
};

const UploadItem = ({ uploadId, upload }: UploadItemProps) => {
  const { colors } = useTheme();
  const deleteFileMutation = useDeleteFileMutation();
  const { cancelUpload, removeUpload, uploadFolderId } = useFileUploadStore(
    (store) => ({
      cancelUpload: store.cancelUpload,
      removeUpload: store.removeUpload,
      uploadFolderId: store.uploadFolderId,
    }),
  );

  const progress =
    (upload.totalBytesSent / upload.totalBytesExpectedToSend) * 100;
  const animatedProgress = useSharedValue(0);

  useEffect(() => {
    animatedProgress.value = withTiming(progress, {
      duration: 300,
    });
  }, [progress]);

  const animatedStyle = useAnimatedStyle(() => ({
    width: `${animatedProgress.value}%`,
  }));

  const handleCancel = async () => {
    await cancelUpload(uploadId);

    if (upload.fileId && uploadFolderId) {
      await deleteFileMutation.mutateAsync({
        id: upload.fileId,
        parentDirectoryID: uploadFolderId,
      });
    }
  };

  return (
    <View
      style={[styles.uploadItem, { backgroundColor: colors.surfaceSubtle }]}
    >
      <View style={styles.uploadInfo}>
        <FileIcon width={32} height={32} fill={colors.primary} />
        <View style={styles.uploadDetails}>
          <Typography numberOfLines={1}>{upload.fileName}</Typography>
          <View style={styles.progressContainer}>
            <View
              style={[styles.progressBar, { backgroundColor: colors.surface }]}
            >
              <Animated.View
                style={[
                  styles.progressFill,
                  { backgroundColor: colors.primary },
                  animatedStyle,
                ]}
              />
            </View>
            <Typography size={12} color={colors.text}>
              {Math.round(progress)}%
            </Typography>
          </View>
        </View>
      </View>
      {upload.status === FileUploadStatus.UPLOADING ? (
        <Pressable
          onPress={handleCancel}
          style={({ pressed }) => [
            styles.actionButton,
            pressed && { opacity: 0.6 },
          ]}
        >
          <FontAwesome6 name="xmark" size={24} color={colors.text} />
        </Pressable>
      ) : upload.status === FileUploadStatus.FINISHED ||
        upload.status === FileUploadStatus.CANCELED ? (
        <Pressable
          onPress={() => removeUpload(uploadId)}
          style={({ pressed }) => [
            styles.actionButton,
            pressed && { opacity: 0.6 },
          ]}
        >
          <FontAwesome6 name="trash-can" size={24} color={colors.text} />
        </Pressable>
      ) : null}
    </View>
  );
};

const Header = () => {
  const { t } = useTranslation();
  return (
    <HeaderContainer>
      <Typography size={20} style={styles.title}>
        {t('screen.uploads')}
      </Typography>
    </HeaderContainer>
  );
};

export const UploadsScreen = () => {
  const fileUploads = useFileUploadStore((store) => store.fileUploads);
  const { colors } = useTheme();

  const uploads = Array.from(fileUploads.entries()).map(
    ([uploadId, upload]) => ({
      uploadId,
      upload,
    }),
  );

  const renderItem = ({
    item,
  }: {
    item: { uploadId: string; upload: FileUpload };
  }) => <UploadItem uploadId={item.uploadId} upload={item.upload} />;

  const keyExtractor = (item: { uploadId: string; upload: FileUpload }) =>
    item.uploadId;

  return (
    <ScreenContainer noTopPadding>
      <Header />
      <FlatList
        data={uploads}
        renderItem={renderItem}
        keyExtractor={keyExtractor}
        contentContainerStyle={[
          styles.listContent,
          { backgroundColor: colors.background },
        ]}
        ListEmptyComponent={EmptyState}
      />
    </ScreenContainer>
  );
};

const styles = StyleSheet.create({
  listContent: {
    flexGrow: 1,
    padding: 16,
  },
  title: {
    marginBlockStart: 8,
  },
  emptyContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 12,
    padding: 24,
    gap: 16,
  },
  emptyTitle: {
    marginBottom: 8,
  },
  emptyText: {
    textAlign: 'center',
  },
  uploadItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    borderRadius: 12,
    marginBottom: 8,
  },
  uploadInfo: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  uploadDetails: {
    flex: 1,
    gap: 8,
  },
  progressContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  progressBar: {
    flex: 1,
    height: 4,
    borderRadius: 2,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    borderRadius: 2,
  },
  actionButton: {
    padding: 8,
  },
});
