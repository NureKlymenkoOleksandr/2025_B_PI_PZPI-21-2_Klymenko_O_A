import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { NativeStackHeaderProps } from '@react-navigation/native-stack';
import { useEffect, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import {
  NativeSyntheticEvent,
  TextInput,
  TextInputSubmitEditingEventData,
  View,
  StyleSheet,
  Pressable,
  ScrollView,
} from 'react-native';

import { Input } from '@/common/components/Input';
import { GoBackButton } from '@/common/components/layout/GoBackButton';
import { HeaderContainer } from '@/common/components/layout/HeaderContainer';
import { Typography } from '@/common/components/Typography';
import { useTheme } from '@/common/theme';
import { DateFilterMenu } from '@/features/search/components/DateFilterMenu';
import { FileTypeFilterMenu } from '@/features/search/components/FileTypeFilterMenu';
import {
  FILE_TYPE_FILTERS,
  useSearchStore,
} from '@/features/search/stores/searchStore';

type SearchHeaderProps = Pick<NativeStackHeaderProps, 'back'>;

export const SearchHeader = ({ back }: SearchHeaderProps) => {
  const { t } = useTranslation();
  const { colors } = useTheme();
  const inputRef = useRef<TextInput>(null);
  const [isFilterMenuVisible, setIsFilterMenuVisible] = useState(false);
  const [isUpdatedAtMenuVisible, setIsUpdatedAtMenuVisible] = useState(false);
  const [isCreatedAtMenuVisible, setIsCreatedAtMenuVisible] = useState(false);

  const setQuery = useSearchStore((store) => store.setQuery);
  const selectedFileTypes = useSearchStore((store) => store.selectedFileTypes);
  const updatedAtRange = useSearchStore((store) => store.updatedAtRange);
  const createdAtRange = useSearchStore((store) => store.createdAtRange);

  useEffect(() => {
    const timeout = setTimeout(() => {
      inputRef.current?.focus();
    }, 350);

    return () => {
      clearTimeout(timeout);
    };
  }, []);

  const handleSubmitSearch = (
    e: NativeSyntheticEvent<TextInputSubmitEditingEventData>,
  ) => {
    setQuery(e.nativeEvent.text);
  };

  const getFilterButtonText = () => {
    if (selectedFileTypes.length === 0) {
      return t('search.fileTypes');
    }

    const firstType = FILE_TYPE_FILTERS.find(
      (filter) => filter.id === selectedFileTypes[0],
    );

    if (selectedFileTypes.length === 1) {
      return t(firstType?.nameKey ?? '');
    }

    return t('search.filterButton.multiple', {
      type: firstType?.nameKey,
      count: selectedFileTypes.length - 1,
    });
  };

  const isDateFilterEmpty = (type: 'updatedAt' | 'createdAt') => {
    const range = type === 'updatedAt' ? updatedAtRange : createdAtRange;
    return !range.startDate && !range.endDate;
  };

  const getDateFilterButtonText = (type: 'updatedAt' | 'createdAt') => {
    const range = type === 'updatedAt' ? updatedAtRange : createdAtRange;
    if (isDateFilterEmpty(type)) {
      return t(`search.dateFilters.${type}Title`);
    }
    if (range.startDate && range.endDate) {
      return `${range.startDate.toLocaleDateString()} - ${range.endDate.toLocaleDateString()}`;
    }
    return range.startDate
      ? `${t('search.dateFilters.from')} ${range.startDate.toLocaleDateString()}`
      : `${t('search.dateFilters.to')} ${range.endDate?.toLocaleDateString()}`;
  };

  return (
    <>
      <HeaderContainer headerLeft={!!back && <GoBackButton />}>
        <Input
          ref={inputRef}
          placeholder={t('search.placeholder')}
          onSubmitEditing={handleSubmitSearch}
        />
      </HeaderContainer>
      <ScrollView
        style={styles.filterContainer}
        contentContainerStyle={styles.filterButtons}
        horizontal
        showsHorizontalScrollIndicator={false}
      >
        <Pressable
          onPress={() => setIsFilterMenuVisible(true)}
          style={[
            styles.filterButton,
            {
              backgroundColor: selectedFileTypes.length
                ? colors.primary
                : colors.surfaceSubtle,
              borderColor: colors.surface,
            },
          ]}
        >
          <MaterialIcons
            name="filter-list"
            size={20}
            color={selectedFileTypes.length ? colors.contrastText : colors.text}
          />
          <Typography
            size={14}
            color={selectedFileTypes.length ? colors.contrastText : colors.text}
          >
            {getFilterButtonText()}
          </Typography>
        </Pressable>
        <Pressable
          onPress={() => setIsUpdatedAtMenuVisible(true)}
          style={[
            styles.filterButton,
            {
              backgroundColor: !isDateFilterEmpty('updatedAt')
                ? colors.primary
                : colors.surfaceSubtle,
              borderColor: colors.surface,
            },
          ]}
        >
          <MaterialIcons
            name="update"
            size={20}
            color={
              !isDateFilterEmpty('updatedAt')
                ? colors.contrastText
                : colors.text
            }
          />
          <Typography
            size={14}
            color={
              !isDateFilterEmpty('updatedAt')
                ? colors.contrastText
                : colors.text
            }
          >
            {getDateFilterButtonText('updatedAt')}
          </Typography>
        </Pressable>
        <Pressable
          onPress={() => setIsCreatedAtMenuVisible(true)}
          style={[
            styles.filterButton,
            {
              backgroundColor: !isDateFilterEmpty('createdAt')
                ? colors.primary
                : colors.surfaceSubtle,
              borderColor: colors.surface,
            },
          ]}
        >
          <MaterialIcons
            name="event"
            size={20}
            color={
              !isDateFilterEmpty('createdAt')
                ? colors.contrastText
                : colors.text
            }
          />
          <Typography
            size={14}
            color={
              !isDateFilterEmpty('createdAt')
                ? colors.contrastText
                : colors.text
            }
          >
            {getDateFilterButtonText('createdAt')}
          </Typography>
        </Pressable>
      </ScrollView>
      <FileTypeFilterMenu
        isVisible={isFilterMenuVisible}
        onClose={() => setIsFilterMenuVisible(false)}
      />
      <DateFilterMenu
        isVisible={isUpdatedAtMenuVisible}
        onClose={() => setIsUpdatedAtMenuVisible(false)}
        type="updatedAt"
      />
      <DateFilterMenu
        isVisible={isCreatedAtMenuVisible}
        onClose={() => setIsCreatedAtMenuVisible(false)}
        type="createdAt"
      />
    </>
  );
};

const styles = StyleSheet.create({
  filterContainer: {
    paddingVertical: 8,
  },
  filterButtons: {
    flexDirection: 'row',
    gap: 16,
    paddingHorizontal: 16,
  },
  filterButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    borderWidth: 1,
  },
});
