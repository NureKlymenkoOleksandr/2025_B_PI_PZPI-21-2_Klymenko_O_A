import { ScreenContainer } from '@/common/components/layout/ScreenContainer';
import { useUnmount } from '@/common/hooks/useUnmount';
import { SearchContent } from '@/features/search/components/SearchContent';
import { useSearchStore } from '@/features/search/stores/searchStore';

import { SearchHeader } from './Header';

const Screen = () => {
  const { query, reset } = useSearchStore((store) => ({
    query: store.query,
    reset: store.reset,
  }));

  useUnmount(reset);

  return (
    <ScreenContainer noTopPadding>
      <SearchContent query={query} />
    </ScreenContainer>
  );
};

export const SearchScreen = {
  Header: SearchHeader,
  Screen,
};
