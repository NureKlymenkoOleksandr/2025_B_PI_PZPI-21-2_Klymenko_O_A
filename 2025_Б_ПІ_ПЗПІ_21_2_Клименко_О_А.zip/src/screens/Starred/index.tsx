import { useTranslation } from 'react-i18next';

import { HeaderContainer } from '@/common/components/layout/HeaderContainer';
import { ScreenContainer } from '@/common/components/layout/ScreenContainer';
import { Loader } from '@/common/components/Loader';
import { Typography } from '@/common/components/Typography';
import { useStarredFiles } from '@/features/file/api/getStarredFiles';
import { FileSystemList } from '@/features/file-system/components/FileSystemList';
import { StarredEmptyState } from '@/features/file-system/components/FileSystemList/StarredEmptyState';

export const StarredScreen = () => {
  const { t } = useTranslation();
  const { items, refetch, fetchNextPage, totalItems } = useStarredFiles();

  if (!items) return <Loader />;

  return (
    <ScreenContainer noTopPadding>
      <HeaderContainer>
        <Typography size={20} style={{ marginBlockStart: 8 }}>
          {t('file.starred')}
        </Typography>
      </HeaderContainer>
      <FileSystemList
        totalItems={totalItems}
        onRefresh={refetch}
        items={items}
        onLastItem={fetchNextPage}
        emptyStateComponent={<StarredEmptyState />}
      />
    </ScreenContainer>
  );
};
