import FontAwesome6 from '@expo/vector-icons/FontAwesome6';
import { useNavigation } from '@react-navigation/native';
import { useTranslation } from 'react-i18next';
import { Image, Pressable, StyleSheet } from 'react-native';

import { HeaderContainer } from '@/common/components/layout/HeaderContainer';
import { Typography } from '@/common/components/Typography';
import { useTheme } from '@/common/theme';
import { useAuthStore } from '@/features/auth/stores/authStore';

export const HomeHeader = () => {
  const { t } = useTranslation();
  const { colors } = useTheme();
  const navigation = useNavigation();
  const user = useAuthStore((store) => store.user);

  const handleNavigateToSearch = () => {
    navigation.navigate('Search');
  };

  const handleNavigateToProfile = () => {
    navigation.navigate('Profile');
  };

  return (
    <HeaderContainer
      headerRight={
        <Pressable
          onPress={handleNavigateToProfile}
          style={({ pressed }) => [
            styles.profileTrigger,
            pressed && styles.pressed,
          ]}
          testID="profile-trigger"
        >
          <Image
            style={styles.profileIcon}
            source={
              user
                ? { uri: user.picture }
                : require('@/common/images/avatar.png')
            }
            resizeMode="contain"
          />
        </Pressable>
      }
    >
      <Pressable
        onPress={handleNavigateToSearch}
        style={({ pressed }) => [
          styles.searchTrigger,
          { backgroundColor: colors.surfaceSubtle },
          pressed && styles.pressed,
        ]}
      >
        <FontAwesome6 name="magnifying-glass" size={16} color={colors.text} />
        <Typography numberOfLines={1}>{t('search.placeholder')}</Typography>
      </Pressable>
    </HeaderContainer>
  );
};

const styles = StyleSheet.create({
  searchTrigger: {
    paddingBlock: 8,
    paddingInline: 12,
    borderRadius: 16,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  profileTrigger: {
    width: 40,
    height: 40,
    borderRadius: 40,
    overflow: 'hidden',
  },
  profileIcon: {
    flex: 1,
    height: undefined,
    width: undefined,
  },
  pressed: {
    opacity: 0.6,
  },
});
