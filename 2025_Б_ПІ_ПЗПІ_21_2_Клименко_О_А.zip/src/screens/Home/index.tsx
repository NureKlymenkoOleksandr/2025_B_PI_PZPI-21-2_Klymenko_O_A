import { ScreenContainer } from '@/common/components/layout/ScreenContainer';
import { FolderContent } from '@/features/folder/components/FolderContent';

import { HomeHeader } from './Header';

const Screen = () => {
  return (
    <ScreenContainer noTopPadding>
      <FolderContent folderId="" />
    </ScreenContainer>
  );
};

export const HomeScreen = {
  Header: HomeHeader,
  Screen,
};
