import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { useQueryClient } from '@tanstack/react-query';
import { useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { Image, ScrollView, StyleSheet, View } from 'react-native';
import { Pressable, RefreshControl } from 'react-native-gesture-handler';
import switchTheme from 'react-native-theme-switch-animation';

import { ActionButton } from '@/common/components/ActionButton';
import { BottomSheetRef } from '@/common/components/bottom-sheet';
import { GoBackButton } from '@/common/components/layout/GoBackButton';
import { HeaderContainer } from '@/common/components/layout/HeaderContainer';
import { ScreenContainer } from '@/common/components/layout/ScreenContainer';
import { MenuItem } from '@/common/components/menu';
import { ThemeMenu } from '@/common/components/ThemeMenu';
import { Typography } from '@/common/components/Typography';
import { Theme, useTheme } from '@/common/theme';
import { ThemeIcon } from '@/common/theme/ThemeIcon';
import { useAuthStore } from '@/features/auth/stores/authStore';
import { useRootNavigation } from '@/navigation/hooks/useRootNavigation';

const Screen = () => {
  const queryClient = useQueryClient();
  const { selectedTheme, colors, changeTheme } = useTheme();
  const { t } = useTranslation();
  const signOut = useAuthStore((store) => store.signOut);
  const user = useAuthStore((store) => store.user);
  const themeButtonRef = useRef<View>(null);
  const themeMenuRef = useRef<BottomSheetRef>(null);
  const navigation = useRootNavigation();

  const handleSignOut = async () => {
    console.log('click');
    try {
      await signOut();
      queryClient.clear();
    } catch (e) {
      console.log(e);
    }
  };

  const handleThemeMenuOpen = () => themeMenuRef.current?.present();
  const handleSelectTheme = (theme: Theme) => {
    themeButtonRef.current?.measure((x1, y1, width, height, px, py) => {
      switchTheme({
        switchThemeFunction: () => {
          changeTheme(theme);
        },
        animationConfig: {
          type: 'circular',
          duration: 550,
          startingPoint: {
            cy: py + height / 2,
            cx: px + width / 2,
          },
        },
      });
    });
  };

  return (
    <ScreenContainer noTopPadding>
      <HeaderContainer headerLeft={<GoBackButton />}>
        <Typography size={20}>{t('screen.profile')}</Typography>
      </HeaderContainer>
      <ScrollView
        refreshControl={
          <RefreshControl
            colors={[colors.primary]}
            progressBackgroundColor={colors.surfaceSubtle}
            refreshing={false}
          />
        }
        contentContainerStyle={styles.scrollContent}
        style={styles.root}
      >
        <View
          style={[
            styles.section,
            styles.horizontalContainer,
            { backgroundColor: colors.surfaceSubtle },
          ]}
        >
          <Image
            source={
              user?.picture
                ? { uri: user.picture }
                : require('@/common/images/avatar.png')
            }
            defaultSource={require('@/common/images/avatar.png')}
            style={styles.photo}
          />
          <View style={styles.detailsWrapper}>
            <Typography>{user?.name}</Typography>
            <Typography>{user?.email}</Typography>
          </View>
          <View></View>
        </View>
        <View
          style={[
            styles.section,
            { backgroundColor: colors.surfaceSubtle },
            styles.themeSection,
          ]}
        >
          <MenuItem
            title={t('theme.theme')}
            secondaryAction={
              <ActionButton
                testID="theme-menu-trigger"
                ref={themeButtonRef}
                onPress={handleThemeMenuOpen}
              >
                <ThemeIcon
                  theme={selectedTheme}
                  testID={`current-theme-${selectedTheme.toLowerCase()}`}
                />
              </ActionButton>
            }
          />
          <MenuItem
            testID="language-menu-item"
            title={t('language.language')}
            onPress={() => navigation.navigate('Language')}
            secondaryAction={
              <View style={{ flexDirection: 'row', gap: 8 }}>
                <Typography testID="current-language">
                  {t('language.current')}
                </Typography>
                <MaterialIcons
                  name="chevron-right"
                  size={24}
                  color={colors.text}
                />
              </View>
            }
          />
        </View>
        <Pressable
          testID="sign-out-button"
          style={{
            marginTop: 'auto',
            alignSelf: 'stretch',
            borderWidth: 1,
            borderColor: 'red',
            alignItems: 'center',
            padding: 8,
            marginInline: 16,
            borderRadius: 8,
            flexDirection: 'row',
            gap: 8,
            justifyContent: 'center',
          }}
        >
          <Typography color={colors.text} onPress={handleSignOut}>
            {t('auth.signOut')}
          </Typography>
          <MaterialIcons name="logout" size={16} color={colors.text} />
        </Pressable>
      </ScrollView>
      <ThemeMenu onSelectTheme={handleSelectTheme} ref={themeMenuRef} />
    </ScreenContainer>
  );
};

const styles = StyleSheet.create({
  root: {
    marginBottom: 32,
  },
  scrollContent: {
    flex: 1,
  },
  section: {
    borderRadius: 8,
    marginInline: 16,
    padding: 16,
  },
  horizontalContainer: { flexDirection: 'row' },
  photo: {
    width: 64,
    height: 64,
    borderRadius: 64,
  },
  detailsWrapper: {
    flex: 1,
    marginInlineStart: 16,
    justifyContent: 'center',
    rowGap: 8,
  },
  themeSection: {
    marginBlockStart: 12,
    paddingInline: 12,
  },
  sectionTitle: {
    marginBlockEnd: 20,
  },
});

export const ProfileScreen = {
  Screen,
};
