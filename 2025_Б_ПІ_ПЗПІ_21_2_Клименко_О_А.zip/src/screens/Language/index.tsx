import { useTranslation } from 'react-i18next';
import { FlatList, StyleSheet, View } from 'react-native';

import { GoBackButton } from '@/common/components/layout/GoBackButton';
import { HeaderContainer } from '@/common/components/layout/HeaderContainer';
import { ScreenContainer } from '@/common/components/layout/ScreenContainer';
import { MenuItem } from '@/common/components/menu';
import { Radio } from '@/common/components/Radio';
import { Typography } from '@/common/components/Typography';
import { LANGUAGES } from '@/lib/i18n';
import { changeLanguage } from '@/lib/i18n';

const Screen = () => {
  const { t, i18n } = useTranslation();

  const handleLanguageSelect = (languageCode: 'en' | 'uk') => {
    changeLanguage(languageCode);
  };

  return (
    <ScreenContainer noTopPadding>
      <HeaderContainer headerLeft={<GoBackButton />}>
        <Typography size={20}>{t('screen.language')}</Typography>
      </HeaderContainer>
      <FlatList
        data={LANGUAGES}
        keyExtractor={(item) => item.code}
        renderItem={({ item }) => (
          <MenuItem
            testID={`language-option-${item.code}`}
            title={item.name}
            onPress={() => handleLanguageSelect(item.code)}
            secondaryAction={
              <View style={styles.radioContainer}>
                <Radio selected={i18n.language === item.code} />
              </View>
            }
          />
        )}
        contentContainerStyle={styles.list}
        ItemSeparatorComponent={() => <View style={styles.separator} />}
      />
    </ScreenContainer>
  );
};

const styles = StyleSheet.create({
  list: {
    padding: 16,
  },
  separator: {
    height: 8,
  },
  radioContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
});

export const LanguageScreen = {
  Screen,
};
