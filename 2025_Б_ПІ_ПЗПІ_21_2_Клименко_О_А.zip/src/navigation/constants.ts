import { NativeStackNavigationOptions } from '@react-navigation/native-stack';

export const INTERMEDIATE_NAVIGATOR_SCREEN_OPTIONS: NativeStackNavigationOptions =
  {
    headerShadowVisible: false,
  };

export const DEFAULT_SCREEN_OPTIONS: NativeStackNavigationOptions = {
  headerShadowVisible: false,
  animation: 'fade_from_bottom',
  animationMatchesGesture: true,
};

export enum Route {
  TABS = 'Tabs',
  SEARCH = 'Search',
  FOLDER = 'Folder',
  HOME = 'Home',
  FAVOURITES = 'Favourites',
}
