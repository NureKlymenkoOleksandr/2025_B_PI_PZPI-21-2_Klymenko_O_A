import { createStaticNavigation } from '@react-navigation/native';
import * as Linking from 'expo-linking';

import {
  DarkNavigationTheme,
  LightNavigationTheme,
  useTheme,
} from '@/common/theme';

import { RootNavigator } from './navigators/RootNavigator';

const Navigation = createStaticNavigation(RootNavigator);

export const AppNavigation = () => {
  const { theme } = useTheme();

  return (
    <Navigation
      theme={theme === 'dark' ? DarkNavigationTheme : LightNavigationTheme}
    />
  );
};
