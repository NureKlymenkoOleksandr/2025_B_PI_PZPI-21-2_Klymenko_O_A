import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';

import type { RootStackParamList } from '@/navigation/navigators/RootNavigator';

type RootStackNavigationProp = NativeStackNavigationProp<RootStackParamList>;

export const useRootNavigation = () => useNavigation<RootStackNavigationProp>();
