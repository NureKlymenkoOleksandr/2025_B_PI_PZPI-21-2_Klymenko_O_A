import { useNavigation } from '@react-navigation/native';

export const useIsInTabNavigator = () => {
  const navigation = useNavigation();

  let currentNavigation = navigation;
  while (currentNavigation) {
    const state = currentNavigation.getState();
    if (state?.type === 'tab') {
      return true;
    }

    currentNavigation = currentNavigation.getParent();
  }

  return false;
};
