import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';

import type { FoldersStackParamList } from '@/navigation/navigators/FoldersNavigator';

type FoldersStackNavigationProp =
  NativeStackNavigationProp<FoldersStackParamList>;

export const useFoldersNavigation = () =>
  useNavigation<FoldersStackNavigationProp>();
