import { useNavigation } from '@react-navigation/native';
import { useEffect } from 'react';

export const useScreenValueSetter = <T>(
  value: T,
  setter: (folderId: T | null) => void,
) => {
  const navigation = useNavigation();

  useEffect(() => {
    const unsubFocus = navigation.addListener('focus', () => {
      setter(value);
    });

    setter(value);

    return () => {
      unsubFocus();
      setter(null);
    };
  }, [value, setter]);
};
