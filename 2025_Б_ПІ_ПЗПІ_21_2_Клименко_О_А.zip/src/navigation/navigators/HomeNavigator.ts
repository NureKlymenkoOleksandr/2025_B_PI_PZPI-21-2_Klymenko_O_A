import { createNativeStackNavigator } from '@react-navigation/native-stack';

import { UploadFABLayout } from '@/common/components/layout/UploadFABLayout';
import { DEFAULT_SCREEN_OPTIONS } from '@/navigation/constants';
import { HomeScreen } from '@/screens/Home';

import { FoldersNavigator } from './FoldersNavigator';

export const HomeNavigator = createNativeStackNavigator({
  screens: {
    Root: {
      screen: HomeScreen.Screen,
      options: {
        header: HomeScreen.Header,
      },
    },
    Folders: {
      screen: FoldersNavigator,
      options: {
        headerShown: false,
      },
    },
  },
  layout: UploadFABLayout,
  screenOptions: DEFAULT_SCREEN_OPTIONS,
});
