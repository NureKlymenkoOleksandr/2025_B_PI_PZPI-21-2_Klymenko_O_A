import { StaticParamList } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import { DEFAULT_SCREEN_OPTIONS } from '@/navigation/constants';
import { FolderHeader, FolderMoveScreen, FolderScreen } from '@/screens/folder';

export const FoldersNavigator = createNativeStackNavigator({
  screens: {
    Folder: {
      screen: FolderScreen,
      options: {
        header: FolderHeader,
      },
    },
    FolderMove: {
      screen: FolderMoveScreen,
      options: {
        header: FolderHeader,
      },
    },
  },
  screenOptions: DEFAULT_SCREEN_OPTIONS,
});

export type FoldersStackParamList = StaticParamList<typeof FoldersNavigator>;
