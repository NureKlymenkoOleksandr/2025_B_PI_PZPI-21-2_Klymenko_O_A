import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

import { TabIcon } from '@/common/components/TabIcon';
import { TabLabel } from '@/common/components/TabLabel';
import { HomeIcon } from '@/common/icons/HomeIcon';
import { StarFavouriteIcon } from '@/common/icons/StarFavouriteIcon';
import { UploadIcon } from '@/common/icons/UploadIcon';
import { SortingParamsProvider } from '@/common/stores/sortingParamsStore';
import { StarredScreen } from '@/screens/Starred';
import { UploadsScreen } from '@/screens/Uploads';

import { HomeNavigator } from './HomeNavigator';

export const TabsNavigator = createBottomTabNavigator({
  screens: {
    Home: {
      screen: HomeNavigator,
      options: {
        tabBarIcon: (props) => <TabIcon icon={HomeIcon} {...props} />,
        tabBarLabel: ({ color }) => (
          <TabLabel color={color} label="screen.home" />
        ),
      },
      layout: ({ children }) => (
        <SortingParamsProvider persistanceKey="home">
          {children}
        </SortingParamsProvider>
      ),
    },
    Favourites: {
      screen: StarredScreen,
      options: {
        tabBarIcon: (props) => <TabIcon icon={StarFavouriteIcon} {...props} />,
        tabBarLabel: ({ color }) => (
          <TabLabel color={color} label="screen.starred" />
        ),
      },
      layout: ({ children }) => (
        <SortingParamsProvider persistanceKey="favourites">
          {children}
        </SortingParamsProvider>
      ),
    },
    Uploads: {
      screen: UploadsScreen,
      options: {
        tabBarIcon: (props) => <TabIcon icon={UploadIcon} {...props} />,
        tabBarLabel: ({ color }) => (
          <TabLabel color={color} label="screen.uploads" />
        ),
      },
    },
  },

  screenOptions: {
    animation: 'shift',
    tabBarStyle: {
      height: 72,
    },
    headerShown: false,
    headerShadowVisible: false,
  },
});
