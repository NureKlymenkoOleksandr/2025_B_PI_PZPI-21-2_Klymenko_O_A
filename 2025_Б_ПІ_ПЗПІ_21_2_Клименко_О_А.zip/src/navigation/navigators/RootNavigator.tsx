import { StaticParamList } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import { AppLayout } from '@/common/components/layout/AppLayout';
import { FileSystemActionLayout } from '@/common/components/layout/FileSystemActionLayout';
import { UploadFABLayout } from '@/common/components/layout/UploadFABLayout';
import { SortingParamsProvider } from '@/common/stores/sortingParamsStore';
import { useIsAuthenticated } from '@/features/auth/hooks/useIsAuthenticated';
import { useIsNotAuthenticated } from '@/features/auth/hooks/useIsNotAuthenticated';
import {
  DEFAULT_SCREEN_OPTIONS,
  INTERMEDIATE_NAVIGATOR_SCREEN_OPTIONS,
} from '@/navigation/constants';
import { AuthScreen } from '@/screens/Auth';
import { FileScreen } from '@/screens/File';
import { LanguageScreen } from '@/screens/Language';
import { ProfileScreen } from '@/screens/Profile';
import { SearchScreen } from '@/screens/Search';

import { FoldersNavigator } from './FoldersNavigator';
import { TabsNavigator } from './TabsNavigator';

export const RootNavigator = createNativeStackNavigator({
  layout: AppLayout,
  screens: {
    Auth: {
      if: useIsNotAuthenticated,
      screen: AuthScreen,
      options: {
        headerShown: false,
      },
    },
  },
  groups: {
    Authenticated: {
      if: useIsAuthenticated,
      screens: {
        Tabs: {
          screen: TabsNavigator,
          options: {
            headerShown: false,
          },
        },
        Search: {
          layout: ({ children }) => (
            <SortingParamsProvider>{children}</SortingParamsProvider>
          ),
          screen: SearchScreen.Screen,
          options: {
            header: SearchScreen.Header,
            animation: 'fade',
          },
        },
        Folders: {
          screen: FoldersNavigator,
          options: {
            headerShown: false,
          },
          layout: ({ children }) => (
            <UploadFABLayout>
              <SortingParamsProvider>{children}</SortingParamsProvider>
            </UploadFABLayout>
          ),
        },
        FoldersMove: {
          screen: FoldersNavigator,
          options: {
            headerShown: false,
            animation: 'slide_from_bottom',
          },
          layout: ({ children }) => (
            <FileSystemActionLayout>
              <SortingParamsProvider>{children}</SortingParamsProvider>
            </FileSystemActionLayout>
          ),
        },
        Profile: {
          screen: ProfileScreen.Screen,
          options: {
            headerShown: false,
          },
        },
        File: {
          screen: FileScreen,
          options: {
            headerShown: false,
          },
        },
        Language: {
          screen: LanguageScreen.Screen,
          options: {
            headerShown: false,
          },
        },
      },
    },
  },
  screenOptions: {
    ...INTERMEDIATE_NAVIGATOR_SCREEN_OPTIONS,
    ...DEFAULT_SCREEN_OPTIONS,
  },
});

export type RootStackParamList = StaticParamList<typeof RootNavigator>;

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace ReactNavigation {
    // eslint-disable-next-line @typescript-eslint/no-empty-object-type
    interface RootParamList extends RootStackParamList {}
  }
}
