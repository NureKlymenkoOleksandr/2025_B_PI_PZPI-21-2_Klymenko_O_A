import * as SplashScreen from 'expo-splash-screen';
import { StatusBar } from 'expo-status-bar';
import { useEffect } from 'react';

import { AppProviders } from '@/common/components/AppProviders';
import { AppNavigation } from '@/navigation';

SplashScreen.preventAutoHideAsync();

export default function App() {
  useEffect(() => {
    SplashScreen.hide();
  }, []);

  return (
    <AppProviders>
      <StatusBar />
      <AppNavigation />
    </AppProviders>
  );
}
