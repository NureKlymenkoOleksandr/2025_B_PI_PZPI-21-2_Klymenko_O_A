import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { render } from '@testing-library/react-native';
import { ReactElement } from 'react';

export type TestScreenParams = Record<string, unknown>;

export interface NavigationTestOptions {
  initialParams?: TestScreenParams;
  screenOptions?: unknown;
}

const Stack = createNativeStackNavigator();

export function renderWithNavigation(ui: ReactElement) {
  const TestScreen = () => ui;

  const TestNavigator = () => (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="TestScreen" component={TestScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );

  return render(<TestNavigator />);
}
