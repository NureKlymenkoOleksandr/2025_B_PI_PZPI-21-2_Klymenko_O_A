import { FileDownloadResult, FileWithConnection } from '@/features/file/types';
import { File } from '@/features/file-system/types';

export const createMockFile = (overrides?: Partial<File>): File => ({
  id: 'file-123',
  name: 'test-file.pdf',
  extension: 'pdf',
  createdAt: new Date().toString(),
  updatedAt: new Date().toString(),
  parentDirectoryID: '1',
  public: false,
  size: 128,
  starred: false,
  ...overrides,
});

export const createMockFileWithConnection = (
  overrides?: Partial<FileWithConnection>,
): FileWithConnection => ({
  ...createMockFile(),
  host: 'https://api.example.com',
  connectionID: 'conn-456',
  ...overrides,
});

export const createMockDownloadResponse = (
  overrides = {},
): FileDownloadResult => ({
  uri: 'file://downloaded/file.pdf',
  mimeType: 'application/pdf',
  originalFile: createMockFileWithConnection(),
  ...overrides,
});
