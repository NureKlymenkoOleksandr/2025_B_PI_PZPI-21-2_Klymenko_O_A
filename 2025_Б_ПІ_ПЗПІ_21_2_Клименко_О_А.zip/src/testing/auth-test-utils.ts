import { User } from '@/common/types/user';
import { useAuthStore } from '@/features/auth/stores/authStore';

const TEST_USER: User = {
  id: 'test-user-id',
  name: 'Test User',
  email: 'test@example.com',
  picture: 'https://example.com/avatar.jpg',
};

export const setupTestAuth = async () => {
  const accessToken =
    process.env.EXPO_PUBLIC_TEST_ACCESS_TOKEN || 'test-access-token';
  const refreshToken =
    process.env.EXPO_PUBLIC_TEST_REFRESH_TOKEN || 'test-refresh-token';

  useAuthStore.setState({
    accessToken,
    refreshToken,
    user: TEST_USER,
    isAuthenticated: true,
    isReady: true,
    error: null,
  });
};

export const clearTestAuth = async () => {
  useAuthStore.setState({
    accessToken: null,
    refreshToken: null,
    user: null,
    isAuthenticated: false,
    isReady: true,
    error: null,
  });
};
