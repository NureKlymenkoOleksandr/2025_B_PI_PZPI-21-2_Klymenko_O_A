import {
  GoogleSignin,
  isErrorWithCode,
  isSuccessResponse,
  statusCodes,
  User,
} from '@react-native-google-signin/google-signin';

import { GOOGLE_CLIENT_ID } from '@/config/env';

export const configureGoogleSignIn = () => {
  GoogleSignin.configure({
    webClientId: GOOGLE_CLIENT_ID,
    offlineAccess: true,
  });
};

export const signIn = async () => {
  try {
    await GoogleSignin.hasPlayServices();
    const response = await GoogleSignin.signIn();

    if (isSuccessResponse(response)) {
      return { authUser: response.data, error: null };
    } else {
      return { authUser: null, error: null };
    }
  } catch (error) {
    const errorResponse = {
      authUser: null,
      error: 'Something went wrong. Please try again.',
    };

    if (isErrorWithCode(error)) {
      switch (error.code) {
        case statusCodes.IN_PROGRESS:
          errorResponse.error = 'Sign in is already in progress. Please wait.';
          break;
        case statusCodes.PLAY_SERVICES_NOT_AVAILABLE:
          errorResponse.error =
            'Google Play Services not available or outdated';
          break;
      }
    }

    return errorResponse;
  }
};

export const restoreAuth = async (): Promise<User | null> => {
  try {
    if (GoogleSignin.hasPreviousSignIn()) {
      const response = await GoogleSignin.signInSilently();
      return response.data;
    }
  } catch (error) {
    console.error('Restore auth error:', error);
  }

  return null;
};

export const getAuthUser = () => GoogleSignin.getCurrentUser();

export const signOut = async () => {
  try {
    await GoogleSignin.signOut();
    return { success: true, error: null };
  } catch {
    return { success: false, error: 'Failed to sign out' };
  }
};

export const revokeAccess = async () => {
  try {
    await GoogleSignin.revokeAccess();
    await GoogleSignin.signOut();
    return { success: true, error: null };
  } catch {
    return { success: false, error: 'Failed to revoke access' };
  }
};
