import axios from 'axios';

import { AUTH_BASE_URL } from '@/config/env';

export const authClient = axios.create({
  baseURL: AUTH_BASE_URL,
});
