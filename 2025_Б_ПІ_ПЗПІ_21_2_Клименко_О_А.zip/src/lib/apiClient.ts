import axios from 'axios';

import { API_BASE_URL } from '@/config/env';

export const apiClient = axios.create({
  baseURL: API_BASE_URL,
});

export const configureAuthenticationInterceptors = ({
  getAccessToken,
  refreshAccessToken,
  signOut,
}: {
  getAccessToken: () => string | null;
  refreshAccessToken: () => Promise<boolean>;
  signOut: () => Promise<void>;
}) => {
  apiClient.interceptors.request.use(
    (config) => {
      const accessToken = getAccessToken();
      console.log(accessToken);

      if (accessToken) {
        config.headers['Authorization'] = `Bearer ${accessToken}`;
      }
      return config;
    },
    (error) => Promise.reject(error),
  );

  apiClient.interceptors.response.use(
    (response) => response,
    async (error) => {
      const originalRequest = error.config;

      if (error.response?.status === 401 && !originalRequest._retry) {
        originalRequest._retry = true;

        const refreshSuccess = await refreshAccessToken();
        if (refreshSuccess) {
          const newToken = getAccessToken();
          originalRequest.headers['Authorization'] = `Bearer ${newToken}`;
          return apiClient(originalRequest);
        } else {
          await signOut();
        }
      }

      return Promise.reject(error);
    },
  );
};
