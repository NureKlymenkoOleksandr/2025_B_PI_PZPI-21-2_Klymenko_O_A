import 'fast-text-encoding';
import 'react-native-url-polyfill/auto';
