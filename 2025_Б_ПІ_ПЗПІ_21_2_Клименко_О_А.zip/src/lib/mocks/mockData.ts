export const folders = [
  {
    id: '4a824083-a043-4c30-93e0-29382850861e',
    name: 'Folder 1',
    path: ['/', 'Folder 1'],
  },
  {
    id: '77c0e9d6-9825-4314-97de-2d625b49e12d',
    name: 'Folder 2',
    path: ['/', 'Folder 2'],
  },
  {
    id: '692f3920-9717-4c4a-9b51-77f48ec3a941',
    name: 'photo1.jpg',
    extension: 'jpg',
    src: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
  },
  {
    id: 'aeba89a9-bd3a-4dda-8270-8b3b3c98bce2',
    name: 'photo2.jpg',
    extension: 'jpg',
    src: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
  },
];
