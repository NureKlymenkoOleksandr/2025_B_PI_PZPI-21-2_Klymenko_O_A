import { delay, http, HttpResponse } from 'msw';

import { API_BASE_URL } from '@/config/env';

import { folders } from './mockData';

const baseUrl = (path: string) => new URL(path, API_BASE_URL).href;

export const handlers = [
  http.get(baseUrl('folders/:folderId'), () => {
    return HttpResponse.json({
      id: 'c7b3d8e0-5e0b-4b0f-8b3a-3b9f4b3d3b3d',
      name: 'My folder',
    });
  }),
  http.get(baseUrl('folders/:folderId/content'), async () => {
    await delay(1000);
    return HttpResponse.json(folders);
  }),
];
