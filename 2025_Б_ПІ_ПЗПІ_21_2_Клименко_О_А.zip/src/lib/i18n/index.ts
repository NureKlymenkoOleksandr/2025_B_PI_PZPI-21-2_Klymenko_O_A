import * as Localization from 'expo-localization';
import i18n, { ResourceLanguage } from 'i18next';
import { initReactI18next } from 'react-i18next';

import { Storage } from '@/lib/storage';

import translationEn from './locales/en/translation.json';
import translationUk from './locales/uk/translation.json';

const LANGUAGE_STORAGE_KEY = 'app_language';

export const LANGUAGES = [
  { code: 'en', name: 'English' },
  { code: 'uk', name: 'Українська' },
] as const;

export type Language = (typeof LANGUAGES)[number]['code'];

const resources: Record<Language, ResourceLanguage> = {
  en: {
    translation: translationEn,
  },
  uk: {
    translation: translationUk,
  },
};

export const changeLanguage = async (language: Language) => {
  i18n.changeLanguage(language);
  await Storage.setItem(LANGUAGE_STORAGE_KEY, language);
};

const getDeviceLanguage = () => {
  const deviceLocales = Localization.getLocales();

  for (const deviceLocale of deviceLocales) {
    const { languageCode, languageTag } = deviceLocale;
    if (languageTag in resources) {
      return languageTag;
    } else if (languageCode && languageCode in resources) {
      return languageCode;
    }
  }
};

const initI18n = async () => {
  let selectedLanguage = 'en';

  try {
    const savedLanguage = await Storage.getItem<string | null>(
      LANGUAGE_STORAGE_KEY,
    );

    if (!savedLanguage) {
      selectedLanguage = getDeviceLanguage() ?? selectedLanguage;
    } else {
      selectedLanguage = savedLanguage;
    }

    await Storage.setItem(LANGUAGE_STORAGE_KEY, selectedLanguage);
  } catch (error) {
    console.error('Error retrieving the selected language:', error);
  } finally {
    await i18n.use(initReactI18next).init({
      resources,
      debug: process.env.NODE_ENV === 'development',
      lng: selectedLanguage,
      fallbackLng: 'en',
      interpolation: {
        escapeValue: false,
      },
      react: {
        useSuspense: false,
      },
    });
  }
};

initI18n();
