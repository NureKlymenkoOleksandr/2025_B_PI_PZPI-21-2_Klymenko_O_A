import AsyncStorage from '@react-native-async-storage/async-storage';
import * as SecureStore from 'expo-secure-store';
import { JsonBodyType } from 'msw';

export const Storage = {
  getItem: async <T>(key: string) => {
    try {
      const storageValue = await AsyncStorage.getItem(key);

      return (storageValue && JSON.parse(storageValue)) as T | null;
    } catch (error) {
      throw new Error(`Error reading key (${key}) from storage: ${error}`);
    }
  },
  setItem: async (key: string, value: JsonBodyType) => {
    try {
      const jsonValue = JSON.stringify(value);

      await AsyncStorage.setItem(key, jsonValue);
    } catch (error) {
      throw new Error(`Error setting key (${key}) to storage: ${error}`);
    }
  },
};

export const SecureStorage = {
  getItem: (key: string) => SecureStore.getItem(key),
  setItem: (key: string, value: string) => SecureStore.setItem(key, value),
  removeItem: (key: string) => SecureStore.deleteItemAsync(key),
};
