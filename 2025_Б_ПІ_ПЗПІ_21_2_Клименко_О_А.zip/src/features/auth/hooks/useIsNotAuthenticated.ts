import { useAuthStore } from '@/features/auth/stores/authStore';

export const useIsNotAuthenticated = () => {
  return !useAuthStore((store) => store.isAuthenticated);
};
