import { useAuthStore } from '@/features/auth/stores/authStore';

export const useIsAuthenticated = () => {
  return useAuthStore((store) => store.isAuthenticated);
};
