import { User } from '@/common/types/user';

export type JwtPayload = User & {
  sub: string;
};

export type AuthenticationResponse = {
  ok: boolean;
  body?: {
    accessToken: string;
    refreshToken: string;
  };
  error?: string;
};
