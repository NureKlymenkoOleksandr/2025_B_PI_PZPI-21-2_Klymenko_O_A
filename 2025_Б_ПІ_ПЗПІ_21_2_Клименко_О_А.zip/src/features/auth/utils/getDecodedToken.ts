import { jwtDecode } from 'jwt-decode';

import { JwtPayload } from '@/features/auth/types';

export const getDecodedToken = (token: string) => {
  const { sub: _, ...rest } = jwtDecode<JwtPayload>(token);
  return rest;
};
