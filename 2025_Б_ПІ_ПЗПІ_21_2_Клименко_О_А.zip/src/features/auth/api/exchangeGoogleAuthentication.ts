import { AuthenticationResponse } from '@/features/auth/types';
import { authClient } from '@/lib/authClient';

export const exchangeGoogleAuthentication = async (googleJWT: string) => {
  const { data } = await authClient.post<AuthenticationResponse>('/google', {
    googleJWT,
  });

  const { accessToken, refreshToken } = data.body ?? {};

  return { accessToken, refreshToken, error: data.error };
};
