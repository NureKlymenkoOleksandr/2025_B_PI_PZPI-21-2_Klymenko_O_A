import { AuthenticationResponse } from '@/features/auth/types';
import { authClient } from '@/lib/authClient';

export const refreshAuthentication = async (token: string) => {
  const { data } = await authClient.post<AuthenticationResponse>('/refresh', {
    refreshToken: token,
  });

  const { accessToken, refreshToken } = data.body ?? {};

  return { accessToken, refreshToken, error: data.error };
};
