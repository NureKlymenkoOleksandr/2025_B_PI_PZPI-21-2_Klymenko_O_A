import { Image } from 'expo-image';
import { useTranslation } from 'react-i18next';
import { Pressable, StyleSheet } from 'react-native';

import { Typography } from '@/common/components/Typography';
// import { useTheme } from '@/common/theme';
import { useAuthStore } from '@/features/auth/stores/authStore';

export const GoogleButton = () => {
  const { t } = useTranslation();
  // const theme = useTheme();
  const signInWithGoogle = useAuthStore((store) => store.signInWithGoogle);

  return (
    <Pressable
      style={styles.root}
      onPress={signInWithGoogle}
      testID="google-login-button"
    >
      <Image
        source={require('@/features/auth/assets/google-icon.webp')}
        style={styles.googleIcon}
        contentFit="contain"
      />
      <Typography color={'#121212'} style={styles.text} size={16}>
        {t('auth.google')}
      </Typography>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  // root: {
  //   padding: 8,
  //   borderRadius: 9999,
  //   backgroundColor: '#3C3C3C',
  //   flexDirection: 'row',
  //   borderColor: '#121212',
  //   borderWidth: 2,
  //   alignItems: 'center',
  //   alignSelf: 'center',
  // },
  // googleIcon: {
  //   backgroundColor: 'white',
  //   borderRadius: 64,
  //   height: 52,
  //   width: 52,
  // },
  root: {
    width: '100%',
    padding: 8,
    borderRadius: 9999,
    backgroundColor: '#FFFFFF',
    borderColor: '#121212',
    borderWidth: 1,
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'center',
  },
  googleIcon: {
    backgroundColor: '#F2F2F2',
    borderRadius: 64,
    height: 52,
    width: 52,
  },
  text: {
    marginInline: 16,
  },
});
