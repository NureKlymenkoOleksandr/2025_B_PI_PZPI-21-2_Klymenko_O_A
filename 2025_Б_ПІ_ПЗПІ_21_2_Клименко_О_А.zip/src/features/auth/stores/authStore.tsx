import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';

import { User } from '@/common/types/user';
import { exchangeGoogleAuthentication } from '@/features/auth/api/exchangeGoogleAuthentication';
import { refreshAuthentication } from '@/features/auth/api/refreshAuthentication';
import { getDecodedToken } from '@/features/auth/utils/getDecodedToken';
import { configureAuthenticationInterceptors } from '@/lib/apiClient';
import {
  signIn as googleSignIn,
  signOut as googleSignOut,
} from '@/lib/googleAuth';
import { SecureStorage } from '@/lib/storage';

type AuthState = {
  accessToken: string | null;
  refreshToken: string | null;
  isAuthenticated: boolean;
  isReady: boolean;
  user: User | null;
  error: string | null;
};

type AuthStore = AuthState & {
  finishHydration: () => void;
  signInWithGoogle: () => Promise<void>;
  signOut: () => Promise<void>;
  refreshAccessToken: () => Promise<boolean>;
};

const STORAGE_KEY = 'auth-storage';

export const useAuthStore = create<AuthStore>()(
  persist(
    (set, get) => ({
      accessToken: null,
      refreshToken: null,
      isAuthenticated: false,
      isReady: false,
      user: null,
      error: null,

      refreshAccessToken: async () => {
        try {
          const { refreshToken } = get();
          if (!refreshToken) return false;

          const response = await refreshAuthentication(refreshToken);

          const { accessToken: newAccessToken, refreshToken: newRefreshToken } =
            response;

          if (!newAccessToken || !newRefreshToken) return false;

          const decoded = getDecodedToken(newAccessToken);

          set({
            accessToken: newAccessToken,
            refreshToken: newRefreshToken,
            user: decoded,
            isAuthenticated: true,
          });

          return true;
        } catch (error) {
          console.error('Token refresh error:', error);
          set({
            accessToken: null,
            refreshToken: null,
            user: null,
            isAuthenticated: false,
          });
          return false;
        }
      },

      signInWithGoogle: async () => {
        try {
          const { authUser, error } = await googleSignIn();

          if (error) {
            set({ error });
            return;
          }

          if (authUser?.idToken) {
            const response = await exchangeGoogleAuthentication(
              authUser.idToken,
            );

            const { accessToken, refreshToken } = response;

            if (accessToken) {
              const decoded = getDecodedToken(accessToken);

              console.log(accessToken, '    ', refreshToken);

              set({
                accessToken,
                refreshToken,
                user: decoded,
                isAuthenticated: true,
                error: null,
              });
            }
          }
        } catch (error) {
          await googleSignOut();
          console.error('Sign in error:', JSON.stringify(error));
          set({ error: 'Failed to sign in with Google' });
        }
      },

      signOut: async () => {
        googleSignOut();
        set({
          accessToken: null,
          refreshToken: null,
          user: null,
          isAuthenticated: false,
          error: null,
        });
      },

      finishHydration: () => {
        set((state) => ({
          isReady: true,
          isAuthenticated: !!state.accessToken,
          user: state.accessToken ? getDecodedToken(state.accessToken) : null,
        }));
      },
    }),
    {
      name: STORAGE_KEY,
      partialize: (state) => ({
        accessToken: state.accessToken,
        refreshToken: state.refreshToken,
      }),
      storage: createJSONStorage(() => SecureStorage),
      onRehydrateStorage: () => (state) => {
        state?.finishHydration();
      },
    },
  ),
);

configureAuthenticationInterceptors({
  getAccessToken: () => useAuthStore.getState().accessToken,
  refreshAccessToken: () => useAuthStore.getState().refreshAccessToken(),
  signOut: () => useAuthStore.getState().signOut(),
});
