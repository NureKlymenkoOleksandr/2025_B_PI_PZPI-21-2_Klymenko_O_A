import { useEffect } from 'react';

import { useFileUploadStore } from '@/features/file/context';
import { selectDocuments } from '@/features/file/services/documentPickerService';
import {
  captureMediaWithCamera,
  selectMediaFromLibrary,
} from '@/features/file/services/imagePickerService';
import { FileInfo, FileUploadType } from '@/features/file/types';
import { isNativeUpload } from '@/features/file/utils/isNativeUpload';
import { useFileSystemActionStore } from '@/features/file-system/stores/fileSystemActionStore';

export const useNativeFileUpload = () => {
  const setCurrentAction = useFileSystemActionStore(
    (store) => store.setCurrentAction,
  );
  const {
    currentUploadType,
    setPendingFiles,
    setCurrentUploadType,
    startUpload,
  } = useFileUploadStore((store) => ({
    currentUploadType: store.currentUploadType,
    setPendingFiles: store.setPendingFiles,
    setCurrentUploadType: store.setCurrentUploadType,

    startUpload: store.startUpload,
  }));

  const shouldHandleUpload =
    currentUploadType && isNativeUpload(currentUploadType);

  const handleUpload = async () => {
    let files: FileInfo[] | null = [];

    switch (currentUploadType) {
      case FileUploadType.LIBRARY:
        files = await selectMediaFromLibrary();
        break;
      case FileUploadType.CAMERA:
        const captured = await captureMediaWithCamera();
        files = captured ? [captured] : [];
        break;
      case FileUploadType.DOCUMENT:
        files = await selectDocuments();
        break;
    }
    if (files) {
      setPendingFiles(files);

      files.forEach((file) => {
        startUpload(file);
      });
    }

    setCurrentUploadType(null);
    setCurrentAction(null);
  };

  useEffect(() => {
    if (shouldHandleUpload) {
      handleUpload();
    }
  }, [currentUploadType]);
};
