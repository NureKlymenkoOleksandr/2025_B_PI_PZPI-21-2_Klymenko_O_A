import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { renderHook, act } from '@testing-library/react-native';
import React from 'react';

import { FileProvider, useFileUploadStore } from '@/features/file/context';
import { useNativeFileUpload } from '@/features/file/hooks/useNativeFileUpload';
import { selectDocuments } from '@/features/file/services/documentPickerService';
import { FileService } from '@/features/file/services/fileService';
import { FileUploadService } from '@/features/file/services/fileUploadService';
import {
  captureMediaWithCamera,
  selectMediaFromLibrary,
} from '@/features/file/services/imagePickerService';
import { FileUploadType } from '@/features/file/types';
import { FileSystemActionProvider } from '@/features/file-system/stores/fileSystemActionStore';

// Mock the file picker services
jest.mock('@/features/file/services/documentPickerService', () => ({
  selectDocuments: jest.fn(),
}));

jest.mock('@/features/file/services/imagePickerService', () => ({
  captureMediaWithCamera: jest.fn(),
  selectMediaFromLibrary: jest.fn(),
}));

const TestComponent = () => {
  useNativeFileUpload();
  const { setCurrentUploadType } = useFileUploadStore((store) => ({
    setCurrentUploadType: store.setCurrentUploadType,
  }));
  return { setCurrentUploadType };
};

const renderWithProvider = (
  fileService: FileService,
  fileUploadService: FileUploadService,
) => {
  return renderHook(() => TestComponent(), {
    wrapper: ({ children }) => (
      <QueryClientProvider client={new QueryClient()}>
        <FileSystemActionProvider>
          <FileProvider
            fileService={fileService}
            fileUploadService={fileUploadService}
          >
            {children}
          </FileProvider>
        </FileSystemActionProvider>
      </QueryClientProvider>
    ),
  });
};

describe('useNativeFileUpload', () => {
  const mockFileService = {
    saveLocalFile: jest.fn(),
    closeFileConnection: jest.fn(),
  } as unknown as jest.Mocked<FileService>;

  const mockFileUploadService = {
    uploadFile: jest.fn(),
    cancelUpload: jest.fn(),
  } as unknown as jest.Mocked<FileUploadService>;

  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('Library upload', () => {
    it('should handle library upload type', async () => {
      const { result } = renderWithProvider(
        mockFileService,
        mockFileUploadService,
      );

      await act(async () => {
        result.current.setCurrentUploadType(FileUploadType.LIBRARY);
      });

      expect(selectMediaFromLibrary).toHaveBeenCalled();
    });
  });

  describe('Camera upload', () => {
    it('should handle camera upload type', async () => {
      const { result } = renderWithProvider(
        mockFileService,
        mockFileUploadService,
      );

      await act(async () => {
        result.current.setCurrentUploadType(FileUploadType.CAMERA);
      });

      expect(captureMediaWithCamera).toHaveBeenCalled();
    });
  });

  describe('Document upload', () => {
    it('should handle document upload type', async () => {
      const { result } = renderWithProvider(
        mockFileService,
        mockFileUploadService,
      );

      await act(async () => {
        result.current.setCurrentUploadType(FileUploadType.DOCUMENT);
      });

      expect(selectDocuments).toHaveBeenCalled();
    });
  });

  describe('Error handling', () => {
    it('should handle null files from picker', async () => {
      (selectMediaFromLibrary as jest.Mock).mockResolvedValue(null);

      const { result } = renderWithProvider(
        mockFileService,
        mockFileUploadService,
      );

      await act(async () => {
        result.current.setCurrentUploadType(FileUploadType.LIBRARY);
      });

      expect(mockFileUploadService.uploadFile).not.toHaveBeenCalled();
    });

    it('should handle empty files array from picker', async () => {
      (selectMediaFromLibrary as jest.Mock).mockResolvedValue([]);

      const { result } = renderWithProvider(
        mockFileService,
        mockFileUploadService,
      );

      await act(async () => {
        result.current.setCurrentUploadType(FileUploadType.LIBRARY);
      });

      expect(mockFileUploadService.uploadFile).not.toHaveBeenCalled();
    });
  });
});
