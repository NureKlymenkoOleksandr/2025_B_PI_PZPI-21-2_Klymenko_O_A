import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { renderHook, act } from '@testing-library/react-native';
import React from 'react';

import { FileProvider } from '@/features/file/context';
import { useFileDownload } from '@/features/file/hooks/useFileDownload';
import { FileDownloadService } from '@/features/file/services/fileDownloadService';
import { FileService } from '@/features/file/services/fileService';
import {
  FileDownloadResult,
  FileNetworkTaskErrorResult,
  FileNetworkTaskSuccessResult,
  FileWithConnection,
} from '@/features/file/types';
import {
  createMockDownloadResponse,
  createMockFileWithConnection,
} from '@/testing/data-generation';

const renderWithProvider = (
  fileService: FileService,
  fileDownloadService: FileDownloadService,
) => {
  return renderHook(() => useFileDownload(), {
    wrapper: ({ children }) => (
      <QueryClientProvider client={new QueryClient()}>
        <FileProvider
          fileService={fileService}
          fileDownloadService={fileDownloadService}
        >
          {children}
        </FileProvider>
      </QueryClientProvider>
    ),
  });
};

describe('useFileDownload', () => {
  const mockFileService = {
    saveLocalFile: jest.fn(),
    closeFileConnection: jest.fn(),
  } as unknown as jest.Mocked<FileService>;

  const mockFileDownloadService = {
    downloadFile: jest.fn(),
    cancelDownload: jest.fn(),
  } as unknown as jest.Mocked<FileDownloadService>;

  const mockFile: FileWithConnection = createMockFileWithConnection();

  const mockSuccessResult: FileNetworkTaskSuccessResult<FileDownloadResult> = {
    success: true,
    data: createMockDownloadResponse(),
    status: 200,
  };

  const mockErrorResult: FileNetworkTaskErrorResult = {
    success: false,
    error: 'Download failed',
  };

  beforeEach(() => {
    jest.clearAllMocks();

    jest.spyOn(Math, 'random').mockReturnValue(0.123456);
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  describe('Initial state', () => {
    it('should return initial state values', () => {
      const { result } = renderWithProvider(
        mockFileService,
        mockFileDownloadService,
      );

      expect(result.current.downloadProgress).toBe(0);
      expect(result.current.downloadResult).toBeNull();
      expect(result.current.downloadError).toBe('');
      expect(typeof result.current.downloadFile).toBe('function');
      expect(typeof result.current.cancelDownload).toBe('function');
      expect(typeof result.current.resetDownload).toBe('function');
    });
  });

  describe('downloadFile', () => {
    it('should successfully download a file', async () => {
      jest
        .mocked(mockFileDownloadService.downloadFile)
        .mockResolvedValue(mockSuccessResult);

      const { result } = renderWithProvider(
        mockFileService,
        mockFileDownloadService,
      );

      await act(async () => {
        await result.current.downloadFile(mockFile);
      });

      expect(mockFileDownloadService.downloadFile).toHaveBeenCalledWith({
        downloadId: '123456',
        file: mockFile,
        onProgress: expect.any(Function),
      });

      expect(result.current.downloadResult).toEqual(mockSuccessResult.data);
      expect(result.current.downloadError).toBe('');
    });

    it('should handle download failure', async () => {
      mockFileDownloadService.downloadFile.mockResolvedValue(mockErrorResult);

      const { result } = renderWithProvider(
        mockFileService,
        mockFileDownloadService,
      );

      await act(async () => {
        await result.current.downloadFile(mockFile);
      });

      expect(result.current.downloadResult).toBeNull();
      expect(result.current.downloadError).toBe('Download failed');
    });

    it('should update progress during download', async () => {
      let progressCallback: Parameters<
        typeof mockFileDownloadService.downloadFile
      >[0]['onProgress'];

      mockFileDownloadService.downloadFile.mockImplementationOnce(
        ({ onProgress }) => {
          if (onProgress) {
            progressCallback = onProgress;
          }
          return Promise.resolve(mockSuccessResult);
        },
      );

      const { result } = renderWithProvider(
        mockFileService,
        mockFileDownloadService,
      );

      await act(async () => {
        await result.current.downloadFile(mockFile);
      });

      act(() => {
        progressCallback?.({
          totalBytesWritten: 50,
          totalBytesExpectedToWrite: 100,
        });
      });

      expect(result.current.downloadProgress).toBe(0.5);
    });

    it('should save file locally when shouldSave is true', async () => {
      mockFileDownloadService.downloadFile.mockResolvedValue(mockSuccessResult);

      const { result } = renderWithProvider(
        mockFileService,
        mockFileDownloadService,
      );

      await act(async () => {
        await result.current.downloadFile(mockFile, { shouldSave: true });
      });

      expect(mockFileService.saveLocalFile).toHaveBeenCalledWith(
        mockFile,
        mockSuccessResult.data.uri,
        mockSuccessResult.data.mimeType,
      );
    });

    it('should not save file locally when shouldSave is false', async () => {
      mockFileDownloadService.downloadFile.mockResolvedValue(mockSuccessResult);

      const { result } = renderWithProvider(
        mockFileService,
        mockFileDownloadService,
      );

      await act(async () => {
        await result.current.downloadFile(mockFile, { shouldSave: false });
      });

      expect(mockFileService.saveLocalFile).not.toHaveBeenCalled();
    });

    it('should close connection when shouldCloseConnection is true', async () => {
      mockFileDownloadService.downloadFile.mockResolvedValue(mockSuccessResult);

      const { result } = renderWithProvider(
        mockFileService,
        mockFileDownloadService,
      );

      await act(async () => {
        await result.current.downloadFile(mockFile, {
          shouldCloseConnection: true,
        });
      });

      expect(mockFileService.closeFileConnection).toHaveBeenCalledWith(
        mockSuccessResult.data.originalFile.connectionID,
      );
    });

    it('should not close connection when shouldCloseConnection is false', async () => {
      mockFileDownloadService.downloadFile.mockResolvedValue(mockSuccessResult);

      const { result } = renderWithProvider(
        mockFileService,
        mockFileDownloadService,
      );

      await act(async () => {
        await result.current.downloadFile(mockFile, {
          shouldCloseConnection: false,
        });
      });

      expect(mockFileService.closeFileConnection).not.toHaveBeenCalled();
    });

    it('should handle both shouldSave and shouldCloseConnection options', async () => {
      mockFileDownloadService.downloadFile.mockResolvedValue(mockSuccessResult);

      const { result } = renderWithProvider(
        mockFileService,
        mockFileDownloadService,
      );

      await act(async () => {
        await result.current.downloadFile(mockFile, {
          shouldSave: true,
          shouldCloseConnection: true,
        });
      });

      expect(mockFileService.saveLocalFile).toHaveBeenCalledWith(
        mockFile,
        mockSuccessResult.data.uri,
        mockSuccessResult.data.mimeType,
      );
      expect(mockFileService.closeFileConnection).toHaveBeenCalledWith(
        mockSuccessResult.data.originalFile.connectionID,
      );
    });

    it('should not save or close connection on failed download', async () => {
      mockFileDownloadService.downloadFile.mockResolvedValue(mockErrorResult);

      const { result } = renderWithProvider(
        mockFileService,
        mockFileDownloadService,
      );

      await act(async () => {
        await result.current.downloadFile(mockFile, {
          shouldSave: true,
          shouldCloseConnection: true,
        });
      });

      expect(mockFileService.saveLocalFile).not.toHaveBeenCalled();
      expect(mockFileService.closeFileConnection).not.toHaveBeenCalled();
    });

    it('should generate unique download IDs for multiple downloads', async () => {
      const randomValues = [0.123456, 0.789012];
      let callIndex = 0;

      jest
        .spyOn(Math, 'random')
        .mockImplementation(() => randomValues[callIndex++]);
      mockFileDownloadService.downloadFile.mockResolvedValue(mockSuccessResult);

      const { result } = renderWithProvider(
        mockFileService,
        mockFileDownloadService,
      );

      await act(async () => {
        await result.current.downloadFile(mockFile);
      });

      expect(mockFileDownloadService.downloadFile).toHaveBeenCalledWith(
        expect.objectContaining({ downloadId: '123456' }),
      );

      await act(async () => {
        await result.current.downloadFile(mockFile);
      });

      expect(mockFileDownloadService.downloadFile).toHaveBeenCalledWith(
        expect.objectContaining({ downloadId: '789012' }),
      );
    });
  });

  describe('resetDownload', () => {
    it('should reset download state', async () => {
      mockFileDownloadService.downloadFile.mockResolvedValue(mockErrorResult);

      const { result } = renderWithProvider(
        mockFileService,
        mockFileDownloadService,
      );

      await act(async () => {
        await result.current.downloadFile(mockFile);
      });

      expect(result.current.downloadError).toBe('Download failed');

      act(() => {
        result.current.resetDownload();
      });

      expect(result.current.downloadResult).toBeNull();
      expect(result.current.downloadProgress).toBe(0);
      expect(result.current.downloadError).toBe('');
    });
  });

  describe('cancelDownload', () => {
    it('should cancel download', async () => {
      const mockCancelResult = { success: true };
      mockFileDownloadService.cancelDownload.mockResolvedValue(
        mockCancelResult,
      );

      const { result } = renderWithProvider(
        mockFileService,
        mockFileDownloadService,
      );

      mockFileDownloadService.downloadFile.mockResolvedValue(mockSuccessResult);
      await act(async () => {
        await result.current.downloadFile(mockFile);
      });
      const cancelResult = await act(async () => {
        return await result.current.cancelDownload();
      });

      expect(mockFileDownloadService.cancelDownload).toHaveBeenCalledWith(
        '123456',
      );
      expect(cancelResult).toEqual(mockCancelResult);
    });

    it('should handle cancel download failure', async () => {
      const mockCancelError = { success: false, error: 'Cancel failed' };
      mockFileDownloadService.cancelDownload.mockResolvedValue(mockCancelError);

      const { result } = renderWithProvider(
        mockFileService,
        mockFileDownloadService,
      );

      const cancelResult = await act(async () => {
        return await result.current.cancelDownload();
      });

      expect(cancelResult).toEqual(mockCancelError);
    });
  });

  describe('Edge cases', () => {
    it('should handle null download result from service', async () => {
      mockFileDownloadService.downloadFile.mockResolvedValue(null);

      const { result } = renderWithProvider(
        mockFileService,
        mockFileDownloadService,
      );

      await act(async () => {
        await result.current.downloadFile(mockFile);
      });

      expect(result.current.downloadResult).toBeNull();
      expect(result.current.downloadError).toBe('');
    });

    it('should handle progress calculation with zero expected bytes', async () => {
      let progressCallback: Parameters<
        typeof mockFileDownloadService.downloadFile
      >[0]['onProgress'];

      mockFileDownloadService.downloadFile.mockImplementation(
        ({ onProgress }) => {
          progressCallback = onProgress;
          return Promise.resolve(mockSuccessResult);
        },
      );

      const { result } = renderWithProvider(
        mockFileService,
        mockFileDownloadService,
      );

      await act(async () => {
        await result.current.downloadFile(mockFile);
      });

      act(() => {
        progressCallback?.({
          totalBytesWritten: 50,
          totalBytesExpectedToWrite: 0,
        });
      });

      expect(result.current.downloadProgress).toBe(Infinity);
    });

    it('should work with different service instances', async () => {
      const alternativeFileService = {
        saveLocalFile: jest.fn(),
        closeFileConnection: jest.fn(),
      } as unknown as jest.Mocked<FileService>;

      const alternativeDownloadService = {
        downloadFile: jest.fn().mockResolvedValue(mockSuccessResult),
        cancelDownload: jest.fn(),
      } as unknown as jest.Mocked<FileDownloadService>;

      const { result } = renderWithProvider(
        alternativeFileService,
        alternativeDownloadService,
      );

      await act(async () => {
        await result.current.downloadFile(mockFile, { shouldSave: true });
      });

      expect(alternativeDownloadService.downloadFile).toHaveBeenCalled();
      expect(alternativeFileService.saveLocalFile).toHaveBeenCalled();
      expect(result.current.downloadResult).toEqual(mockSuccessResult.data);
    });
  });
});
