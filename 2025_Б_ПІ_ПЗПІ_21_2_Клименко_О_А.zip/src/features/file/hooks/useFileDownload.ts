import { useCallback, useState } from 'react';

import {
  useFileDownloadService,
  useFileService,
} from '@/features/file/context';
import { FileDownloadResult } from '@/features/file/types';
import { File } from '@/features/file-system/types';

type DownloadOptions = {
  shouldCloseConnection?: boolean;
  shouldSave?: boolean;
};

export const useFileDownload = () => {
  const [downloadId, setDownloadId] = useState('');
  const [downloadProgress, setDownloadProgress] = useState(0);
  const [downloadResult, setDownloadResult] =
    useState<FileDownloadResult | null>(null);
  const [downloadError, setDownloadError] = useState('');
  const fileService = useFileService();
  const fileDownloadService = useFileDownloadService();

  const downloadFile = useCallback(
    async (
      file: File,
      { shouldCloseConnection, shouldSave }: DownloadOptions = {},
    ) => {
      const newDownloadId = Math.round(Math.random() * 1000000).toString();
      setDownloadId(newDownloadId);

      const result = await fileDownloadService.downloadFile({
        downloadId: newDownloadId,
        file,
        onProgress: ({ totalBytesExpectedToWrite, totalBytesWritten }) => {
          console.log(totalBytesExpectedToWrite, totalBytesWritten);
          return setDownloadProgress(
            totalBytesWritten / totalBytesExpectedToWrite,
          );
        },
      });

      if (result?.success) {
        setDownloadResult(result.data);
      } else if (result) {
        setDownloadError(result.error);
      }

      if (result?.success && shouldSave) {
        fileService.saveLocalFile(file, result.data.uri, result.data.mimeType);
      }

      if (result?.success && shouldCloseConnection) {
        fileService.closeFileConnection(result.data.originalFile.connectionID);
      }
    },
    [],
  );

  const resetDownload = useCallback(() => {
    setDownloadResult(null);
    setDownloadProgress(0);
    setDownloadError('');
  }, []);

  const cancelDownload = useCallback(async () => {
    const result = await fileDownloadService.cancelDownload(downloadId);
    return result;
  }, [downloadId]);

  return {
    downloadProgress,
    downloadResult,
    downloadError,
    downloadFile,
    cancelDownload,
    resetDownload,
  };
};
