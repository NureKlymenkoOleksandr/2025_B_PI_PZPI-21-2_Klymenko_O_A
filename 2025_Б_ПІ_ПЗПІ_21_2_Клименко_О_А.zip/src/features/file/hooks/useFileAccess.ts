import { useEffect } from 'react';
import { useRef } from 'react';

import { BottomSheetRef } from '@/common/components/bottom-sheet/BottomSheet';
import { useControlledBottomSheet } from '@/common/hooks/useControlledBottomSheet';
import { useFileQuery } from '@/features/file/api/getFile';
import { useRootNavigation } from '@/navigation/hooks/useRootNavigation';

export const useFileAccess = (
  fileId: string | null,
  onAccessResult?: () => void,
) => {
  const navigation = useRootNavigation();
  const bottomSheetRef = useRef<BottomSheetRef>(null);

  const { data: file, error } = useFileQuery(fileId);

  useControlledBottomSheet(bottomSheetRef, !!error);

  useEffect(() => {
    if (file) {
      navigation.navigate('File', {
        id: file.id,
      });
      onAccessResult?.();
    }
  }, [file, navigation, onAccessResult]);

  useEffect(() => {
    if (error) {
      onAccessResult?.();
    }
  }, [error, onAccessResult]);

  return {
    error,
    bottomSheetRef,
  };
};
