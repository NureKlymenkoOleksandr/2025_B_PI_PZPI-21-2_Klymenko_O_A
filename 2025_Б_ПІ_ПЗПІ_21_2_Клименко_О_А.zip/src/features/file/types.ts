import { File } from '@/features/file-system/types';

export enum FileUploadStatus {
  CREATED = 'created',
  UPLOADING = 'uploading',
  FINISHED = 'finished',
  FAILED = 'failed',
  CANCELED = 'canceled',
}

export enum FileUploadType {
  LIBRARY = 'library',
  CAMERA = 'camera',
  DOCUMENT = 'document',
  AUDIO = 'audio',
}

export type FileInfo = {
  uri: string;
  name: string;
  size: number;
  mimeType: string;
};

export type FileUpload = {
  totalBytesExpectedToSend: number;
  totalBytesSent: number;
  fileName: string;
  status: FileUploadStatus;
  error?: string | null;
  fileId?: string;
};

export type FileNetworkTaskSuccessResult<T = unknown> = {
  success: true;
  data: T;
  status: number;
};

export type FileNetworkTaskErrorResult = {
  success: false;
  error: string;
  status?: number;
};

export type FileNetworkTaskResult<T = unknown> =
  | FileNetworkTaskSuccessResult<T>
  | FileNetworkTaskErrorResult;

export type FileDownloadResult = {
  originalFile: FileWithConnection;
  uri: string;
  mimeType: string | null;
};

export type FileSaveResult = {
  success: boolean;
  shared?: boolean;
  savedToGallery?: boolean;
  error?: string;
};

export type FileWithConnection = File & {
  host: string;
  connectionID: string;
};
