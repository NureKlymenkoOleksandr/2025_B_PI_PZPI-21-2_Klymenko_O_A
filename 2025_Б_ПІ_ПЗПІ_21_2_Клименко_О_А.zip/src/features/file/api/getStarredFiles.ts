import {
  keepPreviousData,
  useInfiniteQuery,
  useQueryClient,
} from '@tanstack/react-query';
import { useEffect, useMemo } from 'react';

import { useSortingParamsStore } from '@/common/stores/sortingParamsStore';
import { SortingParams } from '@/common/types/sorting';
import {
  FileSystemContent,
  FileSystemItem,
} from '@/features/file-system/types';
import { apiClient } from '@/lib/apiClient';

type GetStarredFilesResponse = {
  body: FileSystemContent;
};

const ITEMS_PER_PAGE = 16;

const getStarredFiles = async ({ order, orderBy }: SortingParams) => {
  const queryParams = new URLSearchParams({
    starred: 'true',
    sortByField: orderBy,
    sortOrder: String(order === 'asc' ? 1 : -1),
  });

  const { data } = await apiClient.get<GetStarredFilesResponse>(
    `/directory/search?${queryParams.toString()}`,
  );

  return data;
};

export const useStarredFiles = () => {
  const queryClient = useQueryClient();
  const sortingParams = useSortingParamsStore((store) => ({
    orderBy: store.orderBy,
    order: store.order,
  }));

  useEffect(() => {
    queryClient.invalidateQueries({
      queryKey: ['starred', sortingParams],
    });
  }, [sortingParams.order, sortingParams.orderBy, queryClient]);

  const { data, ...rest } = useInfiniteQuery({
    queryKey: ['starred', sortingParams],
    queryFn: () => getStarredFiles(sortingParams),
    getNextPageParam: (data, _, lastPage) => {
      const totalCount = data.body.filesCount + data.body.directoriesCount;
      return lastPage * ITEMS_PER_PAGE < totalCount ? lastPage + 1 : null;
    },
    initialPageParam: 1,
    placeholderData: keepPreviousData,
    staleTime: Infinity,
    gcTime: Infinity,
  });

  return useMemo(() => {
    if (!data?.pages) return { items: null, totalItems: 0, ...rest };

    const totalItems =
      data.pages[0].body.directoriesCount + data.pages[0].body.filesCount;
    const items: FileSystemItem[] = data.pages.flatMap(({ body }) => {
      return [...(body.directories ?? []), ...(body.files ?? [])];
    });

    return { items, totalItems, ...rest };
  }, [data]);
};
