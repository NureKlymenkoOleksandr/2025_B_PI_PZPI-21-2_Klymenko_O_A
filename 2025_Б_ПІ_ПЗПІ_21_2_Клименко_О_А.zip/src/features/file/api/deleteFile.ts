import { useMutation, useQueryClient } from '@tanstack/react-query';

import { folderQueryKeys } from '@/features/folder/api/queryKeys';
import { apiClient } from '@/lib/apiClient';

type DeleteFileInput = {
  id: string;
  parentDirectoryID: string;
};

export const deleteFile = async (fileId: string) => {
  const { data } = await apiClient.delete(`/file/${fileId}`);
  return !!data;
};

export const useDeleteFileMutation = () => {
  const queryClient = useQueryClient();

  return useMutation<boolean, Error, DeleteFileInput>({
    mutationFn: (variables) => deleteFile(variables.id),
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({
        queryKey: folderQueryKeys.folder(variables.parentDirectoryID),
      });
    },
  });
};
