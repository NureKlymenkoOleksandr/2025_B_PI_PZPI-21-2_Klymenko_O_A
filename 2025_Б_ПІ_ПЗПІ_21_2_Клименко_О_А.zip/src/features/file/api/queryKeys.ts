export const fileQueryKeys = {
  file: (fileId: string) => ['file', fileId],
  starred: () => ['starred'],
};
