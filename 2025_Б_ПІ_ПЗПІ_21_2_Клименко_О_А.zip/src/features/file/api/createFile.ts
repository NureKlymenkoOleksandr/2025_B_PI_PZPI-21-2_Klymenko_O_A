import { AxiosResponse } from 'axios';

import { FileWithConnection } from '@/features/file/types';
import { apiClient } from '@/lib/apiClient';

type CreateFileInput = {
  parentDirID: string;
  name: string;
  extension: string;
  size: number;
};

type CreateFileResponse = {
  body: FileWithConnection;
};

export const createFile = async (input: CreateFileInput) => {
  const { data } = await apiClient.post<
    CreateFileInput,
    AxiosResponse<CreateFileResponse>
  >(`/file`, input);
  return data.body;
};
