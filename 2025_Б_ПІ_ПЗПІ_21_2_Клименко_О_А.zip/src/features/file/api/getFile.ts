import { useQuery } from '@tanstack/react-query';

import { API_BASE_URL } from '@/config/env';
import { FileWithConnection } from '@/features/file/types';
import { apiClient } from '@/lib/apiClient';

type GetFileResponse = {
  body: FileWithConnection;
};

export const getFile = async (fileId: string) => {
  const { data } = await apiClient.get<GetFileResponse>(
    `${API_BASE_URL}/file/${fileId}`,
  );

  return data.body;
};

export const useFileQuery = (id: string | null) => {
  return useQuery({
    queryKey: ['file', id],
    queryFn: () => getFile(id ?? ''),
    staleTime: 0,
    gcTime: 0,
    retry: false,
    enabled: !!id,
  });
};
