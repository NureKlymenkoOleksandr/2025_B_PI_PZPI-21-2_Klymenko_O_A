import { useMutation, useQueryClient } from '@tanstack/react-query';

import { folderQueryKeys } from '@/features/folder/api/queryKeys';
import { apiClient } from '@/lib/apiClient';

type RenameFilePayload = {
  id: string;
  name: string;
};

type RenameFileInput = {
  payload: RenameFilePayload;
  parentDirectoryID: string;
};

const renameFile = async ({ id, name }: RenameFilePayload) => {
  const { data } = await apiClient.patch(`/file/${id}/rename?name=${name}`);
  return !!data;
};

export const useRenameFileMutation = () => {
  const queryClient = useQueryClient();

  return useMutation<boolean, Error, RenameFileInput>({
    mutationFn: (variables) => renameFile(variables.payload),
    onSuccess: (_, { parentDirectoryID }) => {
      queryClient.invalidateQueries({
        queryKey: folderQueryKeys.folder(parentDirectoryID),
      });
    },
  });
};
