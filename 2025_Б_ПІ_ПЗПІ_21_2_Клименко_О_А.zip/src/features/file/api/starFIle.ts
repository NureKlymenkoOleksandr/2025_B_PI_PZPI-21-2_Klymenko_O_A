import { useMutation, useQueryClient } from '@tanstack/react-query';

import { folderQueryKeys } from '@/features/folder/api/queryKeys';
import { apiClient } from '@/lib/apiClient';

type StarFileInput = {
  id: string;
  parentDirectoryID: string;
};

const starFile = async (id: string) => {
  const { data } = await apiClient.patch(`/file/${id}/star`);
  return !!data;
};

export const useStarFileMutation = () => {
  const queryClient = useQueryClient();

  return useMutation<boolean, Error, StarFileInput>({
    mutationFn: (input) => starFile(input.id),
    onSuccess: (_, input) => {
      queryClient.invalidateQueries({
        queryKey: ['starred'],
      });
      queryClient.invalidateQueries({
        queryKey: folderQueryKeys.folder(input.parentDirectoryID),
      });
    },
  });
};
