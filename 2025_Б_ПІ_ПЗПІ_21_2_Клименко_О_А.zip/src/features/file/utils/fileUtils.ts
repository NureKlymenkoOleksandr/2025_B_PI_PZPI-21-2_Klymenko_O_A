import { getExtensionFromMimeType } from '@/common/utils/mimeType';

export const getFileExtension = (fileName: string) => {
  const parts = fileName.split('.');
  return parts.length > 1 ? (parts.pop() ?? '') : '';
};

export function fixFileNameExtension(
  fileName: string,
  mimeType: string,
): string {
  const ext = getFileExtension(fileName);
  if (ext) return fileName;

  const correctExt = getExtensionFromMimeType(mimeType);
  return correctExt ? `${fileName}.${correctExt}` : fileName;
}
