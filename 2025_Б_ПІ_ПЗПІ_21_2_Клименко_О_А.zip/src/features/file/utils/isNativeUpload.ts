import { FileUploadType } from '@/features/file/types';

export const isNativeUpload = (uploadType: FileUploadType) =>
  [
    FileUploadType.CAMERA,
    FileUploadType.DOCUMENT,
    FileUploadType.LIBRARY,
  ].includes(uploadType);
