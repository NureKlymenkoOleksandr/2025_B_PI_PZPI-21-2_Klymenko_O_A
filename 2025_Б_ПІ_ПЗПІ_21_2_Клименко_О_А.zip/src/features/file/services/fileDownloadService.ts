import * as FileSystem from 'expo-file-system';

import { getMimeTypeFromExtension } from '@/common/utils/mimeType';
import { FILE_SYSTEM_DOWNLOAD_URL_MOCK } from '@/config/env';
import { getFile } from '@/features/file/api/getFile';
import {
  FileDownloadResult,
  FileNetworkTaskResult,
  FileWithConnection,
} from '@/features/file/types';
import { File } from '@/features/file-system/types';
import { isFileWithConnection } from '@/features/file-system/utils/isFileWithConnection';

export class FileDownloadService {
  private downloadResumables: Record<string, FileSystem.DownloadResumable> = {};

  private parseDownloadResult = (
    response: FileSystem.FileSystemDownloadResult,
    file: FileWithConnection,
  ): FileNetworkTaskResult<FileDownloadResult> => {
    if (response.status >= 200 && response.status < 300) {
      const mimeType =
        response.mimeType ||
        response.headers['content-type']?.split(';')[0] ||
        getMimeTypeFromExtension(file.extension).mimeType;

      return {
        success: true,
        data: {
          originalFile: file,
          uri: response.uri,
          mimeType,
        },
        status: response.status,
      };
    } else {
      return {
        success: false,
        error: `Operation failed with status ${response.status}`,
        status: response.status,
      };
    }
  };

  getDownloadURL = (file: FileWithConnection) => {
    if (FILE_SYSTEM_DOWNLOAD_URL_MOCK) {
      return FILE_SYSTEM_DOWNLOAD_URL_MOCK;
    }

    if (__DEV__) {
      console.warn(
        'Download URL is not implemented. Consider adding FILE_SYSTEM_DOWNLOAD_URL_MOCK',
      );
    }

    return `${file.host}/files/read?connectionID=${file.connectionID}`;
  };

  private getDownloadFileUri = async (file: File, persist?: boolean) => {
    const fileName = `${file.id}-${file.name}`;
    const targetDir = `${persist ? FileSystem.documentDirectory : FileSystem.cacheDirectory}/downloads/`;

    await FileSystem.makeDirectoryAsync(targetDir, { intermediates: true });

    return `${targetDir}${fileName}`;
  };

  downloadFile = async ({
    downloadId,
    file,
    onProgress,
    persist,
  }: {
    downloadId: string;
    file: File;
    onProgress?: FileSystem.FileSystemNetworkTaskProgressCallback<FileSystem.DownloadProgressData>;
    persist?: boolean;
  }): Promise<FileNetworkTaskResult<FileDownloadResult> | null> => {
    const fileWithConnection = isFileWithConnection(file)
      ? file
      : await getFile(file.id);

    const downloadUrl = this.getDownloadURL(fileWithConnection);

    const fileUri = await this.getDownloadFileUri(file, persist);
    try {
      const downloadResumable = FileSystem.createDownloadResumable(
        downloadUrl,
        fileUri,
        {},
        onProgress,
      );

      this.downloadResumables[downloadId] = downloadResumable;

      const response = await downloadResumable.downloadAsync();

      if (!response) return null;

      return this.parseDownloadResult(response, fileWithConnection);
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : String(error),
      };
    } finally {
      delete this.downloadResumables[downloadId];
    }
  };

  cancelDownload = async (downloadId: string) => {
    const downloadResumable = this.downloadResumables[downloadId];

    if (!downloadResumable)
      return { success: false, error: 'Download resumable not found' };

    try {
      await downloadResumable.cancelAsync();
      return { success: true };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : String(error),
      };
    }
  };
}
