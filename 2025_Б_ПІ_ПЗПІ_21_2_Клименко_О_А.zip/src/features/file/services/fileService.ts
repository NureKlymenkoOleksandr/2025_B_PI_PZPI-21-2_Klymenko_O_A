import * as FileSystem from 'expo-file-system';
import * as MediaLibrary from 'expo-media-library';
import * as Sharing from 'expo-sharing';

import {
  getMimeTypeFromExtension,
  shouldSaveToGallery,
} from '@/common/utils/mimeType';
import { FileSaveResult } from '@/features/file/types';
import { File } from '@/features/file-system/types';

export class FileService {
  closeFileConnection = async (connectionId: string) => {
    return true;
  };

  ensureDirectoryExists = async (directoryPath: string) => {
    const dirInfo = await FileSystem.getInfoAsync(directoryPath);
    if (!dirInfo.exists) {
      await FileSystem.makeDirectoryAsync(directoryPath, {
        intermediates: true,
      });
    }
  };

  requestMediaLibraryPermissions = async (): Promise<boolean> => {
    try {
      const { status } = await MediaLibrary.requestPermissionsAsync();
      return status === 'granted';
    } catch (error) {
      console.error('Error requesting media library permissions:', error);
      return false;
    }
  };

  saveToGallery = async (
    fileUri: string,
    fileName: string,
  ): Promise<{ success: boolean; error?: string }> => {
    try {
      if (!shouldSaveToGallery(fileName)) {
        return {
          success: false,
          error: 'File type not supported for gallery saving',
        };
      }

      const hasPermission = await this.requestMediaLibraryPermissions();
      if (!hasPermission) {
        return {
          success: false,
          error: 'Permission denied to access media library',
        };
      }

      const fileInfo = await FileSystem.getInfoAsync(fileUri);
      if (!fileInfo.exists) {
        return {
          success: false,
          error: 'File does not exist',
        };
      }

      await MediaLibrary.createAssetAsync(fileUri);

      return { success: true };
    } catch (error) {
      return {
        success: false,
        error:
          error instanceof Error ? error.message : 'Unknown error occurred',
      };
    }
  };

  shareFile = async (fileUri: string, fileName: string, mimeType: string) => {
    try {
      if (await Sharing.isAvailableAsync()) {
        await Sharing.shareAsync(fileUri, {
          dialogTitle: fileName,
          mimeType: mimeType,
        });
        return { success: true, shared: true };
      } else {
        return {
          success: false,
          error: 'Sharing is not available on this device',
        };
      }
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : String(error),
      };
    }
  };

  saveLocalFile = async (
    file: File,
    fileUri: string,
    mimeType?: string | null,
  ): Promise<FileSaveResult> => {
    try {
      const finalMimeType =
        mimeType || getMimeTypeFromExtension(file.extension).mimeType;

      if (shouldSaveToGallery(file.extension)) {
        const galleryResult = await this.saveToGallery(fileUri, file.extension);

        if (galleryResult.success) {
          return { success: true, savedToGallery: true };
        } else {
          return { success: false, error: galleryResult.error };
        }
      } else {
        return await this.shareFile(fileUri, file.name, finalMimeType);
      }
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : String(error),
      };
    }
  };

  deleteLocalFile = async (fileUri: string) => {
    return FileSystem.deleteAsync(fileUri);
  };
}
