import * as DocumentPicker from 'expo-document-picker';

import { FileInfo } from '@/features/file/types';
import { fixFileNameExtension } from '@/features/file/utils/fileUtils';

export const selectDocuments = async (): Promise<FileInfo[] | null> => {
  const result = await DocumentPicker.getDocumentAsync({
    multiple: true,
    base64: false,
  });

  if (result.canceled) {
    return null;
  }

  return result.assets.map((asset) => ({
    uri: asset.uri,
    name: asset.mimeType
      ? fixFileNameExtension(asset.name, asset.mimeType)
      : (asset.name ?? ''),
    size: asset.size ?? 0,
    mimeType: asset.mimeType ?? '',
  }));
};
