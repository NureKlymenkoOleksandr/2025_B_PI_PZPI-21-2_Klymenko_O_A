import * as FileSystem from 'expo-file-system';

import { getExtensionFromMimeType } from '@/common/utils/mimeType';
import { FILE_SYSTEM_UPLOAD_URL_MOCK } from '@/config/env';
import { createFile } from '@/features/file/api/createFile';
import {
  FileInfo,
  FileNetworkTaskResult,
  FileWithConnection,
} from '@/features/file/types';
import { getFileExtension } from '@/features/file/utils/fileUtils';

import { FileService } from './fileService';

export class FileUploadService {
  constructor(private fileService: FileService) {}

  private uploadTasks: Record<string, FileSystem.UploadTask> = {};

  private parseUploadResult = (
    response: FileSystem.FileSystemUploadResult,
  ): FileNetworkTaskResult => {
    if (response.status >= 200 && response.status < 300) {
      return {
        success: true,
        data: response.body ? JSON.parse(response.body) : null,
        status: response.status,
      };
    } else {
      return {
        success: false,
        error: `Operation failed with status ${response.status}`,
        status: response.status,
      };
    }
  };

  private getUploadURL = (file: FileWithConnection) => {
    console.log(file);
    if (FILE_SYSTEM_UPLOAD_URL_MOCK) {
      return FILE_SYSTEM_UPLOAD_URL_MOCK;
    }

    if (__DEV__) {
      console.warn(
        'Upload URL is not implemented. Consider adding FILE_SYSTEM_UPLOAD_URL_MOCK',
      );
    }

    return `${file.host}/files/write?connectionID=${file.connectionID}`;
  };

  uploadFile = async ({
    uploadId,
    file,
    parentDirectoryID,
    onProgress,
    onFileCreated,
  }: {
    uploadId: string;
    file: FileInfo;
    parentDirectoryID: string;
    onProgress?: FileSystem.FileSystemNetworkTaskProgressCallback<FileSystem.UploadProgressData>;
    onFileCreated?: (fileId: string) => void;
  }): Promise<FileNetworkTaskResult | null> => {
    const fileWithConnection = await createFile({
      name: file.name,
      parentDirID: parentDirectoryID,
      size: file.size,
      extension:
        getFileExtension(file.name) ||
        getExtensionFromMimeType(file.mimeType) ||
        '',
    });

    onFileCreated?.(fileWithConnection.id);

    const uploadUrl = this.getUploadURL(fileWithConnection);

    try {
      const uploadTask = FileSystem.createUploadTask(
        uploadUrl,
        file.uri,
        {
          uploadType: FileSystem.FileSystemUploadType.BINARY_CONTENT,
        },
        onProgress,
      );

      this.uploadTasks[uploadId] = uploadTask;

      const response = await uploadTask.uploadAsync();

      if (!response) return null;

      return this.parseUploadResult(response);
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : String(error),
      };
    } finally {
      delete this.uploadTasks[uploadId];
      this.fileService.closeFileConnection(fileWithConnection.connectionID);
    }
  };

  cancelUpload = async (uploadId: string) => {
    const uploadTask = this.uploadTasks[uploadId];

    if (!uploadTask) return { success: false, error: 'Upload task not found' };

    try {
      await uploadTask.cancelAsync();
      return { success: true };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : String(error),
      };
    }
  };

  deleteFile = async (fileId: string) => {
    try {
      await this.fileService.deleteLocalFile(fileId);
      return { success: true };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : String(error),
      };
    }
  };
}
