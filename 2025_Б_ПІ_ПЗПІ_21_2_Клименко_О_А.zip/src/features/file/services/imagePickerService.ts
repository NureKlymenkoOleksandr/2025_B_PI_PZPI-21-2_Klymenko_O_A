import * as ImagePicker from 'expo-image-picker';

import { FileInfo } from '@/features/file/types';

const IMAGE_PICKER_OPTIONS: ImagePicker.ImagePickerOptions = {
  mediaTypes: ['images', 'videos'],
  quality: 1,
  allowsMultipleSelection: true,
  allowsEditing: false,
};

export const requestCameraAccess = async () => {
  const { granted, canAskAgain } =
    await ImagePicker.requestCameraPermissionsAsync();
  return { granted, canAskAgain };
};

const formatSelectedAssets = (
  result: ImagePicker.ImagePickerResult,
): FileInfo[] | null => {
  if (result.canceled) return null;

  return result.assets.map((asset) => ({
    uri: asset.uri,
    name: asset.fileName ?? '',
    size: asset.fileSize ?? 0,
    mimeType: asset.mimeType ?? '',
  }));
};

export const selectMediaFromLibrary = async (): Promise<FileInfo[] | null> => {
  const result =
    await ImagePicker.launchImageLibraryAsync(IMAGE_PICKER_OPTIONS);
  return formatSelectedAssets(result);
};

export const captureMediaWithCamera = async (): Promise<FileInfo | null> => {
  const result = await ImagePicker.launchCameraAsync(IMAGE_PICKER_OPTIONS);
  const [firstAsset] = formatSelectedAssets(result) ?? [];
  return firstAsset ?? null;
};
