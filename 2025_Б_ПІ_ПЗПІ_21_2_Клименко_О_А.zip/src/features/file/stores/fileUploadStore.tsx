import { QueryClient } from '@tanstack/react-query';
import { createStore } from 'zustand';

import { FileUploadService } from '@/features/file/services/fileUploadService';
import {
  FileInfo,
  FileUploadStatus,
  FileUploadType,
} from '@/features/file/types';
import { FileUpload } from '@/features/file/types';
import { folderQueryKeys } from '@/features/folder/api/queryKeys';

function generateUploadId(file: FileInfo) {
  return `${Date.now()}-${file.name}`;
}

type FileUploadState = {
  uploadFolderId: string | null;
  isUploadMenuOpened: boolean;
  isAudioRecordingOpened: boolean;
  currentUploadType: FileUploadType | null;
  pendingFiles: FileInfo[];
  fileUploads: Map<string, FileUpload>;
};

export type FileUploadStore = FileUploadState & {
  setUploadFolderId: (folderId?: string | null) => void;
  setIsUploadMenuOpened: (isOpened: boolean) => void;
  setIsAudioRecordingOpened: (isOpened: boolean) => void;
  setCurrentUploadType: (uploadType: FileUploadType | null) => void;
  setPendingFiles: (pendingFiles: FileInfo[]) => void;
  startUpload: (file: FileInfo) => Promise<void>;
  cancelUpload: (uploadId: string) => Promise<void>;
  removeUpload: (uploadId: string) => void;
};

export const createFileUploadStore = (
  fileService: FileUploadService,
  queryClient: QueryClient,
) =>
  createStore<FileUploadStore>((set, get) => ({
    uploadFolderId: null,
    isUploadMenuOpened: false,
    isAudioRecordingOpened: false,
    currentUploadType: null,
    pendingFiles: [],
    fileUploads: new Map(),

    setUploadFolderId: (folderId = null) => set({ uploadFolderId: folderId }),

    setIsUploadMenuOpened: (isOpened) => set({ isUploadMenuOpened: isOpened }),

    setIsAudioRecordingOpened: (isOpened) =>
      set({ isAudioRecordingOpened: isOpened }),

    setPendingFiles: (pendingFiles) => set({ pendingFiles }),

    setCurrentUploadType: (uploadType) =>
      set({ currentUploadType: uploadType }),

    startUpload: async (file) => {
      const folderId = get().uploadFolderId;
      if (!folderId) return;

      const uploadId = generateUploadId(file);

      set((state) => {
        const newUploads = new Map(state.fileUploads);
        newUploads.set(uploadId, {
          totalBytesExpectedToSend: file.size ?? 0,
          totalBytesSent: 0,
          fileName: file.name ?? '',
          status: FileUploadStatus.CREATED,
        });
        return { fileUploads: newUploads };
      });

      const uploadResult = await fileService.uploadFile({
        parentDirectoryID: folderId,
        uploadId,
        file,
        onProgress: ({ totalBytesSent, totalBytesExpectedToSend }) => {
          set((state) => {
            const newUploads = new Map(state.fileUploads);
            const upload = newUploads.get(uploadId);
            if (upload) {
              newUploads.set(uploadId, {
                ...upload,
                status: FileUploadStatus.UPLOADING,
                totalBytesSent,
                totalBytesExpectedToSend,
              });
            }
            return { fileUploads: newUploads };
          });
        },
        onFileCreated: (fileId) => {
          set((state) => {
            const newUploads = new Map(state.fileUploads);
            const upload = newUploads.get(uploadId);
            if (upload) {
              newUploads.set(uploadId, {
                ...upload,
                fileId,
              });
            }
            return { fileUploads: newUploads };
          });
        },
      });

      if (!uploadResult) return;

      set((state) => {
        const newUploads = new Map(state.fileUploads);
        const upload = newUploads.get(uploadId);
        if (upload) {
          newUploads.set(uploadId, {
            ...upload,
            status: uploadResult.success
              ? FileUploadStatus.FINISHED
              : FileUploadStatus.FAILED,
            error: uploadResult.success ? null : uploadResult.error,
          });
        }
        return { fileUploads: newUploads };
      });

      if (uploadResult.success) {
        queryClient.invalidateQueries({
          queryKey: folderQueryKeys.folder(folderId),
        });
      }
    },

    cancelUpload: async (uploadId) => {
      const { success } = await fileService.cancelUpload(uploadId);

      if (!success) return;

      set((state) => {
        const newUploads = new Map(state.fileUploads);
        const upload = newUploads.get(uploadId);
        if (upload) {
          newUploads.set(uploadId, {
            ...upload,
            status: FileUploadStatus.CANCELED,
          });
        }
        return { fileUploads: newUploads };
      });
    },

    removeUpload: (uploadId) => {
      const upload = get().fileUploads.get(uploadId);
      if (
        upload &&
        [FileUploadStatus.CANCELED, FileUploadStatus.FINISHED].includes(
          upload.status,
        )
      ) {
        set((state) => {
          const newUploads = new Map(state.fileUploads);
          newUploads.delete(uploadId);
          return { fileUploads: newUploads };
        });
      }
    },
  }));
