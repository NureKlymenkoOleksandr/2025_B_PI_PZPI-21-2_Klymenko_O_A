import { createStore } from 'zustand';

import { FileService } from '@/features/file/services/fileService';

type FileState = {
  fileUris: Record<string, string>;
};

export type FileStore = FileState & {
  addFileUri: (id: string, uri: string) => void;
};

export const createFileStore = (fileService: FileService) =>
  createStore<FileStore>((set, get) => ({
    fileUris: {},

    addFileUri: (id, uri) => {
      set((state) => ({
        fileUris: {
          ...state.fileUris,
          [id]: uri,
        },
      }));
    },

    deleteFileUri: async (id: string) => {
      const fileUri = get().fileUris[id];
      await fileService.deleteLocalFile(fileUri);
      set(({ fileUris: { [id]: _, ...restUris } }) => ({
        fileUris: restUris,
      }));
    },
  }));
