import { useQueryClient } from '@tanstack/react-query';
import { createContext, PropsWithChildren, useContext, useState } from 'react';
import { useStore } from 'zustand';
import { useShallow } from 'zustand/react/shallow';

import { FileDownloadService } from '@/features/file/services/fileDownloadService';
import { FileService } from '@/features/file/services/fileService';
import { FileUploadService } from '@/features/file/services/fileUploadService';
import { createFileStore, FileStore } from '@/features/file/stores/fileStore';
import {
  createFileUploadStore,
  FileUploadStore,
} from '@/features/file/stores/fileUploadStore';

type FileServices = {
  fileDownloadService: FileDownloadService;
  fileUploadService: FileUploadService;
  fileService: FileService;
};

type FileContextValue = FileServices & {
  fileStore: ReturnType<typeof createFileStore>;
  fileUploadStore: ReturnType<typeof createFileUploadStore>;
};

type FileProviderProps = PropsWithChildren<Partial<FileServices>>;

const FileContext = createContext<FileContextValue | null>(null);

export const FileProvider = ({
  children,
  fileService = new FileService(),
  fileDownloadService = new FileDownloadService(),
  fileUploadService = new FileUploadService(fileService),
}: FileProviderProps) => {
  const queryClient = useQueryClient();

  const [contextValue] = useState(() => ({
    fileUploadStore: createFileUploadStore(fileUploadService, queryClient),
    fileStore: createFileStore(fileService),
    fileService,
    fileDownloadService,
    fileUploadService,
  }));

  return (
    <FileContext.Provider value={contextValue}>{children}</FileContext.Provider>
  );
};

const useFileContext = () => {
  const fileContext = useContext(FileContext);

  if (!fileContext) {
    throw new Error('useFileStore must be used within a FileProvider');
  }

  return fileContext;
};

export const useFileStore = <T,>(selector: (store: FileStore) => T): T => {
  const fileContext = useFileContext();
  return useStore(fileContext.fileStore, useShallow(selector));
};

export const useFileUploadStore = <T,>(
  selector: (store: FileUploadStore) => T,
): T => {
  const fileContext = useFileContext();
  return useStore(fileContext.fileUploadStore, useShallow(selector));
};

export const useFileService = () => useFileContext().fileService;

export const useFileUploadService = () => useFileContext().fileUploadService;

export const useFileDownloadService = () =>
  useFileContext().fileDownloadService;
