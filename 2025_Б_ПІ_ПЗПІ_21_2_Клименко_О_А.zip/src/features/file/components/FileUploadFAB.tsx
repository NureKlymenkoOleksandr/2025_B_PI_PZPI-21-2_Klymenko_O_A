import FontAwesome6 from '@expo/vector-icons/FontAwesome6';

import { FloatingActionButton } from '@/common/components/FloatingActionButton';
import { useTheme } from '@/common/theme';
import { useFileUploadStore } from '@/features/file/context';
import { useIsInTabNavigator } from '@/navigation/hooks/useIsInTabNavigator';

export const FileUploadFab = () => {
  // Refactor folderId to useFileSystemActionStore
  const { uploadFolderId, setIsUploadMenuOpened } = useFileUploadStore(
    (store) => ({
      uploadFolderId: store.uploadFolderId,
      setIsUploadMenuOpened: store.setIsUploadMenuOpened,
    }),
  );
  const isInTabNavigator = useIsInTabNavigator();
  const { colors } = useTheme();

  const handleMenuOpen = () => {
    setIsUploadMenuOpened(true);
  };

  if (uploadFolderId === null) {
    return null;
  }

  return (
    <>
      <FloatingActionButton
        testID="upload-fab"
        bottom={isInTabNavigator ? 48 : 72}
        onPress={handleMenuOpen}
      >
        <FontAwesome6 name="plus" size={20} color={colors.primary} />
      </FloatingActionButton>
    </>
  );
};
