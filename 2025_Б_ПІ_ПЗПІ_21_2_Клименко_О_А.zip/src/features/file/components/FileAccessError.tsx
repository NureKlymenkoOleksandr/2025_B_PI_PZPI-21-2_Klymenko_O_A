import { useTranslation } from 'react-i18next';
import { MaterialIcons } from '@expo/vector-icons';

import { BottomSheet, BottomSheetRef, BottomSheetView } from '@/common/components/bottom-sheet';
import { Typography } from '@/common/components/Typography';
import { useTheme } from '@/common/theme';

type FileAccessErrorProps = {
  bottomSheetRef: React.RefObject<BottomSheetRef | null>;
};

export const FileAccessError = ({ bottomSheetRef }: FileAccessErrorProps) => {
  const { t } = useTranslation();
  const { colors } = useTheme();

  return (
    <BottomSheet
      name="file-access-error"
      ref={bottomSheetRef}
    >
      <BottomSheetView style={{ padding: 16, alignItems: 'center' }}>
        <MaterialIcons 
          name="lock" 
          size={48} 
          color={colors.primary} 
          style={{ marginBottom: 16 }}
        />
        <Typography
          weight='semiBold'
          style={{ color: colors.text, fontSize: 24, textAlign: 'center', marginBottom: 8 }}
        >
          {t('file.accessError.title')}
        </Typography>
        <Typography
          style={{ color: colors.text, textAlign: 'center' }}
        >
          {t('file.accessError.description')}
        </Typography>
      </BottomSheetView>
    </BottomSheet>
  );
};
