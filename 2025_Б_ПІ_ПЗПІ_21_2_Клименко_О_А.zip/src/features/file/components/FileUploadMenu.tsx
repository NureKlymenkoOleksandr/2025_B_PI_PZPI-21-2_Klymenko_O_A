// import FontAwesome from '@expo/vector-icons/FontAwesome';
// import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import FontAwesome6 from '@expo/vector-icons/FontAwesome6';
import { useRef } from 'react';
import { useTranslation } from 'react-i18next';

import {
  BottomSheet,
  BottomSheetRef,
  BottomSheetView,
} from '@/common/components/bottom-sheet';
import { MenuItem } from '@/common/components/menu';
import { useControlledBottomSheet } from '@/common/hooks/useControlledBottomSheet';
import { useTheme } from '@/common/theme';
import { useFileUploadStore } from '@/features/file/context';
import { useNativeFileUpload } from '@/features/file/hooks/useNativeFileUpload';
import { FileUploadType } from '@/features/file/types';
import { useFileSystemActionStore } from '@/features/file-system/stores/fileSystemActionStore';
import { FileSystemAction } from '@/features/file-system/types';

export const FileUploadMenu = () => {
  const { colors } = useTheme();
  const bottomSheetRef = useRef<BottomSheetRef>(null);
  const { t } = useTranslation();

  const { setCurrentAction } = useFileSystemActionStore((store) => ({
    setCurrentItem: store.setCurrentItem,
    setCurrentAction: store.setCurrentAction,
  }));
  const { isUploadMenuOpened, setIsUploadMenuOpened, setCurrentUploadType } =
    useFileUploadStore((store) => ({
      isUploadMenuOpened: store.isUploadMenuOpened,
      setIsUploadMenuOpened: store.setIsUploadMenuOpened,
      setCurrentUploadType: store.setCurrentUploadType,
    }));

  useControlledBottomSheet(bottomSheetRef, isUploadMenuOpened);
  useNativeFileUpload();

  const handleMenuClose = () => {
    setIsUploadMenuOpened(false);
  };

  const handleUploadAction =
    (fileSystemAction: FileSystemAction, uploadType?: FileUploadType) => () => {
      handleMenuClose();
      setCurrentAction(fileSystemAction);
      if (uploadType) {
        setCurrentUploadType(uploadType);
      }
    };

  return (
    <BottomSheet
      name="upload-menu"
      ref={bottomSheetRef}
      onClose={handleMenuClose}
    >
      <BottomSheetView>
        <MenuItem
          testID="create-folder-option"
          title={t('folder.create')}
          onPress={handleUploadAction(FileSystemAction.CREATE_FOLDER)}
          icon={
            <FontAwesome6 name="folder-plus" size={20} color={colors.primary} />
          }
        />
        <MenuItem
          testID="upload-from-library-option"
          title={t('fileUpload.pickFromTheLibrary')}
          onPress={handleUploadAction(
            FileSystemAction.UPLOAD_FILE,
            FileUploadType.LIBRARY,
          )}
          icon={<FontAwesome6 name="images" size={20} color={colors.primary} />}
        />
        <MenuItem
          testID="upload-from-camera-option"
          title={t('fileUpload.takePhotoOrVideo')}
          onPress={handleUploadAction(
            FileSystemAction.UPLOAD_FILE,
            FileUploadType.CAMERA,
          )}
          icon={<FontAwesome6 name="camera" size={20} color={colors.primary} />}
        />
        <MenuItem
          testID="upload-from-files-option"
          title={t('fileUpload.pickFromFileSystem')}
          onPress={handleUploadAction(
            FileSystemAction.UPLOAD_FILE,
            FileUploadType.DOCUMENT,
          )}
          icon={
            <FontAwesome6 name="file-import" size={20} color={colors.primary} />
          }
        />
        {/* <MenuItem
          title={t('fileUpload.recordAudio')}
          onPress={() => {}}
          icon={
            <FontAwesome6 name="microphone" size={20} color={colors.text} />
          }
        /> */}
      </BottomSheetView>
    </BottomSheet>
  );
};
