import * as Linking from 'expo-linking';
import { useEffect, useState } from 'react';

import { useFileAccess } from '@/features/file/hooks/useFileAccess';

import { FileAccessError } from './FileAccessError';

export const FileAccessHandler = () => {
  const [fileId, setFileId] = useState<string | null>(null);
  const { bottomSheetRef } = useFileAccess(fileId, () => setFileId(null));

  const handleUrl = (url: string) => {
    try {
      const parsedUrl = new URL(url);
      const pathname = parsedUrl.pathname;
      const fileId = pathname.split('/')[2];
      console.log('FILE', fileId);

      if (pathname.startsWith('/share/') && fileId) {
        setFileId(fileId);
      }
    } catch {
      console.warn('Invalid URL:', url);
    }
  };

  useEffect(() => {
    Linking.getInitialURL().then((url) => {
      if (url) {
        handleUrl(url);
      }
    });

    const subscription = Linking.addEventListener('url', ({ url }) => {
      handleUrl(url);
    });

    return () => {
      subscription.remove();
    };
  }, []);

  return <FileAccessError bottomSheetRef={bottomSheetRef} />;
};
