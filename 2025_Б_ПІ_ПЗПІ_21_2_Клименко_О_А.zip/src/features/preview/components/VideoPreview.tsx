import { useVideoPlayer, VideoView } from 'expo-video';
import { StyleSheet } from 'react-native';

import { Loader } from '@/common/components/Loader';

type VideoPreviewProps = {
  url: string;
};

export const VideoPreview = ({ url }: VideoPreviewProps) => {
  const player = useVideoPlayer(url, (player) => {
    player.loop = true;
    player.play();
  });

  if (player.status === 'loading') return <Loader />;

  return (
    <VideoView
      style={styles.video}
      player={player}
      allowsFullscreen
      allowsPictureInPicture
      contentFit="contain"
    />
  );
};

const styles = StyleSheet.create({
  video: {
    flex: 1,
  },
});
