import { useImage, Image } from 'expo-image';
import { StyleSheet, View } from 'react-native';

import { Loader } from '@/common/components/Loader';

type ImagePreviewProps = {
  url: string;
  cacheKey?: string;
};

export const ImagePreview = ({ url, cacheKey }: ImagePreviewProps) => {
  const imageRef = useImage({
    uri: url,
    cacheKey: cacheKey ?? url,
  });

  if (!imageRef) return <Loader />;

  return (
    <View style={styles.image}>
      <Image source={imageRef} style={styles.image} contentFit="contain" />
    </View>
  );
};

const styles = StyleSheet.create({
  root: {
    flex: 1,
  },
  image: {
    flex: 1,
    width: '100%',
  },
});
