import { useAudioPlayer } from 'expo-audio';
import { Button, StyleSheet, View } from 'react-native';

type AudioPreviewProps = {
  url: string;
};

export const AudioPreview = ({ url }: AudioPreviewProps) => {
  const player = useAudioPlayer({
    uri: url,
  });

  return (
    <View style={styles.container}>
      <Button title="Play Sound" onPress={() => player.play()} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 10,
  },
});
