import { useTranslation } from 'react-i18next';
import { View } from 'react-native';

import { Typography } from '@/common/components/Typography';
import { FileIcon } from '@/common/icons/FileIcon';
import { useTheme } from '@/common/theme';

type NotSupportedPreviewProps = {
  fileExtension?: string;
};

export const NotSupportedPreview = ({
  fileExtension,
}: NotSupportedPreviewProps) => {
  const { colors } = useTheme();
  const { t } = useTranslation();

  return (
    <View
      style={{
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 20,
      }}
    >
      <FileIcon width={48} height={48} fill={colors.primary} />
      <Typography
        size={20}
        weight="semiBold"
        style={{ marginTop: 16, marginBottom: 8 }}
      >
        {t('preview.notAvailable')}
      </Typography>
      <Typography size={16} style={{ textAlign: 'center', color: '#666' }}>
        {fileExtension
          ? t('preview.notSupportedWithExtension', { extension: fileExtension })
          : t('preview.notSupported')}
      </Typography>
      <Typography
        size={16}
        style={{ textAlign: 'center', color: '#666', marginTop: 8 }}
      >
        {t('preview.downloadHint')}
      </Typography>
    </View>
  );
};
