import { useMutation, useQueryClient } from '@tanstack/react-query';

import { apiClient } from '@/lib/apiClient';

import { folderQueryKeys } from './queryKeys';

type CreateFolderInput = {
  parentDirectoryID: string;
  name: string;
};

const createFolder = async ({ parentDirectoryID, name }: CreateFolderInput) => {
  const { data } = await apiClient.post('/directory', {
    parentDirectoryID: parentDirectoryID,
    name,
  });

  return data;
};

export const useCreateFolderMutation = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: createFolder,
    onSuccess: (_, { parentDirectoryID }) => {
      queryClient.invalidateQueries({
        queryKey: folderQueryKeys.folder(parentDirectoryID),
      });
    },
  });
};
