export const folderQueryKeys = {
  folder: (folderId: string | null) => ['folder', folderId || 'root'],
};
