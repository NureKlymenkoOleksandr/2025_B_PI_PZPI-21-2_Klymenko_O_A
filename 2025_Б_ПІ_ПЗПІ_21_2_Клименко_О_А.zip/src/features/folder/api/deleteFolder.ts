import { useMutation, useQueryClient } from '@tanstack/react-query';

import { apiClient } from '@/lib/apiClient';

import { folderQueryKeys } from './queryKeys';

type DeleteFolderInput = {
  id: string;
  parentDirectoryID: string;
};

const deleteFolder = async (folderId: string) => {
  const { data } = await apiClient.delete(`/directory/${folderId}`);
  return !!data;
};

export const useDeleteFolderMutation = () => {
  const queryClient = useQueryClient();

  return useMutation<boolean, Error, DeleteFolderInput>({
    mutationFn: (variables) => deleteFolder(variables.id),
    onSuccess: (_, { parentDirectoryID }) => {
      queryClient.invalidateQueries({
        queryKey: folderQueryKeys.folder(parentDirectoryID),
      });
    },
  });
};
