import { useMutation, useQueryClient } from '@tanstack/react-query';

import { Folder } from '@/features/file-system/types';
import { apiClient } from '@/lib/apiClient';

import { folderQueryKeys } from './queryKeys';

type RenameFolderPayload = {
  id: string;
  name: string;
};

type RenameFolderInput = {
  payload: RenameFolderPayload;
  parentDirectoryID: string;
};

const renameFolder = async ({ id, name }: RenameFolderPayload) => {
  const { data } = await apiClient.patch(
    `/directory/${id}/rename?name=${name}`,
  );
  return !!data;
};

export const useRenameFolderMutation = () => {
  const queryClient = useQueryClient();

  return useMutation<boolean, Error, RenameFolderInput>({
    mutationFn: (variables) => renameFolder(variables.payload),
    onSuccess: (_, { payload, parentDirectoryID }) => {
      queryClient.invalidateQueries({
        queryKey: folderQueryKeys.folder(parentDirectoryID),
      });
      queryClient.setQueriesData(
        { queryKey: folderQueryKeys.folder(payload.id) },
        (oldData: Folder) => {
          if (!oldData) return oldData;

          return {
            ...oldData,
            name: payload.name,
          };
        },
      );
    },
  });
};
