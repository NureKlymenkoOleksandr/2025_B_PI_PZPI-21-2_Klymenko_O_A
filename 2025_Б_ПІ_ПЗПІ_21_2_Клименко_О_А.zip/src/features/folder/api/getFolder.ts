import {
  infiniteQueryOptions,
  keepPreviousData,
  useInfiniteQuery,
} from '@tanstack/react-query';
import { useMemo } from 'react';

import { SortingParams } from '@/common/types/sorting';
import { FileSystemItem, Folder } from '@/features/file-system/types';
import { apiClient } from '@/lib/apiClient';

import { folderQueryKeys } from './queryKeys';

const ITEMS_PER_PAGE = 16;

type GetFolderResponse = {
  body: Folder;
};

type GetFolderPayload = SortingParams & {
  folderId: string;
};

type GetFolderInput = GetFolderPayload & {
  enabled?: boolean;
};

export const getFolder = async (
  { folderId, order, orderBy }: GetFolderPayload,
  page: number,
) => {
  const queryParams = new URLSearchParams({
    offset: ((page - 1) * ITEMS_PER_PAGE).toString(),
    limit: ITEMS_PER_PAGE.toString(),
    sortByField: orderBy,
    sortOrder: String(order === 'asc' ? 1 : -1),
  });

  const { data } = await apiClient.get<GetFolderResponse>(
    `/directory/${folderId}?${queryParams.toString()}`,
  );

  return data;
};

export const getFolderQueryOptions = ({
  enabled,
  folderId,
  order,
  orderBy,
}: GetFolderInput) => {
  return infiniteQueryOptions({
    queryKey: folderQueryKeys.folder(folderId).concat([order, orderBy]),
    queryFn: ({ pageParam = 1 }) =>
      getFolder({ folderId, order, orderBy }, pageParam),
    getNextPageParam: (data, _, lastPage) => {
      const totalCount = data.body.filesCount + data.body.directoriesCount;
      return lastPage * ITEMS_PER_PAGE < totalCount ? lastPage + 1 : null;
    },
    initialPageParam: 1,
    placeholderData: keepPreviousData,
    staleTime: Infinity,
    gcTime: Infinity,
    enabled,
  });
};

export const useFolder = (input: GetFolderInput) => {
  const { data, ...rest } = useInfiniteQuery(getFolderQueryOptions(input));

  return useMemo(() => {
    if (!data?.pages) return { data: null, ...rest };

    const { directories, files, ...folder } = data.pages[0].body;
    const totalItems = folder.directoriesCount + folder.filesCount;
    const items: FileSystemItem[] = data.pages.flatMap(({ body }) => {
      return [...(body.directories ?? []), ...(body.files ?? [])];
    });

    return { data: { folder, items, totalItems }, ...rest };
  }, [data?.pages]);
};
