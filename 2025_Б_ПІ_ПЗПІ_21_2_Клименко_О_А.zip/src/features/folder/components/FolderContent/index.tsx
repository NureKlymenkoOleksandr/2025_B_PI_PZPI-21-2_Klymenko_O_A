import { useIsFocused, useNavigation } from '@react-navigation/native';
import { useEffect, useState } from 'react';

import { Loader } from '@/common/components/Loader';
import { useSortingParamsStore } from '@/common/stores/sortingParamsStore';
import { useFileUploadStore } from '@/features/file/context';
import { FileSystemList } from '@/features/file-system/components/FileSystemList';
import { useFileSystemActionStore } from '@/features/file-system/stores/fileSystemActionStore';
import {
  FileSystemAction,
  FileSystemItemHandlers,
} from '@/features/file-system/types';
import { isFile } from '@/features/file-system/utils/isFile';
import { isFolder } from '@/features/file-system/utils/isFolder';
import { useFolder } from '@/features/folder/api/getFolder';
import { useScreenValueSetter } from '@/navigation/hooks/useScreenValueSetter';

type FolderContentProps = {
  folderId: string;
  folderOnly?: boolean;
  itemMenuHidden?: boolean;
  onFolderPress?: FileSystemItemHandlers['onFolderPress'];
};

export const FolderContent = ({
  folderId,
  folderOnly,
  itemMenuHidden,
  onFolderPress,
}: FolderContentProps) => {
  const { order, orderBy } = useSortingParamsStore(
    ({ setSortingParams: _, ...rest }) => rest,
  );
  const isFocused = useIsFocused();
  const [internalId, setInternalId] = useState(folderId);

  const { data, fetchNextPage, refetch } = useFolder({
    folderId: internalId,
    order,
    orderBy,
    enabled: isFocused,
  });

  useEffect(() => {
    if (data?.folder.id) {
      setInternalId(data.folder.id);
    }
  }, [data?.folder.id]);

  const setUploadFolderId = useFileUploadStore(
    (store) => store.setUploadFolderId,
  );
  const { currentItem, currentAction, setDestinationFolderId } =
    useFileSystemActionStore((store) => ({
      currentItem: store.currentItem,
      currentAction: store.currentAction,
      setDestinationFolderId: store.setDestinationFolderId,
    }));

  const handleScreenValue = (value: string | null) => {
    setUploadFolderId(value);
    setDestinationFolderId(value);
  };

  useScreenValueSetter(data?.folder.id ?? '', handleScreenValue);

  if (!data) return <Loader />;

  return (
    <FileSystemList
      totalItems={data.totalItems}
      onRefresh={refetch}
      items={data.items}
      onLastItem={fetchNextPage}
      itemHandlers={{
        onFolderPress,
      }}
      getDisabledState={(item) => {
        if (isFile(item)) {
          return !!folderOnly;
        }

        if (isFolder(item)) {
          return (
            currentAction === FileSystemAction.MOVE &&
            currentItem?.id === item.id
          );
        }

        return false;
      }}
      itemMenuHidden={itemMenuHidden}
    />
  );
};
