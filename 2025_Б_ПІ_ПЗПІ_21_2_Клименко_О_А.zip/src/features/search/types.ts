export enum SearchType {
  BOTH,
  FILES_ONLY,
  DIRECTORIES_ONLY,
}
