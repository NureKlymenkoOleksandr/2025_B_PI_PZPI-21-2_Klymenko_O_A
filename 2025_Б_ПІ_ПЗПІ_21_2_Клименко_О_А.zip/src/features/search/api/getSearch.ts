import {
  infiniteQueryOptions,
  keepPreviousData,
  useInfiniteQuery,
} from '@tanstack/react-query';
import { useMemo } from 'react';

import { SortingParams } from '@/common/types/sorting';
import {
  FileSystemContent,
  FileSystemItem,
} from '@/features/file-system/types';
import { SearchType } from '@/features/search/types';
import { apiClient } from '@/lib/apiClient';

type GetSearchResponse = {
  body: FileSystemContent;
};

type GetSearchPayload = SortingParams & {
  query: string;
  extensions?: string[];
  createdAtFrom?: string;
  createdAtTo?: string;
  updatedAtFrom?: string;
  updatedAtTo?: string;
};

type GetSearchInput = GetSearchPayload & {
  enabled?: boolean;
};

const ITEMS_PER_PAGE = 10;

export const getSearch = async (
  {
    query,
    order,
    orderBy,
    extensions,
    createdAtFrom,
    createdAtTo,
    updatedAtFrom,
    updatedAtTo,
  }: GetSearchPayload,
  page: number,
) => {
  const queryParams = new URLSearchParams({
    type: SearchType.BOTH.toString(),
    offset: ((page - 1) * ITEMS_PER_PAGE).toString(),
    limit: ITEMS_PER_PAGE.toString(),
    sortByField: orderBy,
    sortOrder: String(order === 'asc' ? 1 : -1),
    name: query,
  });

  if (extensions && extensions.length > 0) {
    extensions.forEach((extension) =>
      queryParams.append('extensions', extension),
    );
  }

  if (createdAtFrom) {
    queryParams.append('createdAtFrom', createdAtFrom);
  }
  if (createdAtTo) {
    queryParams.append('createdAtTo', createdAtTo);
  }
  if (updatedAtFrom) {
    queryParams.append('updatedAtFrom', updatedAtFrom);
  }
  if (updatedAtTo) {
    queryParams.append('updatedAtTo', updatedAtTo);
  }

  const { data } = await apiClient.get<GetSearchResponse>(
    `/directory/search?${queryParams.toString()}`,
  );

  return data;
};

const getSearchQueryOptions = ({
  enabled = true,
  ...payload
}: GetSearchInput) => {
  return infiniteQueryOptions({
    queryKey: [
      'search',
      payload.query,
      { order: payload.order, orderBy: payload.orderBy },
      payload.extensions,
      payload.createdAtFrom,
      payload.createdAtTo,
      payload.updatedAtFrom,
      payload.updatedAtTo,
    ],
    queryFn: ({ pageParam = 1 }) => getSearch(payload, pageParam),
    getNextPageParam: (data, _, lastPage) => {
      const totalCount = data.body.filesCount + data.body.directoriesCount;
      return lastPage * ITEMS_PER_PAGE < totalCount ? lastPage + 1 : null;
    },
    initialPageParam: 1,
    placeholderData: keepPreviousData,
    staleTime: 0,
    gcTime: 0,
  });
};

export const useSearch = (input: GetSearchInput) => {
  const { data, ...rest } = useInfiniteQuery({
    ...getSearchQueryOptions(input),
    enabled: input.enabled,
  });

  return useMemo(() => {
    if (!data?.pages)
      return { items: [] as FileSystemItem[], totalItems: 0, ...rest };

    const totalItems =
      data.pages[0].body.directoriesCount + data.pages[0].body.filesCount;
    const items: FileSystemItem[] = data.pages.flatMap(({ body }) => [
      ...(body.directories ?? []),
      ...(body.files ?? []),
    ]);

    return { items, totalItems, ...rest };
  }, [data]);
};
