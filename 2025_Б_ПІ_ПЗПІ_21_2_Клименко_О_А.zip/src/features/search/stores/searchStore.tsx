import { createContext, useContext, PropsWithChildren, useState } from 'react';
import { create, useStore } from 'zustand';
import { useShallow } from 'zustand/react/shallow';

export type FileTypeFilter = {
  id: string;
  nameKey: string;
  extensions: string[];
};

export const FILE_TYPE_FILTERS: FileTypeFilter[] = [
  {
    id: 'images',
    nameKey: 'search.fileTypes.images',
    extensions: [
      'jpg',
      'jpeg',
      'png',
      'gif',
      'bmp',
      'webp',
      'svg',
      'tiff',
      'ico',
      'heic',
    ],
  },
  {
    id: 'videos',
    nameKey: 'search.fileTypes.videos',
    extensions: [
      'mp4',
      'avi',
      'mov',
      'wmv',
      'flv',
      'webm',
      'mkv',
      '3gp',
      'm4v',
      'mpg',
      'mpeg',
    ],
  },
  {
    id: 'audio',
    nameKey: 'search.fileTypes.audio',
    extensions: [
      'mp3',
      'wav',
      'flac',
      'aac',
      'ogg',
      'm4a',
      'wma',
      'opus',
      'aiff',
    ],
  },
  {
    id: 'documents',
    nameKey: 'search.fileTypes.documents',
    extensions: ['pdf', 'doc', 'docx', 'txt', 'rtf', 'odt', 'pages'],
  },
];

export type DateFilterType = 'updatedAt' | 'createdAt';

export type DateRange = {
  startDate: Date | null;
  endDate: Date | null;
};

type SearchStore = {
  query: string;
  setQuery: (query: string) => void;
  reset: () => void;
  selectedFileTypes: string[];
  setSelectedFileTypes: (types: string[]) => void;
  toggleFileType: (typeId: string) => void;
  getSelectedExtensions: () => string[];
  updatedAtRange: DateRange;
  createdAtRange: DateRange;
  setDateRange: (type: DateFilterType, range: DateRange) => void;
};

const createSearchStore = () =>
  create<SearchStore>((set, get) => ({
    query: '',
    setQuery: (query: string) => set({ query }),
    reset: () =>
      set({
        query: '',
        selectedFileTypes: [],
        updatedAtRange: { startDate: null, endDate: null },
        createdAtRange: { startDate: null, endDate: null },
      }),
    selectedFileTypes: [],
    setSelectedFileTypes: (types) => set({ selectedFileTypes: types }),
    toggleFileType: (typeId) =>
      set((state) => ({
        selectedFileTypes: state.selectedFileTypes.includes(typeId)
          ? state.selectedFileTypes.filter((id) => id !== typeId)
          : [...state.selectedFileTypes, typeId],
      })),
    getSelectedExtensions: () => {
      const state = get();
      return state.selectedFileTypes.reduce<string[]>((extensions, typeId) => {
        const filter = FILE_TYPE_FILTERS.find((f) => f.id === typeId);
        return filter ? [...extensions, ...filter.extensions] : extensions;
      }, []);
    },
    updatedAtRange: { startDate: null, endDate: null },
    createdAtRange: { startDate: null, endDate: null },
    setDateRange: (type, range) =>
      set((state) => ({
        ...state,
        [type === 'updatedAt' ? 'updatedAtRange' : 'createdAtRange']: range,
      })),
  }));

const SearchContext = createContext<ReturnType<
  typeof createSearchStore
> | null>(null);

export const SearchProvider = ({ children }: PropsWithChildren) => {
  const [store] = useState(createSearchStore);

  return (
    <SearchContext.Provider value={store}>{children}</SearchContext.Provider>
  );
};

export const useSearchStore = <T,>(selector: (store: SearchStore) => T): T => {
  const store = useContext(SearchContext);

  if (!store) {
    throw new Error('useSearch must be used within SearchProvider');
  }

  return useStore(store, useShallow(selector));
};
