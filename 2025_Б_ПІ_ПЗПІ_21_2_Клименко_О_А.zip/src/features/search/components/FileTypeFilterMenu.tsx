import { useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { StyleSheet, View } from 'react-native';

import {
  BottomSheet,
  BottomSheetRef,
  BottomSheetView,
} from '@/common/components/bottom-sheet';
import { MenuDivider, MenuItem } from '@/common/components/menu';
import { Radio } from '@/common/components/Radio';
import { Typography } from '@/common/components/Typography';
import { useControlledBottomSheet } from '@/common/hooks/useControlledBottomSheet';
import {
  FILE_TYPE_FILTERS,
  useSearchStore,
} from '@/features/search/stores/searchStore';

interface FileTypeFilterMenuProps {
  isVisible: boolean;
  onClose: () => void;
}

export const FileTypeFilterMenu = ({
  isVisible,
  onClose,
}: FileTypeFilterMenuProps) => {
  const bottomSheetRef = useRef<BottomSheetRef>(null);
  const { t } = useTranslation();
  const { selectedFileTypes, toggleFileType } = useSearchStore((store) => ({
    selectedFileTypes: store.selectedFileTypes,
    toggleFileType: store.toggleFileType,
  }));

  useControlledBottomSheet(bottomSheetRef, isVisible);

  return (
    <BottomSheet ref={bottomSheetRef} onClose={onClose} name="file-type-menu">
      <BottomSheetView>
        <View style={styles.header}>
          <Typography size={20}>{t('search.fileTypes')}</Typography>
        </View>
        <MenuDivider />
        {FILE_TYPE_FILTERS.map((filter) => (
          <MenuItem
            key={filter.id}
            title={t(filter.nameKey)}
            onPress={() => toggleFileType(filter.id)}
            secondaryAction={
              <Radio
                selected={selectedFileTypes.includes(filter.id)}
                size={20}
              />
            }
          />
        ))}
      </BottomSheetView>
    </BottomSheet>
  );
};

const styles = StyleSheet.create({
  header: {
    padding: 16,
  },
});
