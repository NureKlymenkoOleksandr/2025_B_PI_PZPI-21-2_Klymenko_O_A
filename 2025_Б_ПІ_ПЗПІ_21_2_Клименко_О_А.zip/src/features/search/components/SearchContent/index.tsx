import { View } from 'react-native';

import { Loader } from '@/common/components/Loader';
import { useSortingParamsStore } from '@/common/stores/sortingParamsStore';
import { FileSystemList } from '@/features/file-system/components/FileSystemList';
import { useSearch } from '@/features/search/api/getSearch';
import { useSearchStore } from '@/features/search/stores/searchStore';

type SearchContentProps = {
  query: string;
};

export const SearchContent = ({ query }: SearchContentProps) => {
  const { order, orderBy } = useSortingParamsStore(({ order, orderBy }) => ({
    order,
    orderBy,
  }));
  const {
    selectedFileTypes,
    getSelectedExtensions,
    updatedAtRange,
    createdAtRange,
  } = useSearchStore((store) => ({
    selectedFileTypes: store.selectedFileTypes,
    getSelectedExtensions: store.getSelectedExtensions,
    updatedAtRange: store.updatedAtRange,
    createdAtRange: store.createdAtRange,
  }));

  const hasActiveFilters =
    query.trim().length > 0 ||
    selectedFileTypes.length > 0 ||
    updatedAtRange.startDate !== null ||
    updatedAtRange.endDate !== null ||
    createdAtRange.startDate !== null ||
    createdAtRange.endDate !== null;

  const formatDate = (date: Date | null) => {
    if (!date) return undefined;
    return date.toISOString();
  };

  const { items, totalItems, refetch, fetchNextPage, isLoading } = useSearch({
    query,
    order,
    orderBy,
    extensions:
      selectedFileTypes.length > 0 ? getSelectedExtensions() : undefined,
    createdAtFrom: formatDate(createdAtRange.startDate),
    createdAtTo: formatDate(createdAtRange.endDate),
    updatedAtFrom: formatDate(updatedAtRange.startDate),
    updatedAtTo: formatDate(updatedAtRange.endDate),
    enabled: hasActiveFilters,
  });

  const listItems = hasActiveFilters ? items : [];

  if (!listItems && isLoading) return <Loader />;

  return (
    <FileSystemList
      onRefresh={refetch}
      items={listItems}
      onLastItem={() => {
        if (hasActiveFilters) {
          fetchNextPage();
        }
      }}
      totalItems={hasActiveFilters ? totalItems : null}
      emptyStateComponent={<View />}
    />
  );
};
