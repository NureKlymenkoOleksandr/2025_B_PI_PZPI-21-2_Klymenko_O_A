import { useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { StyleSheet, View, Pressable } from 'react-native';
import DatePicker from 'react-native-date-picker';

import {
  BottomSheet,
  BottomSheetRef,
  BottomSheetView,
} from '@/common/components/bottom-sheet';
import { MenuDivider } from '@/common/components/menu';
import { Typography } from '@/common/components/Typography';
import { useControlledBottomSheet } from '@/common/hooks/useControlledBottomSheet';
import { useTheme } from '@/common/theme';
import {
  DateFilterType,
  DateRange,
  useSearchStore,
} from '@/features/search/stores/searchStore';

interface DateFilterMenuProps {
  isVisible: boolean;
  onClose: () => void;
  type: DateFilterType;
}

export const DateFilterMenu = ({
  isVisible,
  onClose,
  type,
}: DateFilterMenuProps) => {
  const bottomSheetRef = useRef<BottomSheetRef>(null);
  const { t } = useTranslation();
  const { colors } = useTheme();
  const [showStartPicker, setShowStartPicker] = useState(false);
  const [showEndPicker, setShowEndPicker] = useState(false);

  const { updatedAtRange, createdAtRange, setDateRange } = useSearchStore(
    (store) => ({
      updatedAtRange: store.updatedAtRange,
      createdAtRange: store.createdAtRange,
      setDateRange: store.setDateRange,
    }),
  );

  const currentRange = type === 'updatedAt' ? updatedAtRange : createdAtRange;

  useControlledBottomSheet(bottomSheetRef, isVisible);

  const handleDateChange = (date: Date, isStart: boolean) => {
    const newDate = new Date(date);
    if (isStart) {
      newDate.setHours(0, 0, 0, 0);
    } else {
      newDate.setHours(23, 59, 59, 999);
    }

    const newRange: DateRange = {
      ...currentRange,
      [isStart ? 'startDate' : 'endDate']: newDate,
    };
    setDateRange(type, newRange);
  };

  const formatDate = (date: Date | null) => {
    if (!date) return t('search.dateFilters.selectDate');
    return date.toLocaleDateString();
  };

  return (
    <BottomSheet ref={bottomSheetRef} onClose={onClose} name="date-filter-menu">
      <BottomSheetView>
        <View style={styles.header}>
          <Typography size={20}>
            {t(`search.dateFilters.${type}Title`)}
          </Typography>
        </View>
        <MenuDivider />
        <View style={styles.dateContainer}>
          <Pressable
            style={[
              styles.dateButton,
              { backgroundColor: colors.surfaceSubtle },
            ]}
            onPress={() => setShowStartPicker(true)}
          >
            <Typography size={14}>
              {t('search.dateFilters.startDate')}:{' '}
              {formatDate(currentRange.startDate)}
            </Typography>
          </Pressable>
          <Pressable
            style={[
              styles.dateButton,
              { backgroundColor: colors.surfaceSubtle },
            ]}
            onPress={() => setShowEndPicker(true)}
          >
            <Typography size={14}>
              {t('search.dateFilters.endDate')}:{' '}
              {formatDate(currentRange.endDate)}
            </Typography>
          </Pressable>
        </View>
      </BottomSheetView>

      <DatePicker
        modal
        open={showStartPicker}
        date={currentRange.startDate || new Date()}
        onConfirm={(date) => {
          console.log('confirm start', date);
          handleDateChange(date, true);
          setShowStartPicker(false);
        }}
        onCancel={() => setShowStartPicker(false)}
        mode="date"
      />

      <DatePicker
        modal
        open={showEndPicker}
        date={currentRange.endDate || new Date()}
        onConfirm={(date) => {
          console.log('confirm end', date);
          handleDateChange(date, false);
          setShowEndPicker(false);
        }}
        onCancel={() => setShowEndPicker(false)}
        mode="date"
      />
    </BottomSheet>
  );
};

const styles = StyleSheet.create({
  header: {
    padding: 16,
  },
  dateContainer: {
    padding: 16,
    gap: 12,
  },
  dateButton: {
    padding: 12,
    borderRadius: 8,
  },
});
