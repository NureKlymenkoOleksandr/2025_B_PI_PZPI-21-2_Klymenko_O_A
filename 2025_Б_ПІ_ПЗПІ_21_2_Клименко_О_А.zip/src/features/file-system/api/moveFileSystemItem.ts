import { useMutation, useQueryClient } from '@tanstack/react-query';

import { fileQueryKeys } from '@/features/file/api/queryKeys';
import { FileSystemItem } from '@/features/file-system/types';
import { folderQueryKeys } from '@/features/folder/api/queryKeys';
import { apiClient } from '@/lib/apiClient';

type MoveFileSystemItemPayload = {
  id: string;
  destinationFolderId: string;
  type: 'directory' | 'file';
};

type MoveFileSystemItemInput = {
  payload: MoveFileSystemItemPayload;
  parentDirectoryID: string;
};

export const moveFileSystemItem = async ({
  id,
  destinationFolderId,
  type,
}: MoveFileSystemItemPayload) => {
  const response = await apiClient.patch(
    `/${type}/${id}/move?to=${destinationFolderId}`,
  );

  return !!response;
};

export const useMoveFileSystemItemMutation = (
  fileSystemItem?: FileSystemItem | null,
) => {
  const queryClient = useQueryClient();

  return useMutation<boolean, Error, MoveFileSystemItemInput>({
    onSuccess: (_, { parentDirectoryID, payload }) => {
      queryClient.invalidateQueries({
        queryKey: folderQueryKeys.folder(parentDirectoryID),
      });
      queryClient.invalidateQueries({
        queryKey: folderQueryKeys.folder(payload.destinationFolderId),
      });
      if (fileSystemItem?.starred) {
        queryClient.invalidateQueries({
          queryKey: fileQueryKeys.starred(),
        });
      }
    },
    mutationFn: (variables) => moveFileSystemItem(variables.payload),
  });
};
