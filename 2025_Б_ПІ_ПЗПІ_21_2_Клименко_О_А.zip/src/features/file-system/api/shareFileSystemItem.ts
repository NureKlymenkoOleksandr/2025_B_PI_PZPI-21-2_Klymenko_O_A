import { useMutation, useQueryClient } from '@tanstack/react-query';

import { fileQueryKeys } from '@/features/file/api/queryKeys';
import { FileSystemItem } from '@/features/file-system/types';
import { isFile } from '@/features/file-system/utils/isFile';
import { folderQueryKeys } from '@/features/folder/api/queryKeys';
import { apiClient } from '@/lib/apiClient';

type ShareFileSystemItemPayload = {
  id: string;
  isPublic: boolean;
  type: 'directory' | 'file';
};

type ShareFileSystemItemInput = {
  payload: ShareFileSystemItemPayload;
  parentDirectoryID: string;
};

const shareFileSystemItem = async ({
  type,
  id,
  isPublic,
}: ShareFileSystemItemPayload) => {
  const { data } = await apiClient.patch(
    `/${type}/${id}/share?public=${isPublic}`,
  );
  return !!data;
};

export const useShareFileSystemItemMutation = (
  fileSystemItem?: FileSystemItem | null,
) => {
  const queryClient = useQueryClient();

  return useMutation<boolean, Error, ShareFileSystemItemInput>({
    mutationFn: (variables) => shareFileSystemItem(variables.payload),
    onSuccess: (_, { parentDirectoryID }) => {
      queryClient.invalidateQueries({
        queryKey: folderQueryKeys.folder(parentDirectoryID),
      });
      if (fileSystemItem?.starred) {
        queryClient.invalidateQueries({
          queryKey: fileQueryKeys.starred(),
        });
      }
    },
  });
};
