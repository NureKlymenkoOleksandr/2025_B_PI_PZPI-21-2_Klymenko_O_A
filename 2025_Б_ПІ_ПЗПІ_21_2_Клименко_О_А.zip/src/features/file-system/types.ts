export type FileSystemItem = {
  id: string;
  name: string;
  parentDirectoryID: string;
  size: number;
  createdAt: string;
  updatedAt: string;
  public: boolean;
  starred: boolean;
};

export type File = FileSystemItem & {
  extension: string;
};

export type FileSystemContent = {
  directoriesCount: number;
  directories: Folder[];
  files: File[];
  filesCount: number;
};

export type Folder = FileSystemItem &
  FileSystemContent & {
    parentDirectoryID: string | null;
    path: string[];
  };

export type FileSystemItemHandlers = Partial<{
  onFolderPress: (folder: Folder) => void;
  onFilePress: (file: File) => void;
}>;

export enum FileSystemAction {
  RENAME = 'rename',
  MOVE = 'move',
  DELETE = 'delete',
  DOWNLOAD = 'download',
  CREATE_FOLDER = 'create_folder',
  UPLOAD_FILE = 'upload_file',
  MANAGE_ACCESS = 'manage_access',
}
