import { FileSystemItem, Folder } from '@/features/file-system/types';

export const isFolder = (item: FileSystemItem): item is Folder =>
  'path' in item;
