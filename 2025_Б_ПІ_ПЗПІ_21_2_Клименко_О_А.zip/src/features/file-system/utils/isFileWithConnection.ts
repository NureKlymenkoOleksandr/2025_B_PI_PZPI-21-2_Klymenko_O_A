import { FileWithConnection } from '@/features/file/types';
import { FileSystemItem } from '@/features/file-system/types';

export const isFileWithConnection = (
  file: FileSystemItem,
): file is FileWithConnection => 'connectionID' in file;
