import { createURL } from "expo-linking";

import { FileSystemItem } from "@/features/file-system/types";

export const createShareUrl = (file: FileSystemItem) => {
  return createURL(`/file/${file.id}`)
}