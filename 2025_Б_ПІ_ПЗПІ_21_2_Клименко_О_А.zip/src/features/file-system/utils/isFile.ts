import { File, FileSystemItem } from '@/features/file-system/types';

export const isFile = (item: FileSystemItem | null): item is File =>
  !!item && 'extension' in item;
