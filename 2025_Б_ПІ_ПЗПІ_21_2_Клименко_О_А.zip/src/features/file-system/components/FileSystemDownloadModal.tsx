import { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { StyleSheet, View } from 'react-native';

import { CircularProgress } from '@/common/components/CircularProgress';
import { BaseModal } from '@/common/components/modals/BaseModal';
import { Typography } from '@/common/components/Typography';
import { shouldSaveToGallery } from '@/common/utils/mimeType';
import { useFileDownload } from '@/features/file/hooks/useFileDownload';
import { useFileSystemActionStore } from '@/features/file-system/stores/fileSystemActionStore';
import { FileSystemAction } from '@/features/file-system/types';
import { isFile } from '@/features/file-system/utils/isFile';
import { isFileWithConnection } from '@/features/file-system/utils/isFileWithConnection';

export const FileSystemDownloadModal = () => {
  const { t } = useTranslation();
  const { currentItem, currentAction, resetAction } = useFileSystemActionStore(
    (store) => ({
      currentItem: store.currentItem,
      currentAction: store.currentAction,
      resetAction: store.resetAction,
    }),
  );

  const isDownloading =
    isFile(currentItem) && currentAction === FileSystemAction.DOWNLOAD;
  const isGalleryFile =
    isDownloading && shouldSaveToGallery(currentItem?.extension);

  const { downloadProgress, downloadFile, cancelDownload, resetDownload } =
    useFileDownload();

  const handleCancel = async () => {
    await cancelDownload();
    resetAction();
  };

  useEffect(() => {
    const startDownload = async () => {
      if (isDownloading) {
        await downloadFile(currentItem, {
          shouldCloseConnection: !isFileWithConnection(currentItem),
          shouldSave: true,
        });
        resetAction();
        resetDownload();
      }
    };

    startDownload();
  }, [isDownloading]);

  return (
    <BaseModal
      visible={isDownloading}
      title={t(
        isGalleryFile ? 'file.savingToGallery' : 'file.preparingForExport',
      )}
      onRequestClose={handleCancel}
    >
      <View style={styles.progressContainer}>
        <CircularProgress
          size={40}
          progress={downloadProgress}
          strokeWidth={5}
        />
        <Typography weight="semiBold">
          {Math.round(downloadProgress * 100)}%
        </Typography>
      </View>
    </BaseModal>
  );
};

const styles = StyleSheet.create({
  progressContainer: {
    marginTop: 16,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
  },
});
