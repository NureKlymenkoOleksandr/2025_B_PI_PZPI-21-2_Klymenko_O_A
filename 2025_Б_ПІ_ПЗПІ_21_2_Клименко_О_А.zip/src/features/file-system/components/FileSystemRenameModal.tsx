import { useTranslation } from 'react-i18next';

import { InputModal } from '@/common/components/modals/InputModal';
import { useRenameFileMutation } from '@/features/file/api/renameFile';
import { useFileSystemActionStore } from '@/features/file-system/stores/fileSystemActionStore';
import { FileSystemAction } from '@/features/file-system/types';
import { isFile } from '@/features/file-system/utils/isFile';
import { useRenameFolderMutation } from '@/features/folder/api/renameFolder';

export const FileSystemRenameModal = () => {
  const { t } = useTranslation();
  const { currentAction, currentItem, resetAction } = useFileSystemActionStore(
    (store) => ({
      currentItem: store.currentItem,
      currentAction: store.currentAction,
      resetAction: store.resetAction,
    }),
  );

  const renameFileMutation = useRenameFileMutation();
  const renameFolderMutation = useRenameFolderMutation();

  const isFileItem = isFile(currentItem);
  const isVisible = currentAction === FileSystemAction.RENAME && !!currentItem;

  const handleRename = async (name: string) => {
    if (!currentItem) return;
    const payload = {
      id: currentItem.id,
      name,
    };

    if (isFileItem) {
      await renameFileMutation.mutateAsync({
        payload,
        parentDirectoryID: currentItem.parentDirectoryID,
      });
    } else {
      await renameFolderMutation.mutateAsync({
        payload,
        parentDirectoryID: currentItem.parentDirectoryID,
      });
    }
    resetAction();
  };

  return (
    <InputModal
      visible={isVisible}
      title={t(isFileItem ? 'file.rename' : 'folder.rename')}
      onClose={resetAction}
      actionText={t('common.rename')}
      initialValue={currentItem?.name}
      onAction={handleRename}
    />
  );
};
