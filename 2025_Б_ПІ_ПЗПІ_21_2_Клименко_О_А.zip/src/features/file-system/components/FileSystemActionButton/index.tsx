import { useTranslation } from 'react-i18next';
import { Pressable } from 'react-native';

import { Typography } from '@/common/components/Typography';
import { useTheme } from '@/common/theme';
import { useMoveFileSystemItemMutation } from '@/features/file-system/api/moveFileSystemItem';
import { useFileSystemActionStore } from '@/features/file-system/stores/fileSystemActionStore';
import { isFolder } from '@/features/file-system/utils/isFolder';
import { useRootNavigation } from '@/navigation/hooks/useRootNavigation';

export const FileSystemActionButton = () => {
  const { t } = useTranslation();
  const { colors } = useTheme();
  const navigation = useRootNavigation();

  const { currentItem, destinationFolderId } = useFileSystemActionStore(
    (store) => ({
      currentItem: store.currentItem,
      destinationFolderId: store.destinationFolderId,
    }),
  );

  const moveFileSystemItemMutation = useMoveFileSystemItemMutation();

  const isActionDisabled =
    moveFileSystemItemMutation.isPending ||
    destinationFolderId === currentItem?.parentDirectoryID;

  console.log(
    'AAAAA',
    moveFileSystemItemMutation.isPending,
    destinationFolderId === currentItem?.parentDirectoryID,
  );

  const handlePress = async () => {
    if (!currentItem || !destinationFolderId) return;

    const payload = {
      id: currentItem.id,
      destinationFolderId,
      type: isFolder(currentItem) ? 'directory' : 'file',
    } as const;

    await moveFileSystemItemMutation.mutateAsync({
      payload,
      parentDirectoryID: currentItem.parentDirectoryID,
    });

    navigation.popToTop();
  };

  return (
    <Pressable
      disabled={isActionDisabled}
      onPress={handlePress}
      style={{
        marginTop: 'auto',
        justifyContent: 'center',
        alignItems: 'center',
        height: 60,
        backgroundColor: colors.primary,
        opacity: isActionDisabled ? 0.6 : 1,
      }}
    >
      <Typography color={colors.contrastText}>{t('common.move')}</Typography>
    </Pressable>
  );
};
