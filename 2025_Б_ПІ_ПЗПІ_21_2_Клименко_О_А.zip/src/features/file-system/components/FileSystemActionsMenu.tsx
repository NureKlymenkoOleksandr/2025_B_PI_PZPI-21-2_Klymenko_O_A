import Ionicons from '@expo/vector-icons/Ionicons';
import { useRef } from 'react';
import { useTranslation } from 'react-i18next';

import {
  BottomSheet,
  BottomSheetRef,
  BottomSheetView,
} from '@/common/components/bottom-sheet';
import { MenuItem } from '@/common/components/menu';
import { MenuDivider } from '@/common/components/menu/MenuDivider';
import { useControlledBottomSheet } from '@/common/hooks/useControlledBottomSheet';
import { useTheme } from '@/common/theme';
import { useStarFileMutation } from '@/features/file/api/starFIle';
import { useShareFileSystemItemMutation } from '@/features/file-system/api/shareFileSystemItem';
import { useFileSystemActionStore } from '@/features/file-system/stores/fileSystemActionStore';
import { FileSystemAction } from '@/features/file-system/types';
import { createShareUrl } from '@/features/file-system/utils/createShareUrl';
import { isFile } from '@/features/file-system/utils/isFile';
import { isFolder } from '@/features/file-system/utils/isFolder';
import { useRootNavigation } from '@/navigation/hooks/useRootNavigation';

export const FileSystemActionsMenu = () => {
  const { t } = useTranslation();
  const { colors } = useTheme();
  const navigation = useRootNavigation();
  const bottomSheetRef = useRef<BottomSheetRef>(null);
  const shouldResetOnClose = useRef(true);

  const { currentItem, currentAction, resetAction, setCurrentAction } =
    useFileSystemActionStore((store) => ({
      currentItem: store.currentItem,
      resetAction: store.resetAction,
      setCurrentAction: store.setCurrentAction,
      currentAction: store.currentAction,
    }));

  const starFileMutation = useStarFileMutation();
  const handleStar = () => {
    if (isFile(currentItem)) {
      starFileMutation.mutate(currentItem);
    }
    bottomSheetRef.current?.close();
  };

  const shareFileSystemItemMutation =
    useShareFileSystemItemMutation(currentItem);
  const handleShare = () => {
    if (!currentItem) return;
    const isPublic = !currentItem.public;

    shareFileSystemItemMutation.mutate({
      payload: {
        id: currentItem.id,
        isPublic,
        type: isFolder(currentItem) ? 'directory' : 'file',
      },
      parentDirectoryID: currentItem.parentDirectoryID,
    });

    if (isPublic) {
      console.log(createShareUrl(currentItem));
    }

    bottomSheetRef.current?.close();
  };

  useControlledBottomSheet(bottomSheetRef, !!(currentItem && !currentAction));

  const handleMenuAction = (action: FileSystemAction) => () => {
    if (action === FileSystemAction.MOVE) {
      navigation.navigate('FoldersMove', {
        screen: 'FolderMove',
        params: {
          folderId: '',
          folderName: t('myStore'),
        },
      });
    }
    setCurrentAction(action);
    shouldResetOnClose.current = false;
    bottomSheetRef.current?.close();
  };

  const handleMenuClose = () => {
    if (shouldResetOnClose.current) {
      resetAction();
    }
    shouldResetOnClose.current = true;
  };

  return (
    <BottomSheet
      name="file-system-actions-menu"
      ref={bottomSheetRef}
      onClose={handleMenuClose}
    >
      <BottomSheetView>
        {isFile(currentItem) && (
          <MenuItem
            title={t('common.download')}
            onPress={handleMenuAction(FileSystemAction.DOWNLOAD)}
            icon={<Ionicons name="download" size={20} color={colors.primary} />}
          />
        )}
        <MenuItem
          title={t('common.rename')}
          onPress={handleMenuAction(FileSystemAction.RENAME)}
          icon={<Ionicons name="pencil" size={20} color={colors.primary} />}
        />
        <MenuDivider />

        <MenuItem
          title={
            currentItem?.starred
              ? t('common.removeFromStarred')
              : t('common.addToStarred')
          }
          onPress={handleStar}
          icon={
            <Ionicons
              name={currentItem?.starred ? 'star-outline' : 'star'}
              size={20}
              color={colors.primary}
            />
          }
        />

        {isFile(currentItem) && (
          <MenuItem
            title={
              currentItem?.public
                ? t('common.makePrivate')
                : t('common.makePublic')
            }
            onPress={handleShare}
            icon={
              <Ionicons
                name={currentItem?.public ? 'unlink' : 'link'}
                size={20}
                color={colors.primary}
              />
            }
          />
        )}
        <MenuDivider />
        <MenuItem
          title={t('common.move')}
          onPress={handleMenuAction(FileSystemAction.MOVE)}
          icon={<Ionicons name="move" size={20} color={colors.primary} />}
        />
        <MenuItem
          title={t('common.delete')}
          onPress={handleMenuAction(FileSystemAction.DELETE)}
          icon={<Ionicons name="trash" size={20} color={colors.primary} />}
        />
      </BottomSheetView>
    </BottomSheet>
  );
};
