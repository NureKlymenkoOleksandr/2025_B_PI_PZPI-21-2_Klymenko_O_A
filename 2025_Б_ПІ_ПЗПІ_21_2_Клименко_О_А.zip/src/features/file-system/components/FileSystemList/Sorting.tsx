import { useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { Pressable, StyleSheet, View } from 'react-native';

import { BottomSheetRef } from '@/common/components/bottom-sheet';
import { SortingIcon } from '@/common/components/SortingIcon';
import { Typography } from '@/common/components/Typography';
import { useSortingParamsStore } from '@/common/stores/sortingParamsStore';
import { useTheme } from '@/common/theme';

import { SortingMenu } from './SortingMenu';

export const FileSystemListSorting = () => {
  const { colors } = useTheme();
  const sortingMenuRef = useRef<BottomSheetRef>(null);
  const { t } = useTranslation();
  const { order, orderBy } = useSortingParamsStore(({ order, orderBy }) => ({
    order,
    orderBy,
  }));

  return (
    <>
      <Pressable
        testID="fs-sorting"
        onPress={() => {
          sortingMenuRef.current?.present();
        }}
        hitSlop={{ left: 16, right: 16, bottom: 8, top: 8 }}
        style={({ pressed }) => [
          styles.label,
          pressed && { backgroundColor: colors.surfaceSubtle },
        ]}
      >
        <SortingIcon isAsc={order === 'asc'} size={20} />
        <Typography>{t(`sorting.${orderBy}`)}</Typography>
      </Pressable>
      <SortingMenu ref={sortingMenuRef} />
    </>
  );
};

const styles = StyleSheet.create({
  label: {
    flexDirection: 'row',
    gap: 8,
    paddingInlineStart: 8,
    paddingInlineEnd: 16,
    paddingBlock: 8,
    alignItems: 'center',
    borderRadius: 1000,
  },
  // pressed: {

  // },
});
