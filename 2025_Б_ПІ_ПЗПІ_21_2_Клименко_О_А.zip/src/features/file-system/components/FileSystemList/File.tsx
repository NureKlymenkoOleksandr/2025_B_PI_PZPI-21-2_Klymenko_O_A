import FontAwesome from '@expo/vector-icons/FontAwesome';
import { useNavigation } from '@react-navigation/native';

import { useTheme } from '@/common/theme';
import { useFileSystemActionStore } from '@/features/file-system/stores/fileSystemActionStore';
import { File } from '@/features/file-system/types';

import { FileSystemListItem } from './Item';

type FileItemProps = {
  file: File;
  disabled?: boolean;
  menuHidden?: boolean;
  onPress?: (file: File) => void;
};

export const FileItem = ({
  file,
  disabled,
  menuHidden,
  onPress,
}: FileItemProps) => {
  const { colors } = useTheme();
  const setCurrentItem = useFileSystemActionStore(
    (store) => store.setCurrentItem,
  );
  const navigation = useNavigation();

  const handleFilePress = async () => {
    if (onPress) {
      onPress(file);
      return;
    }

    navigation.navigate('File', {
      id: file.id,
    });
  };

  const handleMenuPress = () => {
    setCurrentItem(file);
  };

  return (
    <FileSystemListItem
      item={file}
      adornment={<FontAwesome name="file" size={20} color={colors.primary} />}
      onPress={handleFilePress}
      disabled={disabled}
      menuHidden={menuHidden}
      onMenuPress={handleMenuPress}
    />
  );
};
