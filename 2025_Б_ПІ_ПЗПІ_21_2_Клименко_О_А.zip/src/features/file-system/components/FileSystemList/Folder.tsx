import FontAwesome from '@expo/vector-icons/FontAwesome';

import { useTheme } from '@/common/theme';
import { useFileSystemActionStore } from '@/features/file-system/stores/fileSystemActionStore';
import { Folder } from '@/features/file-system/types';
import { useRootNavigation } from '@/navigation/hooks/useRootNavigation';

import { FileSystemListItem } from './Item';

type FolderItemProps = {
  folder: Folder;
  menuHidden?: boolean;
  onPress?: (folder: Folder) => void;
  disabled?: boolean;
};

export const FolderItem = ({
  folder,
  menuHidden,
  onPress,
  disabled,
}: FolderItemProps) => {
  const navigation = useRootNavigation();
  const { colors } = useTheme();
  const setCurrentItem = useFileSystemActionStore(
    (store) => store.setCurrentItem,
  );

  const handleFolderPress = () => {
    if (onPress) {
      onPress(folder);
      return;
    }

    navigation.push('Folders', {
      screen: 'Folder',
      params: {
        folderId: folder.id,
        folderName: folder.name,
      },
    });
  };

  const handleMenuPress = () => {
    setCurrentItem(folder);
  };

  return (
    <FileSystemListItem
      item={folder}
      adornment={<FontAwesome name="folder" size={22} color={colors.primary} />}
      onPress={handleFolderPress}
      onMenuPress={handleMenuPress}
      menuHidden={menuHidden}
      disabled={disabled}
    />
  );
};
