import { useTranslation } from 'react-i18next';
import { StyleSheet, View } from 'react-native';

import { Typography } from '@/common/components/Typography';
import { FolderIcon } from '@/common/icons/FolderIcon';
import { useTheme } from '@/common/theme';

type EmptyStateProps = {
  icon?: React.ReactNode;
  title?: string;
  description?: string;
  translationKey?: {
    title: string;
    description: string;
  };
};

export const EmptyState = ({
  icon,
  title,
  description,
  translationKey,
}: EmptyStateProps) => {
  const { t } = useTranslation();
  const { colors } = useTheme();

  const defaultIcon = (
    <FolderIcon width={64} height={64} fill={colors.primary} />
  );
  const defaultTranslationKey = {
    title: 'fileSystem.empty.title',
    description: 'fileSystem.empty.description',
  };

  const finalIcon = icon ?? defaultIcon;
  const finalTranslationKey = translationKey ?? defaultTranslationKey;

  return (
    <View style={styles.container}>
      {finalIcon}
      <Typography size={20} weight="semiBold" style={styles.title}>
        {title ?? t(finalTranslationKey.title)}
      </Typography>
      <Typography
        size={16}
        style={[styles.description, { color: colors.text }]}
      >
        {description ?? t(finalTranslationKey.description)}
      </Typography>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 120,
    paddingHorizontal: 24,
  },
  title: {
    marginTop: 16,
    marginBottom: 8,
    textAlign: 'center',
  },
  description: {
    textAlign: 'center',
  },
});
