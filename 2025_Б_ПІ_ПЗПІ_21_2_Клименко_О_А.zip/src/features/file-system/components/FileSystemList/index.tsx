import { ReactElement, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { FlatList, RefreshControl, StyleSheet, View } from 'react-native';

import { Typography } from '@/common/components/Typography';
import { useTheme } from '@/common/theme';
import {
  FileSystemItem,
  FileSystemItemHandlers,
} from '@/features/file-system/types';
import { isFile } from '@/features/file-system/utils/isFile';
import { isFolder } from '@/features/file-system/utils/isFolder';

import { EmptyState } from './EmptyState';
import { FileItem } from './File';
import { FolderItem } from './Folder';
import { FileSystemListSorting } from './Sorting';

type FileSystemListProps = {
  items: FileSystemItem[];
  totalItems: number | null;
  onLastItem?: () => void;
  onRefresh?: VoidFunction | (() => Promise<void>);
  getDisabledState?: (item: FileSystemItem) => boolean;
  itemHandlers?: FileSystemItemHandlers;
  itemMenuHidden?: boolean;
  emptyStateComponent?: ReactElement;
};

export const FileSystemList = ({
  totalItems,
  items,
  onRefresh,
  onLastItem,
  getDisabledState,
  itemHandlers,
  itemMenuHidden,
  emptyStateComponent,
}: FileSystemListProps) => {
  const { t } = useTranslation();
  const { colors } = useTheme();
  const [isRefreshing, setIsRefreshing] = useState(false);

  const handleRefetch = async () => {
    setIsRefreshing(true);
    await onRefresh?.();
    setIsRefreshing(false);
  };

  return (
    <FlatList
      testID="fs-list"
      onEndReached={onLastItem}
      refreshControl={
        <RefreshControl
          refreshing={isRefreshing}
          onRefresh={handleRefetch}
          colors={[colors.primary]}
          progressBackgroundColor={colors.surfaceSubtle}
        />
      }
      ListHeaderComponent={
        <View style={styles.header}>
          <Typography weight="semiBold">
            {/* FIX ME */}
            {!Number.isNaN(Number(totalItems ?? undefined)) &&
              t('fileSystem.itemsCount', { count: totalItems ?? 0 })}
          </Typography>
          <FileSystemListSorting />
        </View>
      }
      ListEmptyComponent={emptyStateComponent ?? EmptyState}
      renderItem={({ item }) =>
        isFolder(item) ? (
          <FolderItem
            key={item.id}
            folder={item}
            onPress={itemHandlers?.onFolderPress}
            disabled={getDisabledState?.(item)}
            menuHidden={itemMenuHidden}
          />
        ) : isFile(item) ? (
          <FileItem
            key={item.id}
            file={item}
            onPress={itemHandlers?.onFilePress}
            disabled={getDisabledState?.(item)}
            menuHidden={itemMenuHidden}
          />
        ) : null
      }
      data={items}
    />
  );
};

const styles = StyleSheet.create({
  header: {
    marginBlockStart: 8,
    marginInline: 12,
    marginInlineEnd: 4,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
});
