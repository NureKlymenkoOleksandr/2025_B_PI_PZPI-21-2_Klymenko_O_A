import { Pressable, StyleSheet, View } from 'react-native';
import Animated, {
  Easing,
  FadeInUp,
  FadeOutUp,
  LinearTransition,
} from 'react-native-reanimated';

import { Typography } from '@/common/components/Typography';
import { MenuVerticalIcon } from '@/common/icons/MenuVerticalIcon';
import { useTheme } from '@/common/theme';
import { FileSystemItem } from '@/features/file-system/types';

type FileSystemListItemProps = {
  item: FileSystemItem;
  adornment?: React.ReactElement;
  disabled?: boolean;
  menuHidden?: boolean;
  onPress?: () => void;
  onLongPress?: () => void;
  onMenuPress?: () => void;
};

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

const EnteringAnimation = FadeInUp.duration(200).easing(
  Easing.inOut(Easing.quad),
);
const ExetingAnimation = FadeOutUp.duration(200).easing(
  Easing.inOut(Easing.quad),
);

export const FileSystemListItem = ({
  item,
  adornment,
  disabled,
  menuHidden,
  onPress,
  onLongPress,
  onMenuPress,
}: FileSystemListItemProps) => {
  const { colors } = useTheme();

  return (
    <Animated.View
      style={disabled && styles.disabled}
      layout={LinearTransition}
    >
      <AnimatedPressable
        entering={EnteringAnimation}
        exiting={ExetingAnimation}
        disabled={disabled}
        style={styles.root}
        onPress={onPress}
        onLongPress={onLongPress}
        testID={`fs-item-${item.id}`}
      >
        {!!adornment && (
          <View style={[styles.adornment, { backgroundColor: colors.surface }]}>
            {adornment}
          </View>
        )}
        <Typography
          style={styles.name}
          size={20}
          numberOfLines={1}
          ellipsizeMode="middle"
        >
          {item.name}
        </Typography>
        {!menuHidden && (
          <Pressable
            style={styles.menu}
            onPress={onMenuPress}
            testID={`fs-item-${item.id}-menu`}
          >
            <MenuVerticalIcon fill={colors.text} />
          </Pressable>
        )}
      </AnimatedPressable>
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  root: {
    padding: 12,
    alignItems: 'center',
    flexDirection: 'row',
  },
  name: {
    flex: 1,
    paddingBlock: 8,
    paddingInline: 12,
  },
  menu: {
    width: 28,
    height: 28,
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'flex-end',
    marginBlockEnd: 4,
  },
  adornment: {
    width: 32,
    height: 32,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 4,
    opacity: 0.75,
  },
  disabled: {
    opacity: 0.5,
  },
});
