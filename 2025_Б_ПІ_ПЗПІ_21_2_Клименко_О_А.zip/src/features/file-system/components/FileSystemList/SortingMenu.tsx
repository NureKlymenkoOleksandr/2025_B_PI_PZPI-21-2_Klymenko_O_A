import { forwardRef, useImperativeHandle, useRef } from 'react';
import { useTranslation } from 'react-i18next';

import {
  BottomSheet,
  BottomSheetRef,
  BottomSheetView,
} from '@/common/components/bottom-sheet';
import { MenuItem } from '@/common/components/menu';
import { SortingIcon } from '@/common/components/SortingIcon';
import { useSortingParamsStore } from '@/common/stores/sortingParamsStore';
import { SortingParams } from '@/common/types/sorting';

const sortingKeys = ['name', 'createdAt', 'updatedAt', 'size'];

type SortingMenuProps = {
  onSort?: (newSortingParams: SortingParams) => void;
};

export const SortingMenu = forwardRef<BottomSheetRef, SortingMenuProps>(
  ({ onSort }, ref) => {
    const internalRef = useRef<BottomSheetRef>(null);
    useImperativeHandle(ref, () => internalRef.current!);

    const { t } = useTranslation();
    const { order, orderBy, setSortingParams } = useSortingParamsStore(
      (store) => store,
    );

    const handleSortingItemPress = (name: string) => () => {
      const newSortingParams = {
        order: name === orderBy && order === 'asc' ? 'desc' : 'asc',
        orderBy: name,
      } as const;
      setSortingParams(newSortingParams);
      onSort?.(newSortingParams);
      internalRef.current?.close();
    };

    return (
      <BottomSheet name="sorting-menu" ref={internalRef}>
        <BottomSheetView>
          {sortingKeys.map((sortingKey) => {
            const isSelected = orderBy === sortingKey;
            return (
              <MenuItem
                key={sortingKey}
                icon={
                  isSelected ? <SortingIcon isAsc={order === 'asc'} /> : null
                }
                title={t(`sorting.${sortingKey}`)}
                selected={isSelected}
                onPress={handleSortingItemPress(sortingKey)}
              />
            );
          })}
        </BottomSheetView>
      </BottomSheet>
    );
  },
);

SortingMenu.displayName = 'SortingMenu';
