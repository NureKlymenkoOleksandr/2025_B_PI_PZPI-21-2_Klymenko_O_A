import { useTranslation } from 'react-i18next';
import { StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { EmptyState } from './EmptyState';
import { useTheme } from '@/common/theme';

export const StarredEmptyState = () => {
  const { t } = useTranslation();
  const { colors } = useTheme();

  const starIcon = (
    <Ionicons
      name="star"
      size={64}
      color={colors.primary}
      style={styles.icon}
    />
  );

  return (
    <EmptyState
      icon={starIcon}
      translationKey={{
        title: 'fileSystem.starred.empty.title',
        description: 'fileSystem.starred.empty.description',
      }}
    />
  );
};

const styles = StyleSheet.create({
  icon: {
    marginBottom: 8,
  },
});
