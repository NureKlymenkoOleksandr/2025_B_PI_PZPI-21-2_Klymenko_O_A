import { BottomSheetModalProvider } from '@gorhom/bottom-sheet';
import { screen, fireEvent, waitFor } from '@testing-library/react-native';
import React, { ReactElement } from 'react';

import { SortingParamsProvider } from '@/common/stores/sortingParamsStore';
import { FileSystemActionProvider } from '@/features/file-system/stores/fileSystemActionStore';
import { File, Folder } from '@/features/file-system/types';
import { renderWithNavigation } from '@/testing/test-utils';

import { FileSystemList } from '..';

describe('FileSystemList', () => {
  const mockFileItems: File[] = [
    {
      id: 'file-1',
      createdAt: new Date().toString(),
      extension: 'jpg',
      name: 'Photo1.jpg',
      parentDirectoryID: '1',
      public: false,
      size: 0,
      starred: false,
      updatedAt: new Date().toString(),
    },
    {
      id: 'file-2',
      createdAt: new Date().toString(),
      extension: 'jpg',
      name: 'Photo2.jpg',
      parentDirectoryID: '1',
      public: false,
      size: 0,
      starred: false,
      updatedAt: new Date().toString(),
    },
  ];

  const mockFolderItems: Folder[] = [
    {
      id: 'folder-1',
      createdAt: new Date().toString(),
      name: 'Folder 1',
      parentDirectoryID: '1',
      public: false,
      size: 0,
      updatedAt: new Date().toString(),
      directories: [],
      directoriesCount: 0,
      files: [],
      filesCount: 0,
      path: [],
    },
    {
      id: 'folder-2',
      createdAt: new Date().toString(),
      name: 'Folder 2',
      parentDirectoryID: '1',
      public: false,
      size: 0,
      updatedAt: new Date().toString(),
      directories: [],
      directoriesCount: 0,
      files: [],
      filesCount: 0,
      path: [],
    },
  ];

  const mockMixedItems = [...mockFolderItems, ...mockFileItems];

  const mockHandlers = {
    onFilePress: jest.fn(),
    onFolderPress: jest.fn(),
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  const renderWithProviders = (ui: ReactElement) =>
    renderWithNavigation(
      <BottomSheetModalProvider>
        <SortingParamsProvider>
          <FileSystemActionProvider>{ui}</FileSystemActionProvider>
        </SortingParamsProvider>
      </BottomSheetModalProvider>,
    );

  describe('Item Visibility Tests', () => {
    test('renders all file items correctly', () => {
      renderWithProviders(
        <FileSystemList items={mockFileItems} itemHandlers={mockHandlers} />,
      );

      expect(screen.getByText('Photo1.jpg')).toBeTruthy();
      expect(screen.getByText('Photo2.jpg')).toBeTruthy();
    });

    test('renders all folder items correctly', () => {
      renderWithProviders(
        <FileSystemList items={mockFolderItems} itemHandlers={mockHandlers} />,
      );

      expect(screen.getByText('Folder 1')).toBeTruthy();
      expect(screen.getByText('Folder 2')).toBeTruthy();
    });

    test('renders mixed file and folder items correctly', () => {
      renderWithProviders(
        <FileSystemList items={mockMixedItems} itemHandlers={mockHandlers} />,
      );

      expect(screen.getByText('Photo1.jpg')).toBeTruthy();
      expect(screen.getByText('Photo2.jpg')).toBeTruthy();

      expect(screen.getByText('Folder 1')).toBeTruthy();
      expect(screen.getByText('Folder 2')).toBeTruthy();
    });

    test('renders empty list correctly', () => {
      renderWithProviders(<FileSystemList items={[]} />);

      expect(screen.getByTestId('fs-sorting')).toBeTruthy();

      expect(screen.queryByTestId(/^file-/)).toBeFalsy();
      expect(screen.queryByTestId(/^folder-/)).toBeFalsy();
    });

    // test('handles unknown item types gracefully', () => {
    //   const unknownItem = {
    //     id: 'unknown-1',
    //     name: 'unknown',
    //     type: 'unknown',
    //   };

    //   render(
    //     <FileSystemList items={[unknownItem]} itemHandlers={mockHandlers} />,
    //   );

    //   // Unknown items should not render anything
    //   expect(screen.queryByTestId('file-unknown-1')).toBeFalsy();
    //   expect(screen.queryByTestId('folder-unknown-1')).toBeFalsy();
    // });
  });

  describe('Component Props Tests', () => {
    test('passes disabled state correctly', () => {
      const { getByTestId } = renderWithProviders(
        <FileSystemList
          items={mockMixedItems}
          itemHandlers={mockHandlers}
          getDisabledState={(item) => item.id === 'file-1'}
        />,
      );

      const disabledFile = getByTestId('fs-item-file-1');
      const enabledFile = getByTestId('fs-item-file-2');

      expect(disabledFile.props.accessibilityState.disabled).toBe(true);
      expect(enabledFile.props.accessibilityState.disabled).toBe(false);
    });

    test('passes menu hidden state correctly', () => {
      const { queryByTestId } = renderWithProviders(
        <FileSystemList
          items={mockMixedItems}
          itemHandlers={mockHandlers}
          itemMenuHidden={true}
        />,
      );

      expect(queryByTestId('fs-item-file-1-menu')).toBeNull();
      expect(queryByTestId('fs-item-folder-1-menu')).toBeNull();
    });

    test('renders sorting header', () => {
      renderWithProviders(
        <FileSystemList items={mockMixedItems} itemHandlers={mockHandlers} />,
      );

      expect(screen.getByTestId('fs-sorting')).toBeTruthy();
      expect(screen.getByText('sorting.name')).toBeTruthy();
    });

    test('passess item handlers', async () => {
      const { getByTestId } = renderWithProviders(
        <FileSystemList items={mockMixedItems} itemHandlers={mockHandlers} />,
      );

      const pressableFile = getByTestId('fs-item-file-1');
      const pressableFolder = getByTestId('fs-item-folder-1');

      fireEvent.press(pressableFile);
      fireEvent.press(pressableFolder);

      expect(mockHandlers.onFilePress).toHaveBeenCalledTimes(1);
      expect(mockHandlers.onFolderPress).toHaveBeenCalledTimes(1);
    });

    test('handles menu click correctly', () => {
      renderWithProviders(
        <FileSystemList items={mockMixedItems} itemHandlers={mockHandlers} />,
      );

      const menuButton = screen.getByTestId('fs-item-file-1-menu');
      fireEvent.press(menuButton);

      expect(mockHandlers.onFilePress).not.toHaveBeenCalled();
    });
  });

  describe('Refresh Functionality Tests', () => {
    test('handles refresh correctly', async () => {
      const onRefresh = jest.fn().mockResolvedValue(undefined);

      const { getByTestId } = renderWithProviders(
        <FileSystemList
          items={mockMixedItems}
          itemHandlers={mockHandlers}
          onRefresh={onRefresh}
        />,
      );

      const flatList = getByTestId('fs-list');

      fireEvent(flatList, 'refresh');

      await waitFor(() => {
        expect(onRefresh).toHaveBeenCalledTimes(1);
      });
    });
  });
});
