import { useTranslation } from 'react-i18next';

import { InputModal } from '@/common/components/modals/InputModal';
import { useFileUploadStore } from '@/features/file/context';
import { useFileSystemActionStore } from '@/features/file-system/stores/fileSystemActionStore';
import { FileSystemAction } from '@/features/file-system/types';
import { useCreateFolderMutation } from '@/features/folder/api/createFolder';

export const FileSystemCreateModal = () => {
  const { t } = useTranslation();
  const { currentAction, resetAction } = useFileSystemActionStore((store) => ({
    currentAction: store.currentAction,
    // destinationFolderId: store.destinationFolderId,
    resetAction: store.resetAction,
  }));
  // Refactor to use useFileSystemActionStore
  const destinationFolderId = useFileUploadStore(
    (store) => store.uploadFolderId,
  );

  const createFolderMutation = useCreateFolderMutation();

  const isVisible = currentAction === FileSystemAction.CREATE_FOLDER;

  const handleCreate = async (name: string) => {
    if (destinationFolderId === null) return;
    await createFolderMutation.mutateAsync({
      parentDirectoryID: destinationFolderId,
      name,
    });
    resetAction();
  };

  return (
    <InputModal
      testID="create-folder-modal"
      visible={isVisible}
      title={t('folder.create')}
      onClose={resetAction}
      actionText={t('common.create')}
      initialValue=""
      onAction={handleCreate}
    />
  );
};
