import { useTranslation } from 'react-i18next';
import { View, StyleSheet, Pressable } from 'react-native';

import { BaseModal } from '@/common/components/modals/BaseModal';
import { Typography } from '@/common/components/Typography';
import { useTheme } from '@/common/theme';
import { useDeleteFileMutation } from '@/features/file/api/deleteFile';
import { useFileSystemActionStore } from '@/features/file-system/stores/fileSystemActionStore';
import { FileSystemAction } from '@/features/file-system/types';
import { isFile } from '@/features/file-system/utils/isFile';
import { useDeleteFolderMutation } from '@/features/folder/api/deleteFolder';

export const FileSystemDeleteModal = () => {
  const { colors } = useTheme();
  const { t } = useTranslation();
  const { currentAction, currentItem, resetAction } = useFileSystemActionStore(
    (store) => ({
      currentAction: store.currentAction,
      currentItem: store.currentItem,
      resetAction: store.resetAction,
    }),
  );

  const deleteFileMutation = useDeleteFileMutation();
  const deleteFolderMutation = useDeleteFolderMutation();

  const isVisible = currentAction === FileSystemAction.DELETE && !!currentItem;

  const handleDelete = async () => {
    if (!currentItem) {
      return;
    }

    if (isFile(currentItem)) {
      await deleteFileMutation.mutateAsync(currentItem);
    } else {
      await deleteFolderMutation.mutateAsync(currentItem);
    }
    resetAction();
  };

  return (
    <BaseModal
      visible={isVisible}
      onRequestClose={resetAction}
      transparent
      animationType="fade"
    >
      <Typography style={styles.confirmationText} size={16}>
        {isFile(currentItem)
          ? t('file.confirmDelete', { name: currentItem?.name })
          : t('folder.confirmDelete', { name: currentItem?.name })}
      </Typography>

      <View style={styles.buttonContainer}>
        <Pressable
          style={[
            styles.cancelButton,
            { backgroundColor: colors.surfaceSubtle },
          ]}
          onPress={resetAction}
        >
          <Typography>{t('common.cancel')}</Typography>
        </Pressable>

        <Pressable style={styles.deleteButton} onPress={handleDelete}>
          <Typography color="white">{t('common.delete')}</Typography>
        </Pressable>
      </View>
    </BaseModal>
  );
};

const styles = StyleSheet.create({
  confirmationText: {
    marginBottom: 12,
    textAlign: 'center',
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginTop: 20,
  },
  cancelButton: {
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 8,
    marginRight: 9,
  },
  cancelText: {
    color: '#333',
    fontSize: 14,
  },
  deleteButton: {
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 6,
    backgroundColor: 'red',
  },
  deleteText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '500',
  },
});
