import { createContext, PropsWithChildren, useContext, useState } from 'react';
import { create, useStore } from 'zustand';
import { useShallow } from 'zustand/react/shallow';

import { File, Folder, FileSystemAction } from '@/features/file-system/types';

export type FileSystemItem = File | Folder;

type FileSystemActionState = {
  currentItem: FileSystemItem | null;
  currentAction: FileSystemAction | null;
  destinationFolderId: string | null;
};

type FileSystemActionStore = FileSystemActionState & {
  setCurrentItem: (item: FileSystemItem | null) => void;
  setCurrentAction: (action: FileSystemAction | null) => void;
  setDestinationFolderId: (id: string | null) => void;
  resetAction: VoidFunction;
};

const createFileSystemActionStore = () =>
  create<FileSystemActionStore>(
    (set: (state: Partial<FileSystemActionStore>) => void) => ({
      currentItem: null,
      currentAction: null,
      destinationFolderId: null,
      setCurrentItem: (item: FileSystemItem | null) =>
        set({ currentItem: item }),
      setCurrentAction: (action: FileSystemAction | null) =>
        set({ currentAction: action }),
      setDestinationFolderId: (id: string | null) => {
        console.log('DEST', id);
        set({ destinationFolderId: id });
      },
      resetAction: () =>
        set({
          currentAction: null,
          currentItem: null,
          destinationFolderId: null,
        }),
    }),
  );

const FileSystemActionContext = createContext<ReturnType<
  typeof createFileSystemActionStore
> | null>(null);

export const FileSystemActionProvider = ({ children }: PropsWithChildren) => {
  const [store] = useState(() => createFileSystemActionStore());
  return (
    <FileSystemActionContext.Provider value={store}>
      {children}
    </FileSystemActionContext.Provider>
  );
};

export const useFileSystemActionStore = <T,>(
  selector: (store: FileSystemActionStore) => T,
): T => {
  const store = useContext(FileSystemActionContext);
  if (!store) {
    throw new Error(
      'useFileSystemActionStore must be used within a FileSystemActionProvider',
    );
  }
  return useStore(store, useShallow(selector));
};
