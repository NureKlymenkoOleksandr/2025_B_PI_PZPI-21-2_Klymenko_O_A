import AsyncStorage from '@react-native-async-storage/async-storage';
import { createContext, PropsWithChildren, useContext, useState } from 'react';
import { createStore, useStore, StateCreator } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import { useShallow } from 'zustand/react/shallow';

type SortingParamsState = {
  orderBy: string;
  order: 'asc' | 'desc';
};

type SortingParamsStore = SortingParamsState & {
  setSortingParams: (params: Partial<SortingParamsState>) => void;
};

export const createSortingParamsStore = (persistanceKey?: string) => {
  const store: StateCreator<SortingParamsStore> = (set) => ({
    order: 'asc',
    orderBy: 'name',
    setSortingParams: (params: Partial<SortingParamsState>) =>
      set((state) => ({
        ...state,
        ...params,
      })),
  });

  if (persistanceKey) {
    return createStore<SortingParamsStore>()(
      persist(store, {
        name: `sorting-${persistanceKey}`,
        storage: createJSONStorage(() => AsyncStorage),
      }),
    );
  }

  return createStore<SortingParamsStore>(store);
};

const SortingParamsContext = createContext<ReturnType<
  typeof createSortingParamsStore
> | null>(null);

type SortingParamsProviderProps = PropsWithChildren<{
  persistanceKey?: string;
}>;

export const SortingParamsProvider = ({
  children,
  persistanceKey,
}: SortingParamsProviderProps) => {
  const [store] = useState(() => createSortingParamsStore(persistanceKey));

  return (
    <SortingParamsContext.Provider value={store}>
      {children}
    </SortingParamsContext.Provider>
  );
};

export const useSortingParamsStore = <T,>(
  selector: (store: SortingParamsStore) => T,
): T => {
  const sortingParamsStore = useContext(SortingParamsContext);

  if (!sortingParamsStore) {
    throw new Error(
      'useSortingParams must be used inside SortingParamsProvider',
    );
  }

  return useStore(sortingParamsStore, useShallow(selector));
};
