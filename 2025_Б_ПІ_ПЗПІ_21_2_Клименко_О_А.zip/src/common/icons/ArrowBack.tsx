import * as React from 'react';
import Svg, { Path, SvgProps } from 'react-native-svg';

export const ArrowBack = (props: SvgProps) => (
  <Svg
    height="24px"
    viewBox="0 -960 960 960"
    width="24px"
    fill="black"
    {...props}
  >
    <Path d="M640-80 240-480l400-400 71 71-329 329 329 329-71 71Z" />
  </Svg>
);
