import { MediaType } from '@/common/types/mimeType';

export interface MimeTypeInfo {
  mimeType: string;
  mediaType: MediaType;
}

const MIME_TYPE_MAP: Record<string, MimeTypeInfo> = {
  jpg: { mimeType: 'image/jpeg', mediaType: 'image' },
  jpeg: { mimeType: 'image/jpeg', mediaType: 'image' },
  png: { mimeType: 'image/png', mediaType: 'image' },
  gif: { mimeType: 'image/gif', mediaType: 'image' },
  bmp: { mimeType: 'image/bmp', mediaType: 'image' },
  webp: { mimeType: 'image/webp', mediaType: 'image' },
  svg: { mimeType: 'image/svg+xml', mediaType: 'image' },
  ico: { mimeType: 'image/x-icon', mediaType: 'image' },
  tiff: { mimeType: 'image/tiff', mediaType: 'image' },
  tif: { mimeType: 'image/tiff', mediaType: 'image' },
  heic: { mimeType: 'image/heic', mediaType: 'image' },
  heif: { mimeType: 'image/heif', mediaType: 'image' },

  mp4: { mimeType: 'video/mp4', mediaType: 'video' },
  mov: { mimeType: 'video/quicktime', mediaType: 'video' },
  avi: { mimeType: 'video/x-msvideo', mediaType: 'video' },
  wmv: { mimeType: 'video/x-ms-wmv', mediaType: 'video' },
  flv: { mimeType: 'video/x-flv', mediaType: 'video' },
  webm: { mimeType: 'video/webm', mediaType: 'video' },
  mkv: { mimeType: 'video/x-matroska', mediaType: 'video' },
  '3gp': { mimeType: 'video/3gpp', mediaType: 'video' },
  m4v: { mimeType: 'video/x-m4v', mediaType: 'video' },

  mp3: { mimeType: 'audio/mpeg', mediaType: 'audio' },
  wav: { mimeType: 'audio/wav', mediaType: 'audio' },
  flac: { mimeType: 'audio/flac', mediaType: 'audio' },
  aac: { mimeType: 'audio/aac', mediaType: 'audio' },
  ogg: { mimeType: 'audio/ogg', mediaType: 'audio' },
  m4a: { mimeType: 'audio/mp4', mediaType: 'audio' },
  wma: { mimeType: 'audio/x-ms-wma', mediaType: 'audio' },

  pdf: { mimeType: 'application/pdf', mediaType: 'document' },
  doc: { mimeType: 'application/msword', mediaType: 'document' },
  docx: {
    mimeType:
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    mediaType: 'document',
  },
  xls: { mimeType: 'application/vnd.ms-excel', mediaType: 'document' },
  xlsx: {
    mimeType:
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    mediaType: 'document',
  },
  ppt: { mimeType: 'application/vnd.ms-powerpoint', mediaType: 'document' },
  pptx: {
    mimeType:
      'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    mediaType: 'document',
  },
  txt: { mimeType: 'text/plain', mediaType: 'document' },
  rtf: { mimeType: 'application/rtf', mediaType: 'document' },

  zip: { mimeType: 'application/zip', mediaType: 'other' },
  rar: { mimeType: 'application/vnd.rar', mediaType: 'other' },
  '7z': { mimeType: 'application/x-7z-compressed', mediaType: 'other' },
  tar: { mimeType: 'application/x-tar', mediaType: 'other' },
  gz: { mimeType: 'application/gzip', mediaType: 'other' },

  json: { mimeType: 'application/json', mediaType: 'document' },
  xml: { mimeType: 'application/xml', mediaType: 'document' },
  html: { mimeType: 'text/html', mediaType: 'document' },
  css: { mimeType: 'text/css', mediaType: 'document' },
  js: { mimeType: 'application/javascript', mediaType: 'document' },
  ts: { mimeType: 'application/typescript', mediaType: 'document' },
};

const EXTENSION_MAP: Record<string, string> = {};
for (const [ext, info] of Object.entries(MIME_TYPE_MAP)) {
  if (!(info.mimeType in EXTENSION_MAP)) {
    EXTENSION_MAP[info.mimeType] = ext;
  }
}

export const getMimeTypeFromExtension = (extension: string): MimeTypeInfo => {
  return (
    MIME_TYPE_MAP[extension] || {
      mimeType: 'application/octet-stream',
      mediaType: 'other',
    }
  );
};

export const isImageFile = (extension: string): boolean => {
  const { mediaType } = getMimeTypeFromExtension(extension);
  return mediaType === 'image';
};

export const isVideoFile = (extension: string): boolean => {
  const { mediaType } = getMimeTypeFromExtension(extension);
  return mediaType === 'video';
};

export const shouldSaveToGallery = (extension: string): boolean => {
  return isImageFile(extension) || isVideoFile(extension);
};

export const getMediaTypeFromMimeType = (mimeType: string): MediaType => {
  if (mimeType.startsWith('image/')) return 'image';
  if (mimeType.startsWith('video/')) return 'video';
  if (mimeType.startsWith('audio/')) return 'audio';
  if (
    mimeType.startsWith('text/') ||
    mimeType.includes('document') ||
    mimeType === 'application/pdf'
  ) {
    return 'document';
  }
  return 'other';
};

export const getExtensionFromMimeType = (
  mimeType: string,
): string | undefined => {
  return EXTENSION_MAP[mimeType];
};
