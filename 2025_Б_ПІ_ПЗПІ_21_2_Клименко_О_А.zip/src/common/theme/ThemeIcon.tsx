import MaterialIcons from '@expo/vector-icons/MaterialIcons';

import { Theme } from './constants';
import { useTheme } from './useTheme';

export type ThemeIconProps = {
  theme: Theme;
  testID?: string;
};

export const ThemeIcon = ({ theme, testID }: ThemeIconProps) => {
  const { colors } = useTheme();

  const getIconName = () => {
    switch (theme) {
      case Theme.LIGHT:
        return 'light-mode';
      case Theme.DARK:
        return 'dark-mode';
      case Theme.SYSTEM:
        return 'contrast';
    }
  };

  return (
    <MaterialIcons
      name={getIconName()}
      color={colors.text}
      size={24}
      testID={testID}
    />
  );
};
