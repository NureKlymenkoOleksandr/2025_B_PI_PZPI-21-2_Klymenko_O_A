import {
  DarkTheme,
  DefaultTheme,
  Theme as NativeTheme,
} from '@react-navigation/native';

import { ColorScheme } from './types';

export const THEME_KEY = 'THEME';

export enum Theme {
  LIGHT = 'light',
  DARK = 'dark',
  SYSTEM = 'system',
}

export const Light: ColorScheme = {
  background: '#fbfbfe',
  primary: '#012b5b',
  surface: '#012b5b33',
  surfaceSubtle: '#f7f7f7',
  secondary: '##004a9e4d',
  text: '#040316',
  contrastText: '#eae9fc',
  divider: '#EEEEEE',
};

export const Dark: ColorScheme = {
  background: '#010104',
  primary: '#a2cdfe',
  surface: '#a2cdfe33',
  surfaceSubtle: '#121212',
  secondary: '#499DFD',
  text: '#eae9fc',
  contrastText: '#040316',
  divider: '#2a2a2a',
};

export const DarkNavigationTheme: NativeTheme = {
  ...DarkTheme,
  colors: {
    ...DarkTheme.colors,
    background: Dark.background,
    primary: Dark.primary,
  },
};

export const LightNavigationTheme: NativeTheme = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    background: Light.background,
    primary: Light.primary,
  },
};
