export type ColorScheme = {
  background: string;
  primary: string;
  secondary: string;
  surface: string;
  surfaceSubtle: string;
  text: string;
  contrastText: string;
  divider: string;
};
