import { useCallback } from 'react';
import { Appearance, useColorScheme } from 'react-native';

import { useThemeStore } from '@/common/stores/themeStore';

import { Dark, Light, Theme } from './constants';

export const useTheme = () => {
  const systemTheme = useColorScheme();
  const { theme: selectedTheme, setTheme } = useThemeStore();

  const isSystem = selectedTheme === Theme.SYSTEM;
  const effectiveTheme = isSystem
    ? ((systemTheme as Theme) ?? Theme.LIGHT)
    : selectedTheme;

  const changeTheme = useCallback(
    (theme: Theme) => {
      setTheme(theme);
      Appearance.setColorScheme(theme === Theme.SYSTEM ? null : theme);
    },
    [setTheme],
  );

  const colors = effectiveTheme === Theme.DARK ? Dark : Light;

  return {
    theme: effectiveTheme,
    selectedTheme,
    isSystem,
    changeTheme,
    colors,
  };
};
