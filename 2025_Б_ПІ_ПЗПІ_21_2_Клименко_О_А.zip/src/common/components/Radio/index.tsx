import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { StyleSheet, View } from 'react-native';

import { useTheme } from '@/common/theme';

interface RadioProps {
  selected: boolean;
  size?: number;
}

export const Radio = ({ selected, size = 24 }: RadioProps) => {
  const { colors } = useTheme();

  return (
    <View
      style={[
        styles.radio,
        {
          width: size,
          height: size,
          borderRadius: size / 2,
          borderColor: colors.text,
          backgroundColor: selected ? colors.primary : 'transparent',
        },
      ]}
    >
      {selected && (
        <MaterialIcons
          name="check"
          size={size * 0.67}
          color={colors.contrastText}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  radio: {
    borderWidth: 2,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
