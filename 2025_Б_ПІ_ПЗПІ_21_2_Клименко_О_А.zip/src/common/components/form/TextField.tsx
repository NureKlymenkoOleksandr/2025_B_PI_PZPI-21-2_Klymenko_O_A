import { forwardRef } from 'react';
import { TextInput } from 'react-native';

import { Input, InputProps } from '@/common/components/Input';

import { FieldWrapper, FieldWrapperProps } from './FieldWrapper';

type TextFieldProps = InputProps & Omit<FieldWrapperProps, 'children'>;

export const TextField = forwardRef<TextInput, TextFieldProps>(
  ({ label, error, ...inputProps }, ref) => {
    return (
      <FieldWrapper label={label} error={error}>
        <Input ref={ref} {...inputProps} />
      </FieldWrapper>
    );
  },
);

TextField.displayName = 'TextField';
