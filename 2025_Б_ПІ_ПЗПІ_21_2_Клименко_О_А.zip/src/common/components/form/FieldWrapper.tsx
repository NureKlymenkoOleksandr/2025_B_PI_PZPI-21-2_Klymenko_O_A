import { PropsWithChildren } from 'react';
import { StyleSheet, Text, View } from 'react-native';

export type FieldWrapperProps = PropsWithChildren<{
  label?: string;
  error?: string;
}>;

export const FieldWrapper = ({ label, error, children }: FieldWrapperProps) => {
  return (
    <View style={styles.root}>
      {!!label && <Text style={styles.label}>{label}</Text>}
      <View style={styles.fieldWrapper}>{children}</View>
      {!!error && <Text style={styles.error}>{error}</Text>}
    </View>
  );
};

const styles = StyleSheet.create({
  root: {},
  label: {},
  error: {},
  fieldWrapper: {
    marginTop: 8,
    marginBottom: 4,
  },
});
