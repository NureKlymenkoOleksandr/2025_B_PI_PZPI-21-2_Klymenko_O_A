import { StyleProp, Text, TextProps, TextStyle } from 'react-native';

import { useTheme } from '@/common/theme';

const FONTS = {
  Inter: {
    regular: 'Inter-Regular',
    medium: 'Inter-Medium',
    semiBold: 'Inter-SemiBold',
    bold: 'Inter-Bold',
    default: 'Inter-Regular',
  },
} as const;

type FontFamily = keyof typeof FONTS;
type FontWeights<T extends FontFamily> = Exclude<
  keyof (typeof FONTS)[T],
  'default'
>;

type TypographyProps<T extends FontFamily> = TextProps & {
  family?: T;
  weight?: FontWeights<T>;
  color?: string;
  size?: number;
  style?: StyleProp<Omit<TextStyle, 'fontWeight' | 'fontFamily'>>;
};

export const Typography = <T extends FontFamily>({
  style,
  family = 'Inter' as T,
  weight,
  color: textColor,
  size: fontSize = 16,
  ...rest
}: TypographyProps<T>) => {
  const { colors } = useTheme();

  const fontWeight = weight ?? 'default';
  const fontFamily = FONTS[family][fontWeight] as string;
  const color = textColor ?? colors.text;

  return <Text style={[style, { fontFamily, color, fontSize }]} {...rest} />;
};
