import MaterialIcons from '@expo/vector-icons/MaterialIcons';

import { useTheme } from '@/common/theme';

type SortingIconProps = {
  isAsc: boolean;
  size?: number;
};

export const SortingIcon = ({ isAsc, size = 24 }: SortingIconProps) => {
  const { colors } = useTheme();
  return (
    <MaterialIcons
      name={isAsc ? 'arrow-upward' : 'arrow-downward'}
      size={size}
      color={colors.text}
    />
  );
};
