import { StyleSheet, Pressable } from 'react-native';

import { useTheme } from '@/common/theme';

type FloatingActionButtonProps = {
  onPress: () => void;
  children: React.ReactNode;
  bottom?: number;
  right?: number;
  testID?: string;
};

export const FloatingActionButton = ({
  onPress,
  children,
  bottom = 24,
  right = 24,
  testID,
}: FloatingActionButtonProps) => {
  const { colors } = useTheme();

  return (
    <Pressable
      style={[
        {
          bottom,
          right,
          backgroundColor: colors.surfaceSubtle,
        },
        styles.root,
      ]}
      onPress={onPress}
      testID={testID}
    >
      {children}
    </Pressable>
  );
};

const styles = StyleSheet.create({
  root: {
    position: 'absolute',
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.27,
    shadowRadius: 4.65,
  },
});
