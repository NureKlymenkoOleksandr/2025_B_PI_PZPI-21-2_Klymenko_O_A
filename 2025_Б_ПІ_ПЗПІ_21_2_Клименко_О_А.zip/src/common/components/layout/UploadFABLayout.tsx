import { PropsWithChildren } from 'react';
import { View } from 'react-native';

import { FileUploadFab } from '@/features/file/components/FileUploadFAB';

export const UploadFABLayout = ({ children }: PropsWithChildren) => {
  return (
    <View style={{ flex: 1, alignItems: 'stretch' }}>
      {children}
      <FileUploadFab />
    </View>
  );
};
