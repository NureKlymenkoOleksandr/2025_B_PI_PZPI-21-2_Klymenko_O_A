import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { useNavigation } from '@react-navigation/native';

import { ActionButton } from '@/common/components/ActionButton';
import { useTheme } from '@/common/theme';

export const GoBackButton = () => {
  const navigation = useNavigation();
  const { colors } = useTheme();

  return (
    <ActionButton onPress={navigation.goBack} testID="go-back-button">
      <MaterialIcons name="arrow-back-ios-new" size={24} color={colors.text} />
    </ActionButton>
  );
};
