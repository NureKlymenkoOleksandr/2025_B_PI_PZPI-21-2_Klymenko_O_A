import { FC, PropsWithChildren } from 'react';
import { FlexStyle, StyleSheet, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { useTheme } from '@/common/theme';

type Props = {
  justify?: FlexStyle['justifyContent'];
  align?: FlexStyle['alignItems'];
  noTopPadding?: boolean;
};

export const ScreenContainer: FC<PropsWithChildren<Props>> = ({
  children,
  justify = 'flex-start',
  align = 'stretch',
  noTopPadding,
}) => {
  const { top, right, left } = useSafeAreaInsets();
  const { colors } = useTheme();

  return (
    <View
      style={StyleSheet.compose(styles.root, {
        paddingTop: noTopPadding ? 0 : top,
        paddingRight: right,
        paddingLeft: left,
        justifyContent: justify,
        alignItems: align,
        backgroundColor: colors.background,
      })}
    >
      {children}
    </View>
  );
};

const styles = StyleSheet.create({
  root: {
    flex: 1,
    position: 'relative',
  },
});
