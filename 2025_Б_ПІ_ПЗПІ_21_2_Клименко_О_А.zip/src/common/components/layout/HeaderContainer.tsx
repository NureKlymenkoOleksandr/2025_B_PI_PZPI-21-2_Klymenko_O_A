import { PropsWithChildren } from 'react';
import { StyleSheet, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { useTheme } from '@/common/theme';

type HeaderContainerProps = PropsWithChildren<{
  headerLeft?: React.ReactNode;
  headerRight?: React.ReactNode;
  absolute?: boolean;
}>;

export const HeaderContainer = ({
  children,
  headerLeft,
  headerRight,
  absolute,
}: HeaderContainerProps) => {
  const { top } = useSafeAreaInsets();
  const { colors } = useTheme();

  return (
    <View
      style={[
        styles.root,
        {
          paddingTop: top * 1.25,
          backgroundColor: colors.background,
          position: absolute ? 'absolute' : 'static',
        },
      ]}
    >
      {headerLeft}
      <View
        style={[
          styles.content,
          {
            paddingInlineStart: headerLeft ? 8 : 0,
            paddingInlineEnd: headerRight ? 8 : 0,
          },
        ]}
      >
        {children}
      </View>
      {headerRight}
    </View>
  );
};

const styles = StyleSheet.create({
  root: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
    paddingInline: 12,
    paddingBlock: 8,
  },
  content: {
    flex: 1,
  },
});
