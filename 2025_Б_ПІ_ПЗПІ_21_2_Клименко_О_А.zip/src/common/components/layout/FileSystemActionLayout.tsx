import { PropsWithChildren } from 'react';
import { View } from 'react-native';

import { useUnmount } from '@/common/hooks/useUnmount';
import { FileSystemActionButton } from '@/features/file-system/components/FileSystemActionButton';
import { useFileSystemActionStore } from '@/features/file-system/stores/fileSystemActionStore';

export const FileSystemActionLayout = ({ children }: PropsWithChildren) => {
  const resetAction = useFileSystemActionStore((store) => store.resetAction);

  useUnmount(resetAction);

  return (
    <View style={{ flex: 1, alignItems: 'stretch' }}>
      {children}
      <FileSystemActionButton />
    </View>
  );
};
