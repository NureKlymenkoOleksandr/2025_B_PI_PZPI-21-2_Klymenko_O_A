import { PropsWithChildren } from 'react';

import { FileAccessHandler } from '@/features/file/components/FileAccessHandler';
import { FileUploadMenu } from '@/features/file/components/FileUploadMenu';
import { FileSystemActionsMenu } from '@/features/file-system/components/FileSystemActionsMenu';
import { FileSystemCreateModal } from '@/features/file-system/components/FileSystemCreateModal';
import { FileSystemDeleteModal } from '@/features/file-system/components/FileSystemDeleteModal';
import { FileSystemDownloadModal } from '@/features/file-system/components/FileSystemDownloadModal';
import { FileSystemRenameModal } from '@/features/file-system/components/FileSystemRenameModal';

export const AppLayout = ({ children }: PropsWithChildren) => {
  return (
    <>
      {children}
      <FileAccessHandler />
      <FileSystemActionsMenu />
      <FileSystemRenameModal />
      <FileSystemDeleteModal />
      <FileSystemDownloadModal />
      <FileSystemCreateModal />
      <FileUploadMenu />
    </>
  );
};
