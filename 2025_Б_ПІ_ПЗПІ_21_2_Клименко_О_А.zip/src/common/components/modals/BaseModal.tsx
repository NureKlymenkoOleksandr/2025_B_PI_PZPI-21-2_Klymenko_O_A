import { Modal, ModalProps, StyleSheet, View } from 'react-native';

import { Typography } from '@/common/components/Typography';
import { useTheme } from '@/common/theme';

type BaseModalProps = ModalProps & {
  title?: string;
};

export const BaseModal = ({ children, title, ...rest }: BaseModalProps) => {
  const { colors } = useTheme();

  return (
    <Modal transparent animationType="fade" statusBarTranslucent {...rest}>
      <View style={styles.modalOverlay}>
        <View
          style={[
            styles.modalContent,
            { backgroundColor: colors.surfaceSubtle },
          ]}
        >
          {title && <Typography style={styles.modalTitle}>{title}</Typography>}
          {children}
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    width: '85%',
    borderRadius: 12,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 6,
    elevation: 8,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 16,
    textAlign: 'center',
  },
});
