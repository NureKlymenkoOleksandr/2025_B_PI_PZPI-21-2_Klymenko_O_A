import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Pressable, StyleSheet, View } from 'react-native';

import { Input } from '@/common/components/Input';
import { Typography } from '@/common/components/Typography';
import { useTheme } from '@/common/theme';

import { BaseModal } from './BaseModal';

type InputModalProps = {
  visible: boolean;
  onClose: VoidFunction;
  title: string;
  actionText: string;
  onAction: (inputValue: string) => void | Promise<void>;
  placeholder?: string;
  initialValue?: string;
  testID?: string;
};

export const InputModal = ({
  visible,
  onClose,
  title,
  placeholder,
  actionText,
  onAction,
  initialValue = '',
  testID,
}: InputModalProps) => {
  const { t } = useTranslation();
  const { colors } = useTheme();
  const [inputValue, setInputValue] = useState(initialValue);

  useEffect(() => {
    if (visible) {
      setInputValue(initialValue);
    }
  }, [visible, initialValue]);

  const handleAction = async () => {
    if (inputValue.trim()) {
      await onAction(inputValue.trim());
      setInputValue('');
    }
  };

  return (
    <BaseModal title={title} visible={visible} onRequestClose={onClose}>
      <Input
        testID={`${testID}-input`}
        placeholder={placeholder}
        value={inputValue}
        onChangeText={setInputValue}
        autoFocus={true}
        style={{ backgroundColor: colors.background }}
      />

      <View style={styles.buttonContainer}>
        <Pressable
          testID={`${testID}-cancel`}
          style={[
            styles.cancelButton,
            { backgroundColor: colors.surfaceSubtle },
          ]}
          onPress={onClose}
        >
          <Typography>{t('common.cancel')}</Typography>
        </Pressable>

        <Pressable
          testID={`${testID}-action`}
          style={[styles.actionButton, { backgroundColor: colors.secondary }]}
          onPress={handleAction}
        >
          <Typography style={styles.actionText} color={colors.contrastText}>
            {actionText}
          </Typography>
        </Pressable>
      </View>
    </BaseModal>
  );
};

const styles = StyleSheet.create({
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginTop: 20,
  },
  cancelButton: {
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 6,
    marginRight: 10,
    backgroundColor: '#f0f0f0',
  },
  actionButton: {
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 6,
    backgroundColor: '#3478f6',
  },
  actionText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '500',
  },
});
