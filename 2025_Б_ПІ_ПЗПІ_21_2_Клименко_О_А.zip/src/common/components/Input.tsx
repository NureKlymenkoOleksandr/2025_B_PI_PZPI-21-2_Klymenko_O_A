import { forwardRef } from 'react';
import { StyleSheet, TextInput, TextInputProps, View } from 'react-native';

import { useTheme } from '@/common/theme';

export type InputProps = TextInputProps & {
  fullwidth?: boolean;
};

export const Input = forwardRef<TextInput, InputProps>(
  ({ style, fullwidth, ...rest }, ref) => {
    const { colors } = useTheme();

    return (
      <View
        style={[
          { backgroundColor: colors.surfaceSubtle },
          styles.root,
          fullwidth && styles.fullwidth,
          style,
        ]}
      >
        <TextInput
          style={[{ color: colors.text }, styles.input]}
          ref={ref}
          {...rest}
        />
      </View>
    );
  },
);

Input.displayName = 'Input';

const styles = StyleSheet.create({
  root: {
    paddingInline: 12,
    borderRadius: 12,
    justifyContent: 'center',
  },
  input: {
    fontFamily: 'Inter-Regular',
    fontSize: 16,
  },
  fullwidth: {
    width: '100%',
  },
});
