import { ReactNode } from 'react';
import { StyleProp, ViewStyle } from 'react-native';

export type MenuItemProps = {
  title: string;
  subtitle?: string;
  icon?: ReactNode;
  onPress?: () => void;
  secondaryAction?: ReactNode;
  selected?: boolean;
  testID?: string;
};
export type MenuDividerProps = {
  style?: StyleProp<ViewStyle>;
};
