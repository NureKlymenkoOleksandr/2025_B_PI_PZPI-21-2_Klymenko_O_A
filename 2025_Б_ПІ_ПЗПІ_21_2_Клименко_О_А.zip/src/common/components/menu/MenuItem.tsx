import React from 'react';
import { Pressable, StyleSheet, View } from 'react-native';

import { Typography } from '@/common/components/Typography';
import { useTheme } from '@/common/theme';

import { MenuItemProps } from './types';

export const MenuItem: React.FC<MenuItemProps> = ({
  title,
  subtitle,
  icon,
  onPress,
  secondaryAction,
  selected,
  testID,
}) => {
  const { colors } = useTheme();

  const Container = onPress ? Pressable : View;

  return (
    <Container
      testID={testID}
      style={[
        styles.container,
        selected && { backgroundColor: colors.surface },
      ]}
      onPress={onPress}
    >
      {icon && <View style={styles.iconContainer}>{icon}</View>}

      <View style={styles.contentContainer}>
        <Typography weight="medium">{title}</Typography>
        {subtitle && (
          <Typography style={styles.subtitle}>{subtitle}</Typography>
        )}
      </View>

      {secondaryAction && (
        <View style={styles.secondaryActionContainer}>{secondaryAction}</View>
      )}
    </Container>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
  },
  iconContainer: {
    marginRight: 16,
    justifyContent: 'center',
    alignItems: 'flex-end',
    width: 24,
    height: 24,
  },
  contentContainer: {
    flex: 1,
  },
  subtitle: {
    fontSize: 12,
    color: '#666666',
    marginTop: 2,
  },
  secondaryActionContainer: {
    marginLeft: 16,
  },
});
