import { BottomSheetModalProvider } from '@gorhom/bottom-sheet';
import { QueryClientProvider } from '@tanstack/react-query';
import { PropsWithChildren } from 'react';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';

import { FileProvider } from '@/features/file/context';
import { FileSystemActionProvider } from '@/features/file-system/stores/fileSystemActionStore';
import { SearchProvider } from '@/features/search/stores/searchStore';
import { queryClient } from '@/lib/reactQuery';

export const AppProviders = ({ children }: PropsWithChildren) => {
  return (
    <QueryClientProvider client={queryClient}>
      <FileProvider>
        <FileSystemActionProvider>
          <SearchProvider>
            <SafeAreaProvider>
              <GestureHandlerRootView>
                <BottomSheetModalProvider>{children}</BottomSheetModalProvider>
              </GestureHandlerRootView>
            </SafeAreaProvider>
          </SearchProvider>
        </FileSystemActionProvider>
      </FileProvider>
    </QueryClientProvider>
  );
};
