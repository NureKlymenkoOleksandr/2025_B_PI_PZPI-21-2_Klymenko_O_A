import { forwardRef, useImperativeHandle, useRef } from 'react';
import { useTranslation } from 'react-i18next';

import { Theme, useTheme } from '@/common/theme';
import { ThemeIcon } from '@/common/theme/ThemeIcon';

import { BottomSheet, BottomSheetRef, BottomSheetView } from './bottom-sheet';
import { MenuItem } from './menu';

export const ThemeMenu = forwardRef<
  BottomSheetRef,
  { onSelectTheme: (theme: Theme) => void }
>(({ onSelectTheme }, ref) => {
  const { selectedTheme } = useTheme();
  const internalRef = useRef<BottomSheetRef>(null);
  useImperativeHandle(ref, () => internalRef.current!);
  const { t } = useTranslation();
  const selectedThemeRef = useRef(selectedTheme);

  const handleChangeTheme = (theme: Theme) => () => {
    selectedThemeRef.current = theme;
    internalRef.current?.close();
  };

  const handleClose = () => {
    setTimeout(() => {
      onSelectTheme(selectedThemeRef.current);
    }, 50);
  };

  return (
    <BottomSheet ref={internalRef} name="theme-menu" onClose={handleClose}>
      <BottomSheetView style={{ overflow: 'hidden' }}>
        <MenuItem
          testID="theme-option-light"
          title={t('theme.light')}
          selected={selectedTheme === Theme.LIGHT}
          secondaryAction={<ThemeIcon theme={Theme.LIGHT} />}
          onPress={handleChangeTheme(Theme.LIGHT)}
        />
        <MenuItem
          testID="theme-option-dark"
          title={t('theme.dark')}
          selected={selectedTheme === Theme.DARK}
          secondaryAction={<ThemeIcon theme={Theme.DARK} />}
          onPress={handleChangeTheme(Theme.DARK)}
        />
        <MenuItem
          testID="theme-option-system"
          title={t('theme.system')}
          selected={selectedTheme === Theme.SYSTEM}
          secondaryAction={<ThemeIcon theme={Theme.SYSTEM} />}
          onPress={handleChangeTheme(Theme.SYSTEM)}
        />
      </BottomSheetView>
    </BottomSheet>
  );
});

ThemeMenu.displayName = 'ThemeMenu';
