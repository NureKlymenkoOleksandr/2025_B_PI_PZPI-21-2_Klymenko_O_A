import React, { useRef, PropsWithChildren, forwardRef } from 'react';
import { Easing, Animated, View, StyleSheet, Pressable } from 'react-native';

import { useTheme } from '@/common/theme';

type ActionButtonProps = PropsWithChildren<{
  size?: number;
  onPress: () => void;
  onLongPress?: () => void;
  testID?: string;
}>;

export const ActionButton = forwardRef<View, ActionButtonProps>(
  ({ size = 48, onPress, children, onLongPress, testID }, ref) => {
    const animation = useRef(new Animated.Value(0)).current;
    const { colors } = useTheme();

    const handlePressIn = () => {
      Animated.timing(animation, {
        toValue: 1,
        duration: 150,
        useNativeDriver: true,
        easing: Easing.linear,
      }).start();
    };

    const handlePressOut = () => {
      Animated.timing(animation, {
        toValue: 0,
        duration: 0,
        useNativeDriver: true,
      }).start();
    };

    return (
      <Pressable
        ref={ref}
        testID={testID}
        onPressIn={handlePressIn}
        onPressOut={handlePressOut}
        onPress={onPress}
        onLongPress={onLongPress}
      >
        <View
          style={[
            styles.button,
            {
              width: size,
              height: size,
              borderRadius: size / 2,
            },
          ]}
        >
          <View style={styles.childrenContainer}>{children}</View>

          <Animated.View
            style={[
              { backgroundColor: colors.surfaceSubtle },
              styles.ripple,
              {
                transform: [
                  {
                    scale: animation.interpolate({
                      inputRange: [0, 1],
                      outputRange: [0.5, 1.2],
                    }),
                  },
                ],
                opacity: animation,
              },
            ]}
          />
        </View>
      </Pressable>
    );
  },
);

ActionButton.displayName = 'ActionButton';

const styles = StyleSheet.create({
  button: {
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
    position: 'relative',
  },
  ripple: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    borderRadius: 1000,
  },
  childrenContainer: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1,
  },
});
