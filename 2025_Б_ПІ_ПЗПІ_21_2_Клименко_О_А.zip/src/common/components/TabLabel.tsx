import { useTranslation } from 'react-i18next';

import { Typography } from './Typography';

type TabLabelProps = {
  color: string;
  label: string;
};

export const TabLabel = ({ color, label }: TabLabelProps) => {
  const { t } = useTranslation();
  return (
    <Typography size={10} color={color}>
      {t(label)}
    </Typography>
  );
};
