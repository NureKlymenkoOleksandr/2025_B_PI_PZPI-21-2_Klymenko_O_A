import { SvgProps } from 'react-native-svg';

type TabIconProps = {
  icon: React.ComponentType<SvgProps>;
  focused: boolean;
  color: string;
  size: number;
};

export const TabIcon = ({ icon: Icon, color, size }: TabIconProps) => (
  <Icon width={size} height={size} fill={color} />
);
