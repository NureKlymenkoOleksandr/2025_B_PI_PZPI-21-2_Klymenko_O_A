import { createContext, RefObject, useContext } from 'react';

import { BottomSheetRef } from './BottomSheet';

export interface BottomSheetContextValue {
  onContentHeightChange: (height: number) => void;
  expandable: boolean;
  sheetRef: RefObject<BottomSheetRef | null>;
}

export const BottomSheetContext = createContext<BottomSheetContextValue | null>(
  null,
);

export const useBottomSheet = () => {
  const context = useContext(BottomSheetContext);
  return context;
};
