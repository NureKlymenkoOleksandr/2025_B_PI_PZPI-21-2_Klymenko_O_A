import {
  BottomSheetHandle,
  BottomSheetModal,
  useBottomSheetSpringConfigs,
} from '@gorhom/bottom-sheet';
import React, {
  forwardRef,
  PropsWithChildren,
  useImperativeHandle,
  useRef,
  useState,
} from 'react';
import {
  BackHandler,
  NativeEventSubscription,
  useWindowDimensions,
} from 'react-native';

import { useTheme } from '@/common/theme';

import { BottomSheetBackdrop } from './Backdrop';
import { BottomSheetContext } from './context';

export type BottomSheetRef = BottomSheetModal;

export type BottomSheetProps = PropsWithChildren<{
  name: string;
  onClose?: VoidFunction;
}>;

export const BottomSheet = forwardRef<BottomSheetRef, BottomSheetProps>(
  ({ name, children, onClose }, ref) => {
    const { height: windowHeight } = useWindowDimensions();
    const { colors } = useTheme();

    const [snapPoints, setSnapPoints] = useState<(number | string)[]>([]);

    const internalRef = useRef<BottomSheetRef>(null);
    useImperativeHandle(ref, () => internalRef.current!, []);
    const backHandlerSubscriptionRef = useRef<NativeEventSubscription | null>(
      null,
    );

    const animationConfigs = useBottomSheetSpringConfigs({
      mass: 1,
      damping: 30,
      stiffness: 370,
    });

    const handleContentHeight = (contentHeight: number) => {
      const canExpand = contentHeight > windowHeight / 2;

      if (!snapPoints.length && canExpand) {
        setSnapPoints([Math.min(windowHeight, contentHeight)]);
      } else if (snapPoints.length && !canExpand) {
        setSnapPoints([]);
      }
    };

    const handleSheetPositionChange = (index: number) => {
      const isBottomSheetVisible = index >= 0;
      if (isBottomSheetVisible && !backHandlerSubscriptionRef.current) {
        backHandlerSubscriptionRef.current = BackHandler.addEventListener(
          'hardwareBackPress',
          () => {
            internalRef.current?.dismiss();
            return true;
          },
        );
      } else if (!isBottomSheetVisible) {
        backHandlerSubscriptionRef.current?.remove();
        backHandlerSubscriptionRef.current = null;
      }
    };

    const hasNonDynamicSnapPoints = !!snapPoints.length;

    return (
      <BottomSheetModal
        name={name}
        backgroundStyle={{ backgroundColor: colors.surfaceSubtle }}
        ref={internalRef}
        snapPoints={snapPoints}
        maxDynamicContentSize={windowHeight / 2}
        handleComponent={hasNonDynamicSnapPoints ? BottomSheetHandle : null}
        enableOverDrag={hasNonDynamicSnapPoints}
        backdropComponent={BottomSheetBackdrop}
        animationConfigs={animationConfigs}
        onDismiss={onClose}
        onChange={handleSheetPositionChange}
      >
        <BottomSheetContext.Provider
          value={{
            onContentHeightChange: handleContentHeight,
            expandable: hasNonDynamicSnapPoints,
            sheetRef: internalRef,
          }}
        >
          {children}
        </BottomSheetContext.Provider>
      </BottomSheetModal>
    );
  },
);

BottomSheet.displayName = 'BottomSheet';
