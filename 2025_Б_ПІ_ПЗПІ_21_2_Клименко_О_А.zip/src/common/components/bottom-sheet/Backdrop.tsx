import {
  BottomSheetBackdrop as RNBottomSheetBackdrop,
  BottomSheetBackdropProps,
} from '@gorhom/bottom-sheet';

export const BottomSheetBackdrop = (props: BottomSheetBackdropProps) => (
  <RNBottomSheetBackdrop
    {...props}
    appearsOnIndex={0}
    disappearsOnIndex={-1}
    opacity={0.3}
  />
);
