import { BottomSheetView as RNBottomSheetView } from '@gorhom/bottom-sheet';
import { BottomSheetViewProps } from '@gorhom/bottom-sheet/lib/typescript/components/bottomSheetView/types';
import { LayoutChangeEvent } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { useBottomSheet } from './context';

export const BottomSheetView = (props: BottomSheetViewProps) => {
  const bottomSheet = useBottomSheet();
  const { top } = useSafeAreaInsets();

  const handleLayout = (event: LayoutChangeEvent) => {
    props.onLayout?.(event);
    bottomSheet?.onContentHeightChange(event.nativeEvent.layout.height);
  };

  return (
    <RNBottomSheetView
      {...props}
      onLayout={handleLayout}
      style={[{ paddingBottom: top }, props.style]}
    />
  );
};
