import { BottomSheetScrollView as RNBottomSheetScrollView } from '@gorhom/bottom-sheet';
import { BottomSheetScrollViewProps } from '@gorhom/bottom-sheet/lib/typescript/components/bottomSheetScrollable/types';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { useBottomSheet } from './context';

export const BottomSheetScrollView = (props: BottomSheetScrollViewProps) => {
  const bottomSheet = useBottomSheet();
  const { top } = useSafeAreaInsets();

  const handleContentSize = (_: number, height: number) => {
    if (typeof props.onContentSizeChange === 'function')
      props.onContentSizeChange(_, height);

    bottomSheet?.onContentHeightChange(height);
  };

  return (
    <RNBottomSheetScrollView
      {...props}
      onContentSizeChange={handleContentSize}
      contentContainerStyle={[
        { paddingBottom: top * 2 },
        props.contentContainerStyle,
      ]}
    />
  );
};
