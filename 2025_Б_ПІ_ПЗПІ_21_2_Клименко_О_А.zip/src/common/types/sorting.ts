export type SortingParams = {
  order: 'asc' | 'desc';
  orderBy: string;
};
