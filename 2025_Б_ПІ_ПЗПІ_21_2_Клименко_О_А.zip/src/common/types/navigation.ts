import type { ComponentType } from 'react';

export type AppScreen = {
  Screen: ComponentType;
  Header?: ComponentType;
};
