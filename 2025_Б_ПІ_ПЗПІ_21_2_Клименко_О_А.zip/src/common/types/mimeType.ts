export type MediaType = 'image' | 'video' | 'audio' | 'document' | 'other';

export type MimeTypeInfo = {
  mimeType: string;
  mediaType: MediaType;
};
