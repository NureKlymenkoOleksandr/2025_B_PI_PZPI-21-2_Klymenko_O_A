type PaginationMetadata = {
  next: number | null;
};

export type PaginatedResponse<T> = PaginationMetadata & {
  data: T[];
};
