export type User = {
  email: string;
  id: string;
  name: string;
  picture: string;
};
