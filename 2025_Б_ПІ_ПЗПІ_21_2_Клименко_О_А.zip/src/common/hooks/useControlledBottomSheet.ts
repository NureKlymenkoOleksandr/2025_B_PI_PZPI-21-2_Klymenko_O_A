import { RefObject, useEffect } from 'react';

import { BottomSheetRef } from '@/common/components/bottom-sheet';

export const useControlledBottomSheet = (
  ref: RefObject<BottomSheetRef | null>,
  isOpen: boolean,
) => {
  useEffect(() => {
    if (isOpen) {
      ref.current?.present();
    } else {
      ref.current?.close();
    }
  }, [isOpen]);
};
