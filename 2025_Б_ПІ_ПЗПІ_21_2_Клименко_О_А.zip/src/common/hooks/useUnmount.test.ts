import { renderHook } from '@testing-library/react-native';

import { useUnmount } from './useUnmount';

describe('useUnmount', () => {
  it('should call the callback when component unmounts', () => {
    const callback = jest.fn();
    const { unmount } = renderHook(() => useUnmount(callback));

    expect(callback).not.toHaveBeenCalled();
    unmount();
    expect(callback).toHaveBeenCalledTimes(1);
  });

  it('should not call the callback during component updates', () => {
    const callback = jest.fn();
    const { rerender } = renderHook(() => useUnmount(callback));

    expect(callback).not.toHaveBeenCalled();
    rerender({});
    expect(callback).not.toHaveBeenCalled();
  });

  it('should use the latest callback when it changes', () => {
    const firstCallback = jest.fn();
    const secondCallback = jest.fn();
    const { rerender, unmount } = renderHook(
      ({ callback }) => useUnmount(callback),
      {
        initialProps: { callback: firstCallback },
      },
    );

    rerender({ callback: secondCallback });
    unmount();

    expect(firstCallback).not.toHaveBeenCalled();
    expect(secondCallback).toHaveBeenCalledTimes(1);
  });
});
